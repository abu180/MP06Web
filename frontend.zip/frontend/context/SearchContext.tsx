import React, { createContext, useContext, useState } from "react";

// Definición del tipo de contexto para la búsqueda
type SearchContextType = {
    searchTerm: string,
    setSearchTerm: (term: string) => void,
};

// Creación del contexto de búsqueda
const SearchContext = createContext<SearchContextType | undefined>(undefined);

export const SearchProvider: React.FC<({ children: React.ReactNode })> = ({ children }) => {
    const [searchTerm, setSearchTerm] = useState<string>("");

    return (
        <SearchContext.Provider
            value={{
                searchTerm,
                setSearchTerm
            }}
        >   
            {children}
        </SearchContext.Provider>
    );
};
// Hook personalizado para usar el contexto de búsqueda
export const useSearch = (): SearchContextType => {
    const context = useContext(SearchContext);
    if (!context) {
        throw new Error("useSearch must be used within a SearchProvider");
    }

    return context;
}