// Importación del archivo de estilos CSS para el componente
import './ViewReviews.css';
// Importación de hooks de React para estado y efectos secundarios
import { useEffect, useState } from 'react';
// Importación de componentes reutilizables
import NavBar from '../../../Components/NavBar/NavBar';
import AddReviews from '../AddReviews/AddReviews';

// Interfaces para tipar los datos de valoraciones y productos
interface Review {
    Review_id: number;
    product_id: number;
    customer_id: number;
    Review: string;
}

interface Product {
    Product_id: number;
    ProductName: string;
}

// Componente funcional principal que muestra y filtra reseñas
function ViewReviews() {
    // Estado para controlar si el pop-up de añadir reseña está abierto
    const [isOpen, setIsOpen] = useState(false);
    // Estado para almacenar las reseñas obtenidas
    const [reviews, setReviews] = useState<Review[]>([]);
    // Estado para almacenar los productos obtenidos
    const [products, setProducts] = useState<Product[]>([]);
    // Estado para saber qué producto está seleccionado en el filtro
    const [selectedProduct, setSelectedProduct] = useState<number | null>(null);
    // Estado para controlar si se está cargando la información
    const [loading, setLoading] = useState<boolean>(true);
    // Estado para capturar errores de carga
    const [error, setError] = useState<string | null>(null);

    // Función asincrónica para obtener las valoraciones del backend
    const fetchReviews = async () => {
        try {
            const response = await fetch('http://localhost:8000/Reviews');
            if (!response.ok) {
                throw new Error('Error al obtener las valoraciones');
            }
            const data: Review[] = await response.json();
            setReviews(data);
        } catch (error: unknown) {
            if (error instanceof Error) {
                setError(error.message);
            } else {
                setError('Error desconocido');
            }
        } finally {
            setLoading(false);
        }
    };

    // Función asincrónica para obtener los productos disponibles
    const fetchProducts = async () => {
        try {
            const response = await fetch('http://localhost:8000/products');
            if (!response.ok) {
                throw new Error('Error al obtener los productos');
            }
            const data: Product[] = await response.json();
            setProducts(data);
        } catch (error: unknown) {
            if (error instanceof Error) {
                setError(error.message);
            } else {
                setError('Error desconocido');
            }
        }
    };

    // useEffect que ejecuta ambas funciones al montar el componente
    useEffect(() => {
        fetchReviews();
        fetchProducts();
    }, []);

    // Manejador de cambio de producto en el filtro
    const handleProductChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const productId = parseInt(e.target.value, 10);
        setSelectedProduct(productId);
    };

    // Filtra las reseñas si hay un producto seleccionado
    const filteredReviews = selectedProduct
        ? reviews.filter((review) => review.product_id === selectedProduct)
        : reviews;

    // Muestra un mensaje de carga si aún se están obteniendo los datos
    if (loading) {
        return <div>Loading...</div>;
    }

    // Muestra un mensaje de error si la carga falló
    if (error) {
        return <div>Error: {error}</div>;
    }

    // Render principal del componente
    return (
        <section className='ViewReviewsSection-Container'>
            {/* Contenedor de la barra de navegación */}
            <div className='ViewReviewsNavBar-Container'>
                <NavBar />
            </div>

            {/* Contenedor principal de la sección de reseñas */}
            <div className='ViewReviews-Container'>
                <div className='ViewReviews-Card'>
                    <div className='ViewReviewsFiltred-Container'>
                        {/* Filtro desplegable para seleccionar producto */}
                        <select onChange={handleProductChange} value={selectedProduct || ''}>
                            <option value=''>Todos los productos</option>
                            {products.map((product) => (
                                <option key={product.Product_id} value={product.Product_id}>
                                    {product.ProductName}
                                </option>
                            ))}
                        </select>
                    </div>

                    {/* Listado de reseñas filtradas */}
                    <div className='ViewReviews'>
                        {filteredReviews.map((review) => (
                            <div key={review.Review_id}>
                                <p>{review.Review}</p>
                            </div>
                        ))}
                    </div>

                    {/* Botón para abrir el pop-up de añadir reseña */}
                    <div className='AddReviewButton-Container'>
                        <button onClick={() => setIsOpen(true)}>AÑADIR VALORACIÓN</button>
                    </div>
                </div>

                {/* Pop-up que se muestra al hacer clic en "Añadir valoración" */}
                {isOpen && (
                    <>
                        <div className="popup-overlay" onClick={() => setIsOpen(false)}></div>
                        {/* Contenedor del formulario de añadir valoración */}
                        <div className="popup-container">
                            <button
                                className="popup-close-button"
                                onClick={() => setIsOpen(false)}
                            >
                                &times;
                            </button>
                            <AddReviews />
                        </div>
                    </>
                )}
            </div>
        </section>
    );
}
// Exportación del componente para su uso en otras partes del proyecto
export default ViewReviews;