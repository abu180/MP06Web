// Importación del archivo de estilos CSS específico para este componente
import './Reviews.css';
// Importación del hook useNavigate para navegar entre rutas con React Router
import { useNavigate } from 'react-router-dom';
 
// Componente funcional que muestra una reseña destacada y un botón para ver más
function Reviews() {
    // Hook para redireccionar a otra ruta del sitio
    const navigate = useNavigate();


    return (
        // Contenedor principal de la sección de reseñas
        <section className='Reviews-Container'>
            {/* Contenedor de la reseña de ejemplo */}
            <div className='ReviewExample-Container'>
                {/* Título de la sección de reseñas */}
                <div className='ReviewExample-Title'>
                    <h4>NUESTROS CLIENTES HABLAN...</h4>
                </div>
                {/* Contenido de la reseña */}
                <div className='ReviewExample-Content'>
                    <p className='ReviewExample-Content1'>
                        “La hogaza de trigo sarraceno me ha parecido tan buena que he sentido la necesidad (casi la obligación) de felicitarles (…) La hogaza, de la que aún queda algo envuelta en la bolsa de papel, aguanta en perfectas condiciones después de varios días y el pan (que estamos disfrutando mi esposa y yo a más de 400 km de Madrid) es una maravilla”
                    </p>
                    <p className='ReviewExample-Content2'>
                        ESTEVAN
                    </p>
                </div>
                {/* Botón que permite ver más reseñas, redirige a la ruta /ViewReviews */}
                <div className='Review-ViweMore-ButtonContainer'>
                    <button onClick={() => navigate('/ViewReviews')}>VER MÁS</button>
                </div>
            </div>
            {/* Contenedor de ilustración decorativa con frase */}
            <div className='ReviewIlustration-Container'>
                {/* Título/frase motivacional */}
                <div className='ReviewIlustration-TitleContainer'>
                    <h4>LA VIDA ES CORTA, EMPIEZA POR EL POSTRE.</h4>
                </div>
                {/* Imagen ilustrativa relacionada con la sección */}
                <div className='ReviewIlustration-ImageContainer'>
                    <img src='/ReviewsIlustraiton.png' />
                </div>
            </div>
        </section>
    )
}

// Exportación del componente para que pueda ser usado en otras partes de la app
export default Reviews;