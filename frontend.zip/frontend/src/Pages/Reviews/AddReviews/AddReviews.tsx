// Componente para editar un usuario
import './AddReviews.css';
// Importaciones necesarias desde React y librerías externas
import { useState, useEffect } from 'react';
// Importaciones necesarias desde React y librerías externas
import { useNavigate } from 'react-router-dom';

// Componente funcional para añadir reseñas
type Product = {
    Product_id: number,
    ProductName: string,
}
// Tipo para definir la estructura del cliente
type Customer = {
    customer_id: number,
}

// Componente principal
// Añadir reseñas
function AddReviews() {
    const navigate = useNavigate();
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<boolean>(false);

    const [products, setProducts] = useState<Product[]>([]);
    const [product_id, setProduct_id] = useState<number>(0);
    const [review, setReview] = useState<string>('');

    //ID DEL USUARIO QUE LO UTILIZAREMOS PARA OBTENER SUS DATOS COMO CLIENTE
    const storedUser = localStorage.getItem('user');
    const user = storedUser ? JSON.parse(storedUser) : null;
    const user_id = user.userId;

    //OBJETO CLIENTE
    const [customer, setCustomer] = useState<Customer[]>([]); 

    //PETICION BACKEND PARA OBTENER LOS DATOS DEL CLIENTE
    const fetchCustomer = async () => {
        try {
            const response = await fetch(`http://localhost:8000/Reviews/getCustomer/${user_id}`);

            if(!response.ok) {
                throw new Error('Error al obtener los datos del cliente.');
            }

            const data = await response.json();
            console.log('Datos del cliente', data);
            console.log('Userid', user_id)
            setCustomer(data);
        } catch(error) {
            console.log(error)
        }
    }

    //PETICION BACKEND PARA OBTENER LOS PRODUCTOS
    const fetchProducts = async () => {
        try {
            const response = await fetch('http://localhost:8000/Reviews/getProducts');

            if(!response.ok) {
                throw new Error('Error al obtener los productos');
            }

            const data = await response.json();
            setProducts(data);
        } catch(error) {
            console.log(error);
        }
    }

    console.log('Customer:', customer);
    console.log('Customer ID:', customer[0]?.customer_id);

    //PETICION BACKEND PARA ENVIAR LOS DATOS DEL FORMULARIO
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setSuccess(false);

        // Validar campos vacíos
        try {
            const response = await fetch('http://localhost:8000/Reviews/addReview', {
                method: 'POST',
                headers: {
                    'Content-Type' : 'application/json',
                },
                body: JSON.stringify({ product_id, customer_id: customer[0]?.customer_id, review })
            });
            // Comprobar si la respuesta es correcta
            if(!response.ok) {
                throw new Error('No se ha podido anadir la resena');
            }
            // Convertir la respuesta a JSON
            setSuccess(true);
            setReview('');
        } catch(error) {
            console.log(error);
            setError('Error al agregar la resena');
        }
    }

    // Efecto para cargar los datos del cliente y los productos al montar el componente
    useEffect(() => {
        fetchCustomer();
        fetchProducts();
    }, []);


    return (
        <section className='AddReviewsSection-Container'>
            <div className='AddReviewsForm-Container'>
                <form onSubmit={handleSubmit}>
                    <div className='SelectedProduct-Container'>
                        { /* SELECT PARA SELECCIONAR EL PRODUCTO */ }
                        <select
                            value={product_id}
                            onChange={(e) => setProduct_id(parseInt(e.target.value, 10))}
                        >
                            <option value={0}>Selecciona un producto</option>
                            {products.map((product) => (
                                <option key={product.Product_id} value={product.Product_id}>
                                    {product.ProductName}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div className='AddReview-Container'>
                        <label>DEJA TU VALORACION</label>
                        <input 
                            type='text'
                            value={review}
                            onChange={(e) => setReview(e.target.value)}
                            placeholder='Escribe aqui tu valoracion'
                        />
                    </div>

                    <div className='SuccesAndErrorMessage-Container'>
                        {error && <div className="error-message">{error}</div>}
                        {success && <div className="success-message">¡Reseña añadida con éxito!</div>}
                    </div>

                    <div className='AddReviewButtons-Container'>
                        <div className='AddReviewButton'>
                            <button type='submit'>ANADIR</button>
                        </div>
                        <div className='BackButton-Container'>
                            <button onClick={() => navigate('/UsersHome')}>VOLVER</button>
                        </div>
                    </div>
                </form>
            </div>
        </section>
    )
}

export default AddReviews;