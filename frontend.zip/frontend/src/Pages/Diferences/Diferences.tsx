import './Diferences.css';
import { useRef, useState } from 'react';
import { useScroll, useTransform, motion } from 'framer-motion';



// Función principal del componente Diferences
function Diferences() {
    const targetRef = useRef<HTMLDivElement | null>(null);
    const [InnovationisHovered, setInnovationIsHovered] = useState(false);
    const [PersonalizeisHovered, setPersonalizeIsHovered] = useState(false);
    const [HomeDeliveryisHovered, setHomeDeliveryIsHovered] = useState(false);

    // Obtenemos el progreso de scroll relativo al elemento referenciado
    const { scrollYProgress } = useScroll({
        target: targetRef,
        offset: ["start end", "end end"]
    });

    // Detectamos el ancho de pantalla para adaptar animaciones según resolución
    const TitleY = useTransform(
        scrollYProgress,
        [0, 1],
        ["100%", "50%"]
    )
    // Animación de opacidad para el título principal
    const TitleOpacity = useTransform(
        scrollYProgress,
        [0, 0.4],
        [0, 1]
    )

    // Animación de opacidad para el ícono (imagen)
    const InnovationX = useTransform(
        scrollYProgress,
        [0.1, 0.6, 0.9],
        ["-65%", "-20%", "0%"]
    );
    // Animación de opacidad para el título principal
    const InnovationOpacity = useTransform(
        scrollYProgress,
        [0.2, 0.8],
        [0, 1]
    );
    // Animación del crecimiento del subtítulo (altura) según scroll
    const PersonalizeX = useTransform(
        scrollYProgress,
        [0.4, 0.6, 1],
        ["-90%", "-20%", "0%"]
    );
    // Animación de opacidad del subtítulo según el progreso del scroll
    const PersonalizeOpacity = useTransform(
        scrollYProgress,
        [0.6, 1],
        [0, 1]
    );
    // Animación del crecimiento del subtítulo (altura) según scroll
    const HomeDeliveryX = useTransform(
        scrollYProgress,
        [0.6, 0.8, 0.95],
        ["-25%", "-10%", "0%"]
    );
    // Animación de opacidad del subtítulo según el progreso del scroll
    const HomeDeliveryOpacity = useTransform(
        scrollYProgress,
        [0.6, 1],
        [0, 1]
    );
 

    return (
        <section ref={targetRef} className='Diferences-ContainerSection'>
            <div className='Diferences-StickyContainer'>
                <div className='Diferences-TitleContainer'>
                    <motion.h2 style={{ opacity: TitleOpacity, height: TitleY }}>¿QUÉ NOS DIFERENCIA?</motion.h2>
                </div>
                <div className='Diferences-ElementsContainer'>
                    <motion.div 
                        className='Innovation-ElementContainer'
                        style={{
                            x: InnovationX,
                            opacity: InnovationOpacity,
                            cursor: "pointer"
                        }}
                        whileHover="hover"
                        initial="rest"
                        animate="rest"
                    >
                        <div className='Innovation-ImageContainer'>
                            <motion.img 
                                src='/QueNosDiferenciaInnovacion.png' 
                                onMouseEnter={() => setInnovationIsHovered(true)}
                                onMouseLeave={() => setInnovationIsHovered(false)}
                                animate={{ scale: InnovationisHovered ? 0.8 : 1 }}
                                transition={{ duration: 0.3 }}
                            />
                        </div>
                        <div className='Innovation-TitleContainer'>
                            <h4>INNOVACIÓN</h4>
                        </div>
                        <div className='Innovation-ContentContainer'>
                            <motion.p
                                animate={{ scale: InnovationisHovered ? 1.1 : 1 }}
                                transition={{ duration: 0.3 }}
                            >
                                Apostamos por la innovación y el desarrollo de nuevos productos, diferenciales, que destaquen tanto por su sabor y calidad como por su fórmula innovadora. También trabajamos en descubrir productos funcionales que nos ayuden.
                            </motion.p>
                        </div>
                    </motion.div>
                    <motion.div 
                        className='Personalize-ElementContainer'
                        style={{
                            x: PersonalizeX,
                            opacity: PersonalizeOpacity,
                            cursor: "pointer"
                        }}
                        transition={{ duration: 1.5, ease: "easeOut" }}
                    >
                        <div className='Personalize-ImageContainer'>
                            <motion.img 
                                src='/QueNosDiferenciaPersonalizacion.png' 
                                onMouseEnter={() => setPersonalizeIsHovered(true)}
                                onMouseLeave={() => setPersonalizeIsHovered(false)}
                                animate={{ scale: PersonalizeisHovered ? 0.8 : 1 }}
                                transition={{ duration: 0.3 }}
                            />
                        </div>
                        <div className='Personalize-TitleContainer'>
                            <h4>PERSONALIZACIÓN</h4>
                        </div>
                        <div className='Personalize-ContentContainer'>
                            <motion.p
                                animate={{ scale: PersonalizeisHovered ? 1.1 : 1 }}
                                transition={{ duration: 0.3 }}
                            >
                                En nuestros establecimientos personalizamos cualquier tipo de dulce, sobre todo nuestras tartas, en las que incluimos nombres, fotos, objetos de chocolate y todo lo que quieras.
                            </motion.p>
                        </div>
                    </motion.div>
                    <motion.div 
                        className='HomeDelivery-ElementContainer'
                        style={{
                            x: HomeDeliveryX,
                            opacity: HomeDeliveryOpacity,
                            cursor: "pointer"
                        }}
                    >
                        <div className='HomeDelivery-ImageContainer'>
                            <motion.img 
                                src='/QueNosDiferenciaEntregaDomicilio.png'
                                onMouseEnter={() => setHomeDeliveryIsHovered(true)}
                                onMouseLeave={() => setHomeDeliveryIsHovered(false)}
                                animate={{ scale: HomeDeliveryisHovered ? 0.8 : 1 }}
                                transition={{ duration: 0.3 }}
                            />
                        </div>
                        <div className='HomeDelivery-TitleContainer'>
                            <h4>ENTREGA A DOMICILIO</h4>
                        </div>
                        <div className='HomeDelivery-ContentContainer'>
                            <motion.p
                                animate={{ scale: HomeDeliveryisHovered ? 1.1 : 1 }}
                                transition={{ duration: 0.3 }}
                            >
                                Ofrecemos un servicio rápido y seguro para el transporte de nuestros productos al lugar que usted desee. Además, de disponer de un servicio a domicilio para llevarte el pan a casa, también comercializamos nuestros productos por el resto de la provincia.
                            </motion.p>
                        </div>
                    </motion.div>
                </div>
            </div>
        </section>
    )
}

export default Diferences;