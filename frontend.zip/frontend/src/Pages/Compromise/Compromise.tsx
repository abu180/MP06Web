// Importación de estilos CSS para el componente
import './Compromise.css';
// Importación de funcionalidades de framer-motion para animaciones
import { motion, useScroll, useTransform } from "framer-motion";
// Importación de useRef de React para referenciar elementos del DOM
import { useRef } from "react";

function Compromise() {
    // Creamos una referencia al elemento <section> principal
    const targetRef = useRef<HTMLDivElement | null>(null);

    // Obtenemos el progreso de scroll relativo al elemento referenciado
    const { scrollYProgress } = useScroll({
        target: targetRef,
        // Inicia la animación cuando el 60% del elemento entra en pantalla
        offset: ["0.6 end", "end end"]
    });


    // Detectamos el ancho de pantalla para adaptar animaciones según resolución
    const screenWidth = typeof window !== 'undefined' ? window.innerWidth : 0;
    // Valores de transformación para el tamaño del subtítulo según resolución
    const CompromiseSubtitleGrowthOutput = screenWidth >= 1440 ? ["0", "50%", "100%"] : ["100%", "50%", "0%"];
    const CompromiseSubtitleOpacityOutput = screenWidth >= 1440 ? ["0", "1"] : ["0", "1"];
    
    // Animación de opacidad para el ícono (imagen)
    const CompromiseIconOpacity = useTransform(
        scrollYProgress,
        [0, 0.5],
        [0, 1]
    );

    // Animación de opacidad para el título principal
    const CompromiseTitleOpacity = useTransform(
        scrollYProgress,
        [0.6, 1],
        [0, 1]
    )

    // Animación del crecimiento del subtítulo (altura) según scroll
    const CompromiseSubtitleGrowth = useTransform(
        scrollYProgress,
        [0, 0.6, 1],
        CompromiseSubtitleGrowthOutput
    );

    // Animación de opacidad del subtítulo según el progreso del scroll
    const CompromiseSubtitleOpacity = useTransform(
        scrollYProgress,
        [0.2, 1],
        CompromiseSubtitleOpacityOutput
    )


    return (
        // Sección principal con referencia para calcular scroll
        <section ref={targetRef} className='Compromise-Container'>
            {/* Contenedor del ícono con animación de opacidad */}
            <motion.div 
                className='CompromiseIcon-Container'
                style={{
                    opacity: CompromiseIconOpacity
                }}
            >
                <img src='/HacerLasCosasBien.png' />
            </motion.div>

            {/* Contenedor del título y subtítulo */}
            <div className='CompromiseTitleSubititle-Container'>
                {/* Título principal con animación de opacidad */}
                <div className='CompromiseTitle-Container'>   
                    <motion.h1
                        style={{
                            //height: CompromiseSubtitleGrowth,
                            opacity: CompromiseTitleOpacity
                        }}
                    >
                        HACER LAS COSAS
                    </motion.h1>
                </div>

                {/* Subtítulo con animación de altura y opacidad */}
                <div className='CompromiseSubtitle-Container'>
                    <motion.h3
                        style={{
                            height: CompromiseSubtitleGrowth,
                            opacity: CompromiseSubtitleOpacity
                        }}
                    >
                        EXTRAORDINARIAMENTE BIEN
                    </motion.h3>
                </div>
            </div>
            
            {/* Contenido final con texto explicativo */}
            <div className='CompromiseContent-Container'>
                <p>
                    En MIGA MÍA apostamos por una panadería sostenible, con ingredientes naturales y materiales ecológicos.
                    Apoyamos a colectivos vulnerables y colaboramos con ONG en favor de la infancia.
                </p>
            </div>
        </section>
    )
}

export default Compromise;