import './ContactUs.css';
import { useEffect, useState } from 'react';
import NavBar from '../../Components/NavBar/NavBar';


// Definición de la interfaz para los datos del cliente
interface Customer {
    customer_id: number,
    Name: string,
    Email: string,
}

// Definición de la interfaz para los datos del cliente
function ContactUs() {
    const [customer, setCustomer] = useState<Customer[]>([]);
    const [name, setName] = useState<string>('');
    const [email, setEmail] = useState<string>('');
    const [affair, setAffair] = useState<string>('');
    const [message, setMessage] = useState<string>('');
    //ID DEL USUARIO QUE LO UTILIZAREMOS PARA OBTENER SUS DATOS COMO CLIENTE
    const storedUser = localStorage.getItem('user');
    const user = storedUser ? JSON.parse(storedUser) : null;
    const user_id = user.userId;
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<boolean>(false);

    // Función para obtener los datos del cliente
    const fetchCustomer = async () => {
        try {
            const response = await fetch(`http://localhost:8000/Contact/getCustomer/${user_id}`);
            // Comprobar si la respuesta es correcta
            if(!response.ok) {
                throw new Error('Error al obtener los datos del cliente');
            }
            // Convertir la respuesta a JSON
            const data = await response.json();
            setCustomer(data);
            // console.log(data);
        } catch(error) {
            console.log(error);
        }
    };

    // Función para manejar el envío del formulario
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setSuccess(false);

        // Validar campos vacíos
        try {
            const response = await fetch('http://localhost:8000/Contact/addContact', {
                method: 'POST',
                headers: {
                    'Content-Type' : 'application/json',
                },
                body: JSON.stringify({ customer_id: customer[0]?.customer_id, name, email, affair, message })
            });
            // Comprobar si la respuesta es correcta
            if(!response.ok) {
                throw new Error('No se ha podido agregar la peticion de contacto');
            }
            // Convertir la respuesta a JSON
            setSuccess(true);
            setAffair('');
            setMessage('');

        // Mostrar mensaje de éxito
        } catch(error) {
            console.log(error);
            setError('Error al agregar el contacto');
        }
    }

    // Efecto para obtener los datos del cliente al cargar el componente
    useEffect(() => {
        if(customer.length > 0) {
            setName(customer[0].Name);
            setEmail(customer[0].Email)
        }
        // Llamar a la función para obtener los datos del cliente
        fetchCustomer();
    }, [customer]);

    return (
        <section className='ContactUsSection-Container'>
            <div className='ContactUsNavBar-Container'>
                <NavBar />
            </div>
            <div className='ContactUsContent-Container'>
                <div className='ContactUsTitle-Container'>
                    <h2>HABLAMOS?</h2>
                </div>
                <div className='ContactUsParragraph-Container'>
                    <p>Estamos aquí para ayudarte. Si tienes alguna pregunta sobre nuestros productos, quieres colaborar o simplemente quieres decir hola, puedes escribirnos a través del formulario o usando cualquiera de nuestros canales de contacto. ¡Te responderemos lo antes posible!</p>
                </div>
                <div className='ConactUsCard'>
                    <div className='ContactUsCardTitle-Container'>
                        <h2>CONTACTA CON NOSOTROS</h2>
                    </div>
                    <div className='ContactUsCardParragraph-Container'>
                        <p>¿Tienes alguna duda, sugerencia o simplemente quieres saludarnos? Estaremos encantados de escucharte</p>
                    </div>
                    <div className='ContactUsForm-Container'>
                        <form className='ContactUsForm' onSubmit={handleSubmit}>
                            <input 
                                type='text'
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                placeholder='Nombre'
                                disabled
                                required
                            />
                            <input 
                                type='text'
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                placeholder='Email'
                                disabled
                                required
                            />
                            <input 
                                type="text" 
                                onChange={(e) => setAffair(e.target.value)}
                                placeholder='Asunto'
                            />
                            <input 
                                type="text" 
                                onChange={(e) => setMessage(e.target.value)}
                                placeholder='Mensaje'
                            />
                            
                            <div className='ContactUsSuccesAndErrorMessage-Container'>
                                {error && <div className="error-message">{error}</div>}
                                {success && <div className="success-message">¡Reseña añadida con éxito!</div>}
                            </div>

                            <div className='ContactUsButton-Container'>
                                <button type='submit'>ENVIAR</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    )
}

export default ContactUs;