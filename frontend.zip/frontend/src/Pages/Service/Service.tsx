// Importación de estilos CSS para la sección de servicios
import './Service.css';
// Importación de React y hooks de framer-motion para animaciones
import React from 'react';
// Importación de framer-motion para animaciones
import { motion, useScroll, useTransform } from "framer-motion";
// Importación de useScroll y useTransform de framer-motion para animaciones
import { useRef } from 'react';

// Importación de useRef de React para referenciar elementos del DOM
function Service() {
    const targetRef = useRef<HTMLDivElement | null>(null);
    const { scrollYProgress } = useScroll({
        target: targetRef,
        offset: ["start end", "end end"]
    });
    // Detectamos el ancho de pantalla para adaptar animaciones según resolución
    const BreadX = useTransform(
        scrollYProgress,
        [0.2, 0.5],
        ["0%", "-80%"]
    );


    // ADAPTAR LA ANIMACION SEGUN OTRAS DIMENSIONES DE PANTALLA
    const screenWidth = typeof window !== 'undefined' ? window.innerWidth : 0;
    const bakeryOutput = screenWidth >= 1440 ? ["0%", "82.5%"] : ["0%", "221.2%"];
    // Animación de opacidad para el ícono (imagen)
    const BakeryX = useTransform(
        scrollYProgress,
        [0.6, 1],
        bakeryOutput
    );


    return (
        <section ref={targetRef} className='Service-SectionContainer'>
            <div className='Service-TitleContainer'>
                <h4>¿QUÉ TE OFRECEMOS?</h4>
            </div>
            <div className='Service-FirstServiceContainer'>
                <motion.div 
                    className='BreadService-Container'
                    style={{
                        x: BreadX
                    }}
                >
                    <div className='BreadCard-Container'>
                        <div className='BreadImage-Container'>
                            <img src='/Bread.jpg' />
                        </div>
                        <div className='BreadContent-Container'>
                            <div className='BreadTitle-Container'>
                                <h4>PANES</h4>
                            </div>
                            <div className='BreadParragraph-Container'>
                                <p>Ofrecemos una variedad de panes frescos para todos los gustos. Como pan integral, centeno, masa madre... Tú escoges.</p>
                            </div>
                        </div>
                    </div>
                </motion.div>
                <div className='CoffeService-Container'>
                    <div className='CoffeCard-Container'>
                        <div className='CoffeContent-Container'>
                            <div className='CoffeTitle-Container'>
                                <h4>CAFÉ</h4>
                            </div>
                            <div className='CoffeParagraph-Container'>
                                <p>Ofrecemos una amplia variedad de cafés con diferentes granos y sabores para satisfacer todos los paladares.</p>
                            </div>
                        </div>
                        <div className='CoffeImage-Container'>
                            <img src='/Coffe.jpg' />
                        </div>
                    </div>
                </div>
            </div>
            <div className='Service-SecondServiceContainer'>
                <div className='ShakesService-Container'>
                    <div className='ShakesCard-Container'>
                        <div className='ShakesImage-Container'>
                            <img src='/Shakes.jpg' />
                        </div>
                        <div className='ShakesContent-Container'>
                            <div className='ShakesTitle-Container'>
                                <h4>BATIDOS</h4>
                            </div>
                            <div className='ShakesParragraph-Container'>
                                <p>Ofrecemos una variedad de batidos deliciosos y nutritivos, con diferentes sabores y combinaciones para todos los gustos. Tú escoges.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <motion.div 
                    className='BakeryService-Container'
                    style={{
                        x: BakeryX,
                    }}
                >
                    <div className='BakeryCard-Container'>
                        <div className='BakeryContent-Container'>
                            <div className='BakeryTitle-Container'>
                                <h4>BOLLERÍA</h4>
                            </div>
                            <div className='BakeryParagraph-Container'>
                                <p>Ofrecemos una variedad de bollería deliciosa y recién horneada para todos los gustos.</p>
                            </div>
                        </div>
                        <div className='BakeryImage-Container'>
                            <img src='/Bakery.jpeg' />
                        </div>
                    </div>
                </motion.div>
            </div>
        </section>
    )
}

export default Service;