import './HomeIntro.css';
import NavBar from '../../Components/NavBar/NavBar';
import { motion } from "framer-motion";

// Componente funcional de la página de inicio
export default function HomeIntro() {
    return (
        <section className="HomeIntro-Container">
            <div className='NavBar-Container'>
                <NavBar />
            </div>
            <div className='Intro-Container'>
                <div className='Content-Container'>
                    <div className='LogoName-Container'>
                        <h1>MIGA MÍA</h1>
                    </div>
                    <div className='SloganName-Container'>
                        <h4>Del Horno a Tu Corazón</h4>
                    </div>
                </div>
                <div className='Icons-Container'>
                    <motion.div 
                        className='Croussant-Container'
                        animate={{
                            y: ["0px", "10px", "0px"]
                        }}
                        transition={{
                            duration: 2,
                            repeat: Infinity,
                            repeatType: "loop",
                            ease: "easeInOut",
                        }}
                    >
                        <img src='/CroussaintIconIlustration.png' />
                    </motion.div>
                    <motion.div 
                        className='Cake-Container'
                        animate={{
                            y: ["0px", "-6px", "0px"],

                        }}
                        transition={{
                            duration: 2,
                            repeat: Infinity,
                            repeatType: "loop",
                            ease: "easeInOut",
                        }}
                    >
                        <img src='/CakeIlustrationIcon2.png' />
                    </motion.div>
                    <motion.div 
                        className='Coffe-Container'
                        animate={{
                            y: ["0px", "-12px", "0px"],
                            
                        }}
                        transition={{
                            duration: 2,
                            repeat: Infinity,
                            repeatType: "loop",
                            ease: "easeInOut",
                        }}
                    >
                        <img src='/CoffeeIconIlustration.png' />
                    </motion.div>
                    <motion.div 
                        className='Baget-Container'
                        animate={{
                            y: ["0px", "15px", "0px"],
                            
                        }}
                        transition={{
                            duration: 2,
                            repeat: Infinity,
                            repeatType: "loop",
                            ease: "easeInOut",
                        }}
                    >
                        <img src='/BaguetIconIlustration.png' />
                    </motion.div>
                </div>
            </div>
        </section>
    );
}