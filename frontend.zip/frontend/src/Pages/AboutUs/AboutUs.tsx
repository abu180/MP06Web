// Importamos los estilos específicos para el componente AboutUs
import './AboutUs.css';
// Importamos la librería framer-motion (aunque aquí no se está usando aún)
//import motion from "framer-motion";
// Importamos el componente de la barra de navegación
import NavBar from '../../Components/NavBar/NavBar';


// Definimos el componente funcional AboutUs
function AboutUs() {
    return (
        // Contenedor principal de toda la sección About Us
        <section className='AboutUsSection-Container'>
            {/* Contenedor de la barra de navegación */}
            <div className='AboutUsNavBar-Container'>
                <NavBar />
            </div>

            {/* Contenedor del contenido principal */}
            <div className='AboutUsContent-Container'>
                <div className='AboutUsCard'>
                    {/* Título principal */}
                    <div className='AboutUsTitle-Container'>
                        <h2>¿QUIÉNES SOMOS?</h2>
                    </div>
                    
                    {/* Subtítulo de la historia */}
                    <div className='AboutUsSubtitle-Container'>
                        <h3>De líneas de código a líneas de pan fresco: nuestra historia</h3>
                    </div>

                    {/* Contenido del texto de la historia */}
                    <div className='AboutUsContent'>
                        {/* Primer párrafo: presentación de los fundadores y origen de la idea */}
                        <div className='FirstParragraph-Container'>
                            <p>Somos Aboubakr y Jose Angel, dos desarrolladores web con algo en común además del código: una profunda pasión por la gastronomía. Después de años dedicados al mundo del software, trabajando para startups y empresas tecnológicas, descubrimos que nuestras conversaciones no giraban en torno a frameworks o servidores… sino a pan casero, café de especialidad y recetas tradicionales con un toque moderno. Nos dimos cuenta de que cada vez que terminábamos una jornada de programación, lo único que queríamos era hornear, experimentar en la cocina y compartir esos sabores con los demás.</p>
                        </div>
                        {/* Párrafo de cierre: bienvenida al usuario */}
                        <div className='SecondParragraph-Container'>
                            <p>Así nació nuestra idea: fusionar tecnología y cocina. Creamos nuestro propio negocio gastronómico con un enfoque artesanal, sostenible y auténtico. Y como no podía ser de otra manera, también diseñamos nuestra propia web desde cero, cuidando cada detalle con tanto mimo como nuestras recetas. La página que estás viendo es fruto de esa doble pasión: por lo bien hecho, en el código y en la cocina. Hoy, nuestra pequeña empresa es más que un proyecto: es una forma de vida. Queremos inspirar a otros a disfrutar de los sabores reales, los productos naturales y el trabajo hecho con el corazón.</p>
                        </div>
                        <div className='EndParragraph-Container'>
                            <p>Bienvenid@ a nuestra panadería digital.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}

// Exportamos el componente para poder usarlo en otras partes de la aplicación
export default AboutUs;