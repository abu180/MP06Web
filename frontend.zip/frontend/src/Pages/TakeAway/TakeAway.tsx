import './TakeAway.css';
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef, useState, useEffect } from "react";

// Importación de useRef de React para referenciar elementos del DOM
function TakeAway() {
    const targetRef = useRef<HTMLDivElement | null>(null);
    // Obtenemos el progreso de scroll relativo al elemento referenciado
    const { scrollYProgress } = useScroll({
        target: targetRef,
        offset: ["0.6 end", "end end"]
    });
    // Detectamos el ancho de pantalla para adaptar animaciones según resolución
    const CompromiseIconOpacity = useTransform(
        scrollYProgress,
        [0.1, 1],
        [0, 1]
    );

    // Animación de opacidad para el ícono (imagen)
    const CompromiseSubtitleOpacity = useTransform(
        scrollYProgress,
        [0, 1],
        [0, 1]
    )

    // Animación del crecimiento del subtítulo (altura) según scroll
    const fullTitle = "TAKE AWAY PARA LLEVAR";
    const fullSubtitle = "Solo tienes que pedirlo, y te lo preparamos para llevar. Disfruta de Miga Mia en cualquier sitio. Donde quieras y como quieras. "
    const [typedTitle, setTypedTitle] = useState("");
    const [typedSubtitle, setTypedSubtitle] = useState("");
    const [hasStartedTyping, setHasStartedTyping] = useState(false);
    const [titleFinished, setTitleFinished] = useState(false);
    
    // Animación del crecimiento del subtítulo (altura) según scroll
    useEffect(() => {
        const unsubscribe = scrollYProgress.on("change", (value) => {
            if (value > 0.4 && !hasStartedTyping) {
                setHasStartedTyping(true);
            } else if (value <= 0.2 && hasStartedTyping) {
                // Si salimos de la sección, reiniciar
                setHasStartedTyping(false);
                setTypedTitle(""); 
                setTypedSubtitle("");
                setTitleFinished(false);
            }
        });
        // Limpiar el efecto al desmontar el componente
        return () => unsubscribe(); 
    }, [scrollYProgress, hasStartedTyping]);
    
    

    // efecto de escritura
    useEffect(() => {
        if (!hasStartedTyping) return;
    
        const isCancelled = false;

        const typeText = async () => {
            let typed = "";
            for (const letter of fullTitle) {
                if (isCancelled) break;
                typed += letter
                setTypedTitle(typed);


                await new Promise(res => setTimeout(res, 100));
            }
            setTitleFinished(true);
        }

        typeText();
    }, [hasStartedTyping]);
    
    // efecto de escritura
    useEffect(() => {
        if(!titleFinished) return;
        // Si el título no ha terminado de escribirse, no hacer nada
        let isCancelled = false;
        // Función de escritura
        const typeSubtitle = async () => {
            let typed = "";
            for (const letter of fullSubtitle) {
                if (isCancelled) break;
                typed += letter;
                setTypedSubtitle(typed)
                await new Promise(res => setTimeout(res, 25));
            }
        }
        // Llamar a la función de escritura    
        typeSubtitle();

        return () => {
            isCancelled = true;
        };
    }, [titleFinished])


    return (
        <section ref={targetRef} className='TakeAway-Container'>
            <motion.div 
                className='TakeAwayIcon-Container'
                style={{
                    opacity: CompromiseIconOpacity
                }}
            >
                <img src='/TakeAwayIlustration.png' />
            </motion.div>
            <div className='TakeAwayTitleSubititle-Container'>
                <div className='TakeAwayTitle-Container'>   
                    <motion.h1
                        style={{
                            //height: CompromiseTitleGrowth,
                            opacity: CompromiseSubtitleOpacity,
                            whiteSpace: 'pre'
                        }}
                    >
                        {typedTitle}
                    </motion.h1>
                </div>
            </div>
            <div className='TakeAwayContent-Container'>
                <p>
                    {typedSubtitle}
                </p>
            </div>
        </section>
    )
}

export default TakeAway;