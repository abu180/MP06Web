// Estilo global
import './App.css';
// Depenecias de React y React Router
import React from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate
} from 'react-router-dom';

// Contextos y Providers
import { AuthProvider } from './Components/Login/Auth/Auth';

// Hooks de Autenticación
import { useAuth } from './Components/Login/Auth/useAuth';
import { SearchProvider } from '../context/SearchContext';

// Páginas de Autenticación / Registro
import SyncUp from './Components/Login/SyncUp/SyncUp';
import SyncDown from './Components/Login/SyncDown/SyncDown';
import MultiStepRegister from './Components/Register/MultiStepRegister';

// Páginas de Usuario
import UserHome from './Components/UserHome/UserHome';
import ProductsCatalogue from './Components/Products/ProductsCatalogue/ProductsCatalogue';
import ProductPage from './Components/Products/forCustomer/Products/Products';
import Cart from './Components/Cart/Cart';
import ContactUs from './Pages/ContactUs/ContactUs';
import AboutUs from './Pages/AboutUs/AboutUs';
import ViewReviews from './Pages/Reviews/ViewReviews/ViewReviews';

// Páginas de Administrador
import AdminHome from './Components/Admin/AdminHome/AdminHome';
import AdminMenu from './Components/Admin/AdminMenu/AdminMenu';

// Gestión de Clientes (Admin)
import ListCustomers from './Components/Customers/listCustomers/listCustomers';
import ListCustomersRemove from './Components/Customers/listCustomers/ListCustomersRemove';
import AddCustomer from './Components/Customers/addCustomer/addCustomer';
import EditCustomer from './Components/Customers/editCustomer/editCustomer';

// Gestión de Productos (Admin)
import ListProducts from './Components/Products/listProducts/listProducts';
import AddProduct from './Components/Products/addProducts/addProducts';
import EditProduct from './Components/Products/editProducts/editProducts';

//Productos por Proveedor (Admin)
import AddProduct_Supplier from './Components/Products_Supplier/addProduct_Supplier/addProduct_Supplier';
import EditProduct_Supplier from './Components/Products_Supplier/editProduct_Supplier/editProduct_Supplier';

// Gestión de Pedidos (Admin)
import ListOrders from './Components/Orders/listOrders/listOrders';

// Gestión de Proveedores (Admin)
import ListSuppliers from './Components/Suppliers/listSuppliers/listSuppliers';
import AddSupplier from './Components/Suppliers/addSuplier/addSuplier';
import EditSupplier from './Components/Suppliers/editSupplier/editSupplier';

//Checkout (Admin) 
import SuccessCheckout from './Components/Checkout/SuccessCheckout/SuccessCheckout';
import CancelCheckout from './Components/Checkout/CancelCheckout/CancelCheckout';

//Usuarios asociados a Cliente (Admin)
import AddCustomerUser from './Components/Customers_Users/addCustomer_User/addCustomer_User';
import EditCustomerUser from './Components/Customers_Users/editCustomer_User/editCustomer_User';


// Ruta pública: solo accesible si NO estás autenticado.
// Si ya estás autenticado, te redirige a tu página de inicio correspondiente.
function PublicRoute({ children }: { children: JSX.Element }) {
  const { isAuthenticated, user } = useAuth();

  // Si el usuario está autenticado...
  if (isAuthenticated) {
    // ...y es admin, lo enviamos a /AdminHome
    if (user?.email === 'admin@gmail.com') {
      return <Navigate to="/AdminHome" replace />;
    }
    // ...si es un usuario normal, lo enviamos a /UserHome
    return <Navigate to="/UserHome" replace />;
  }

  // Si NO está autenticado, mostramos el componente solicitado (login, register, etc.)
  return children;
}


// Ruta privada: solo accesible si estás autenticado.
// Si no, redirige a la página de autenticación (/SyncUp).
function PrivateRoute({ children }: { children: JSX.Element }) {
  const { isAuthenticated } = useAuth();

  // Si estás autenticado, permitimos el acceso
  if (isAuthenticated) {
    return children;
  }

  // Si no, te enviamos a la pantalla de login / sincronización
  return <Navigate to="/SyncUp" replace />;
}


// Ruta de admin: solo accesible para el usuario admin.
// Si no eres admin, te redirige a /UserHome.
function AdminRoute({ children }: { children: JSX.Element }) {
  const { user } = useAuth();

  // Solo permitimos el acceso si el email coincide con el del admin
  if (user?.email === 'admin@gmail.com') {
    return children;
  }

  // Si no, redirigimos al home de usuario normal
  return <Navigate to="/UserHome" replace />;
}

// Ruta de usuario normal: solo accesible para usuarios que NO sean admin.
// Si eres admin, te redirige al home de admin.
function UserRoute({ children }: { children: JSX.Element }) {
  const { user } = useAuth();

  // Permitimos el acceso si existe user y NO es admin
  if (user && user.email !== 'admin@gmail.com') {
    return children;
  }

  // Si el usuario es admin (o no hay usuario), lo enviamos al home de admin
  return <Navigate to="/AdminHome" replace />;
}


function App() {
  return (
    <AuthProvider>
      <SearchProvider>
        <Router>
          <Routes>

            {/* ─────────────── PÚBLICAS ─────────────── */}
            <Route path="/" element={<Navigate to="/SyncUp" replace />} />
            <Route
              path="/SyncUp"
              element={
                <PublicRoute>
                  <SyncUp />
                </PublicRoute>
              }
            />
            <Route
              path="/login"
              element={
                <PublicRoute>
                  <SyncUp />
                </PublicRoute>
              }
            />
            <Route
              path="/register"
              element={
                <PublicRoute>
                  <MultiStepRegister />
                </PublicRoute>
              }
            />
            <Route path="/logout" element={<SyncDown />} />

            {/* ───────────── USUARIO NORMAL ───────────── */}
            <Route
              path="/UserHome"
              element={
                <PrivateRoute>
                  <UserRoute>
                    <UserHome />
                  </UserRoute>
                </PrivateRoute>
              }
            />
            <Route
              path="/ProductsPage"
              element={
                <PrivateRoute>
                  <UserRoute>
                    <ProductsCatalogue />
                  </UserRoute>
                </PrivateRoute>
              }
            />
            <Route
              path="/products/:productName"
              element={
                <PrivateRoute>
                  <UserRoute>
                    <ProductPage />
                  </UserRoute>
                </PrivateRoute>
              }
            />
            <Route
              path="/Cart"
              element={
                <PrivateRoute>
                  <UserRoute>
                    <Cart />
                  </UserRoute>
                </PrivateRoute>
              }
            />
            <Route path="/ContactUs" element={<ContactUs />} />
            <Route path="/AboutUs" element={<AboutUs />} />

            {/* ────────────── ADMIN ────────────── */}
            <Route
              path="/AdminHome"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <AdminHome />
                  </AdminRoute>
                </PrivateRoute>
              }
            />

            {/* Clientes */}
            <Route
              path="/Customers"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <ListCustomers />
                  </AdminRoute>
                </PrivateRoute>
              }
            />
            <Route
              path="/Customers/removed"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <ListCustomersRemove />
                  </AdminRoute>
                </PrivateRoute>
              }
            />
            <Route
              path="/Customers/addCustomer"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <AddCustomer />
                  </AdminRoute>
                </PrivateRoute>
              }
            />
            <Route
              path="/Customers/editCustomer/:id"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <EditCustomer />
                  </AdminRoute>
                </PrivateRoute>
              }
            />

            {/* Productos */}
            <Route
              path="/Products"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <ListProducts />
                  </AdminRoute>
                </PrivateRoute>
              }
            />
            <Route
              path="/Products/addProduct"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <AddProduct />
                  </AdminRoute>
                </PrivateRoute>
              }
            />
            <Route
              path="/Products/editProduct/:id"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <EditProduct />
                  </AdminRoute>
                </PrivateRoute>
              }
            />
            <Route path="/Products/addProduct_Supplier/:id" element={<AddProduct_Supplier />} />
            <Route path="/Products/editProduct_Supplier/:id" element={<EditProduct_Supplier />}/>

            {/* Pedidos */}
            <Route
              path="/Orders/getOrders"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <ListOrders />
                  </AdminRoute>
                </PrivateRoute>
              }
            />

            {/* Proveedores */}
            <Route
              path="/Suppliers"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <ListSuppliers />
                  </AdminRoute>
                </PrivateRoute>
              }
            />
            <Route
              path="/Suppliers/addSupplier"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <AddSupplier />
                  </AdminRoute>
                </PrivateRoute>
              }
            />
            <Route
              path="/Suppliers/editSupplier/:id"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <EditSupplier />
                  </AdminRoute>
                </PrivateRoute>
              }
            />

            {/* Checkout */}
            <Route
              path="/Checkout/Success"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <SuccessCheckout />
                  </AdminRoute>
                </PrivateRoute>
              }
            />
            <Route
              path="/Checkout/Cancel"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <CancelCheckout />
                  </AdminRoute>
                </PrivateRoute>
              }
            />

            {/* Admin Menu & Reviews */}
            <Route
              path="/AdminMenu"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <AdminMenu />
                  </AdminRoute>
                </PrivateRoute>
              }
            />
            <Route
              path="/ViewReviews"
              element={<ViewReviews />}
            />

            {/* Asociar Usuarios a Cliente */}
            <Route
              path="/Customers/addCustomer_User/:id"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <AddCustomerUser />
                  </AdminRoute>
                </PrivateRoute>
              }
            />
            <Route
              path="/Customers/editCustomer_User/:id"
              element={
                <PrivateRoute>
                  <AdminRoute>
                    <EditCustomerUser />
                  </AdminRoute>
                </PrivateRoute>
              }
            />

            {/* ───────────── CUALQUIER OTRA RUTA ───────────── */}
            <Route path="*" element={<Navigate to="/SyncUp" replace />} />
          </Routes>
        </Router>
      </SearchProvider>
    </AuthProvider>
  );
}

export default App;
