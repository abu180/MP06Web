// src/Components/Sidebar/Sidebar.tsx
import React, { useState } from 'react';
// Para navegación entre rutas
import { Link } from 'react-router-dom';
// Estilos del sidebar
import '../Styles/Sidebar.css';
// Componente del perfil del usuario (parte superior del sidebar)
import ProfileCard from '../Perfil/ProfileCard';
// Íconos
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// Íconos específicos
import { faHouse, faUsers, faBreadSlice, faTruck } from '@fortawesome/free-solid-svg-icons';


// Componente funcional del Sidebar
const Sidebar: React.FC = () => {
  // Estado que controla si la barra lateral está expandida o no
  const [isExpanded, setIsExpanded] = useState(false);

  // Expande el sidebar al pasar el mouse por encima
  const handleMouseEnter = () => setIsExpanded(true);
  // Contrae el sidebar al quitar el mouse
  const handleMouseLeave = () => setIsExpanded(false);

  return (
    <div
      className={`sidebar${isExpanded ? ' expanded' : ''}`}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {/* Aquí se muestra siempre el perfil */}
      <div className="sidebar-profile">
        <ProfileCard />
      </div>

      {/* Navegación del sidebar */}
      <nav className="sidebar-nav">
        <ul>
          {/* Enlace a la página principal del administrador */}
          <li>
            <Link to="/AdminHome">
              <FontAwesomeIcon icon={faHouse} className="icon" />
              {isExpanded && <span className="label">Home</span>}
            </Link>
          </li>
          
          {/* Enlace a la sección de clientes */}
          <li>
            <Link to="/Customers">
              <FontAwesomeIcon icon={faUsers} className="icon" />
              {isExpanded && <span className="label">Customers</span>}
            </Link>
          </li>

          {/* Enlace a la sección de productos */}
          <li>
            <Link to="/Products">
              <FontAwesomeIcon icon={faBreadSlice} className="icon" />
              {isExpanded && <span className="label">Products</span>}
            </Link>
          {/* Subenlace a la sección de proveedores (mal indentado, pero válido) */}
          <li>
            <Link to="/Suppliers">
              <FontAwesomeIcon icon={faTruck} className="icon" />
              {isExpanded && <span className="label">Proverdores</span>}
            </Link>
          </li>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default Sidebar;
