// frontend/src/Components/Customers/editCustomer/EditCustomer.tsx
// Hooks de React
import React, { useEffect, useState } from 'react';
// Hook para obtener parámetros de la URL y componente de navegación
import { useParams, Link } from 'react-router-dom';
// Sidebar del menú
import Menu from '../../Sidebar/Sidebar';
// Librería para mostrar alertas bonitas
import Swal from 'sweetalert2';
// CSS de SweetAlert
import 'sweetalert2/dist/sweetalert2.min.css';
// Iconos de FontAwesome
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// Iconos específicos
import { faPenToSquare, faTrash } from '@fortawesome/free-solid-svg-icons';
// Estilos CSS para este componente
import './editCustomer.css';
// import './listCustomersRemove.css';


// Definición de interfaz para representar un usuario
interface User {
  User_id: number;
  UserName: string;
  Email: string;
  Password: string;
}

// Interfaz que representa un pedido
interface Order {
  Order_id: number;
  Name: string;
  Surname: string;
  Adress: string;
  PostalCode: string;
  Country: string;
  OrderDate: string;
  State: string;
}

// Interfaz para representar un país
interface Country {
  Country_id: number;
  CountryName: string;
}

// Interfaz para representar los datos de un cliente
interface CustomerData {
  Customer_id: number;
  Name: string;
  Surname: string;
  Phone: string;
  Adress: string;
  Country: string;
  PostalCode: string;
}


// Componente principal para editar un cliente
const EditCustomer: React.FC = () => {
  // Obtenemos el parámetro 'id' de la URL
  const { id } = useParams<{ id: string }>();

  // Obtenemos el parámetro 'id' de la URL
  const storedUser = localStorage.getItem('user');
  const user = storedUser ? JSON.parse(storedUser) : null;
  // ID del usuario que inició sesión
  const user_id = user.userId

  // Estado inicial del cliente
  const [customer, setCustomer] = useState<CustomerData>({
    Customer_id: 0,
    Name: '',
    Surname: '',
    Phone: '',
    Adress: '',
    Country: '',
    PostalCode: '',
  });

  // Estados para usuarios, pedidos, países, etc.
  const [users, setUsers] = useState<User[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [countries, setCountries] = useState<Country[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  // Se ejecuta al cargar el componente
  useEffect(() => {
    Promise.all([
      fetchCustomer(),
      fetchCountries(),
      fetchUsers(),
      fetchOrders(),
    ]).finally(() => setLoading(false));
  }, [id]);

  // Obtiene los datos del cliente desde la API
  const fetchCustomer = async () => {
    try {
      // PETICION
      const res = await fetch(`http://localhost:8000/Customers/${id}`);
      if (!res.ok) throw new Error('Error al cargar datos del cliente');
      const data: CustomerData = await res.json();
      setCustomer(data);
    } catch (e: unknown) {
      if (e instanceof Error) {
        setError(e.message);
      } else {
        setError('Error desconocido al cargar datos del cliente');
      }
    }
  };

  // Obtiene la lista de países
  const fetchCountries = async () => {
    try {
      const res = await fetch('http://localhost:8000/Countries');
      if (!res.ok) throw new Error('Error al cargar países');
      const data: Country[] = await res.json();
      setCountries(data);
    } catch { /* ignorar */ }
  };

  // Obtiene los usuarios relacionados con el cliente
  const fetchUsers = async () => {
    try {
      const res = await fetch(`http://localhost:8000/Customers/getCustomer_User/${id}`);
      if (!res.ok) throw new Error('Error al cargar usuarios asociados');
      const data: User[] = await res.json();
      setUsers(data);
    } catch { /* ignorar */ }
  };

  // Obtiene los pedidos relacionados con el cliente
  const fetchOrders = async () => {
    try {
      const res = await fetch(`http://localhost:8000/Customers/getCustomer_OrderById/${id}`);
      if (!res.ok) throw new Error('Error al cargar pedidos asociados');
      const data: Order[] = await res.json();
      setOrders(data);
    } catch { /* ignorar */ }
  };

  // Función que se ejecuta al enviar el formulario
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Confirmación con SweetAlert
    const result = await Swal.fire({
      title: '¿Confirmas la edición?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Sí, actualizar',
      cancelButtonText: 'Cancelar',
    });
    if (!result.isConfirmed) return;

    try {
      // Petición PUT para actualizar cliente
      const res = await fetch(`http://localhost:8000/Customers/updateCustomer/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(customer),
      });
      if (!res.ok) throw new Error('Error al actualizar cliente');
      setSuccess(true);
      fetchCustomer();
    } catch {
      setError('No se pudo actualizar');
    }
  };

  // Elimina un usuario asociado al cliente
  const handleDeleteUser = async (userId: number) => {
    const result = await Swal.fire({
      title: '¿Eliminar usuario?',
      text: 'Esta acción no se puede deshacer',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
    });
    if (!result.isConfirmed) return;

    try {
      const res = await fetch(`http://localhost:8000/Customers/deleteCustomer_User/${userId}`, {
        method: 'DELETE',
      });
      if (!res.ok) throw new Error('Error al eliminar usuario');
      fetchUsers();
    } catch {
      Swal.fire('Error', 'No se pudo eliminar el usuario', 'error');
    }
  };


  


  // Elimina un pedido asociado al cliente
  const handleDeleteCustomer_Order = async (orderId: number) => {
    const { isConfirmed } = await Swal.fire({
      title: '¿Eliminar Pedido?',
      text: 'Esta acción no se puede deshacer',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
    });
    if (!isConfirmed) return;

    // Petición DELETE para eliminar el pedido
    try {
      const res = await fetch(
        `http://localhost:8000/Customers/deleteCustomer_Order/${orderId}`,
        { method: 'DELETE' }
      );
      if (!res.ok) throw new Error('Error al eliminar el pedido');
      await fetchOrders();    
      Swal.fire('¡Listo!', 'Pedido eliminado correctamente', 'success');
    } catch (err: unknown) {
      const errorMessage =
        err instanceof Error ? err.message : 'No se pudo eliminar el pedido';
      Swal.fire('Error', errorMessage, 'error');
    }
  };



  // Vista si está cargando
  if (loading) return <div className="content-container">Cargando...</div>;
  if (error)   return <div className="content-container">Error: {error}</div>;

  return (
    <div className="content-container">
      <Menu />
      <div className="edit-customer-wrapper">
        <div className="inner">
          <div className="page-title">Editar Cliente</div>

          <form className="edit-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Nombre</label>
              <input
                type="text"
                value={customer.Name}
                onChange={e => setCustomer({ ...customer, Name: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Apellido</label>
              <input
                type="text"
                value={customer.Surname}
                onChange={e => setCustomer({ ...customer, Surname: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Teléfono</label>
              <input
                type="text"
                value={customer.Phone}
                onChange={e => setCustomer({ ...customer, Phone: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label>Dirección</label>
              <input
                type="text"
                value={customer.Adress}
                onChange={e => setCustomer({ ...customer, Adress: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label>País</label>
              <select
                value={customer.Country}
                onChange={e => setCustomer({ ...customer, Country: e.target.value })}
              >
                <option value="">Selecciona un país</option>
                {countries.map(c => (
                  <option key={c.Country_id} value={c.CountryName}>
                    {c.CountryName}
                  </option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label>Código Postal</label>
              <input
                type="text"
                value={customer.PostalCode}
                onChange={e => setCustomer({ ...customer, PostalCode: e.target.value })}
              />
            </div>

            <div className="form-actions">
              <Link to="/Customers">
                <button type="button" className="btn-back">Back</button>
              </Link>
              <button type="submit" className="btn-submit">Actualizar Cliente</button>
            </div>

            {success && <p className="text-green-600 mt-2">Cliente actualizado correctamente</p>}
          </form>

          <div className="subtable-container">
            <h2>Usuarios Asociados</h2>
            <table>
              <thead>
                <tr>
                  <th>User ID</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Password</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {users.map(u => (
                  <tr key={u.User_id}>
                    <td>{u.User_id}</td>
                    <td>{u.UserName}</td>
                    <td>{u.Email}</td>
                    <td>{u.Password}</td>
                  <td className="actions-cell">
                    <Link to={`/Customers/editCustomer_User/${u.User_id}`}>
                      <button className="btn-edit">
                        <FontAwesomeIcon icon={faPenToSquare} />
                      </button>
                    </Link>
                    <button
                      className="btn-delete"
                      onClick={() => handleDeleteUser(u.User_id)}
                    >
                      <FontAwesomeIcon icon={faTrash} />
                    </button>
                  </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="subtable-container">
            <h2>Pedidos Asociados</h2>
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Surname</th>
                  <th>Address</th>
                  <th>Postal Code</th>
                  <th>Country</th>
                  <th>Order Date</th>
                  <th>State</th>
                  <th>Acciones</th>
                </tr>
              </thead>
                <tbody>
                  {orders.map(o => (
                    <tr key={o.Order_id}>
                      <td>{o.Name}</td>
                      <td>{o.Surname}</td>
                      <td>{o.Adress}</td>
                      <td>{o.PostalCode}</td>
                      <td>{o.Country}</td>
                      <td>{new Date(o.OrderDate).toLocaleString('es-ES')}</td>
                      <td>{o.State}</td>
                      <td className="actions-cell">
                        <button
                          className="btn-delete"
                          onClick={() => handleDeleteCustomer_Order(o.Order_id)}  
                        >
                          <FontAwesomeIcon icon={faTrash} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
            </table>
          </div>
            <Link to={`/Customers/addCustomer_User/${id}`}>
                      <button>ADD USER FOR CUSTOMER</button>
            </Link>
        </div>
      </div>
    </div>
  );
};

export default EditCustomer;
