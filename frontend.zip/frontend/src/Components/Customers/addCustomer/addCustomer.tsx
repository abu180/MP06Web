// Importación de dependencias necesarias
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
// // Notificaciones tipo toast
import toast, { Toaster } from 'react-hot-toast';
// // Alerta tipo modal
import Swal from 'sweetalert2';
// Estilos para SweetAlert
import 'sweetalert2/dist/sweetalert2.min.css';
// // Componente del menú lateral
import Menu from '../../Sidebar/Sidebar';
// Estilos del formulario
import './addCustomer.css';

// Definición del tipo para los países
type Country = {
  Country_id: number;
  CountryName: string;
};

const AddCustomer: React.FC = () => {
    // Estados para los campos del formulario
  const [Name, setName] = useState('');
  const [Surname, setSurname] = useState('');
  const [Phone, setPhone] = useState('');
  const [Adress, setAdress] = useState('');
  const [Country, setCountry] = useState('');
  const [PostalCode, setPostalCode] = useState('');

  // Estado para almacenar la lista de países
  const [countries, setCountries] = useState<Country[]>([]);
  // Hook de navegación para redireccionar entre rutas
  const navigate = useNavigate();

  // Hook que se ejecuta al cargar el componente para obtener la lista de países
  useEffect(() => {
    const fetchCountries = async () => {
      try {
        const res = await fetch('http://localhost:8000/Countries');
        if (!res.ok) throw new Error('Error al obtener los países');
        const data: Country[] = await res.json();
        // Guardar países en el estado
        setCountries(data);
      } catch (e) {
        // Mostrar error en consola si la petición falla
        console.error(e);
      }
    };
    fetchCountries();
  }, []);

  
  // Función que se ejecuta al enviar el formulario
  const handleSubmit = async (e: React.FormEvent) => {
    // Prevenir recarga de la página
    e.preventDefault();
    try {
      // Enviar los datos del cliente al backend
      const res = await fetch('http://localhost:8000/Customers/addCustomer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ Name, Surname, Phone, Adress, Country, PostalCode }),
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Error al agregar el cliente');

      // Mostrar notificación de éxito
      toast.success('Cliente agregado con éxito');

      // Limpiar los campos del formulario
      setName('');
      setSurname('');
      setPhone('');
      setAdress('');
      setCountry('');
      setPostalCode('');

      // Obtener el ID del cliente agregado
      const id = json.Customer_id;

      // Preguntar si se desea añadir un usuario para este cliente
      const result = await Swal.fire({
        title: '¿Agregar usuario?',
        text: '¿Quieres agregar un usuario al cliente ahora?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí, agregar',
        cancelButtonText: 'No',
        confirmButtonColor: '#8c6239',
        cancelButtonColor: '#6c757d',
      });

      // Redirigir a la página para añadir usuario si se confirmó
      if (result.isConfirmed) {
        navigate(`/Customers/addCustomer_User/${id}`);
      }

    } catch (err: unknown) {
      // Manejo de errores y notificación al usuario
      if (err instanceof Error) {
        toast.error(err.message);
      } else {
        toast.error('Error desconocido');
      }
    }
  };

return (
  <div className="addCustomer__container">
    {/* Componente para mostrar los toasts */}
    <Toaster position="top-center" reverseOrder={false} />
    {/* Menú lateral */}
    <Menu />
    {/* Título de la página */}
    <h1 className="addCustomer__header">Agregar Cliente</h1>

    {/* Formulario para añadir un cliente */}
    <form className="addCustomer__form" onSubmit={handleSubmit}>
      {/* Campo: Nombre */}
      <div className="addCustomer__form-group">
        <label className="addCustomer__label">Nombre</label>
        <input
          className="addCustomer__input"
          type="text"
          value={Name}
          onChange={e => setName(e.target.value)}
          required
        />
      </div>
      
      {/* Campo: Apellido */}
      <div className="addCustomer__form-group">
        <label className="addCustomer__label">Apellido</label>
        <input
          className="addCustomer__input"
          type="text"
          value={Surname}
          onChange={e => setSurname(e.target.value)}
          required
        />
      </div>

      {/* Campo: Teléfono */}
      <div className="addCustomer__form-group">
        <label className="addCustomer__label">Teléfono</label>
        <input
          className="addCustomer__input"
          type="text"
          value={Phone}
          onChange={e => setPhone(e.target.value)}
          required
        />
      </div>

      {/* Campo: Dirección */}
      <div className="addCustomer__form-group">
        <label className="addCustomer__label">Dirección</label>
        <input
          className="addCustomer__input"
          type="text"
          value={Adress}
          onChange={e => setAdress(e.target.value)}
          required
        />
      </div>

      {/* Campo: País (desplegable) */}
      <div className="addCustomer__form-group">
        <label className="addCustomer__label">País</label>
        <select
          className="addCustomer__select"
          value={Country}
          onChange={e => setCountry(e.target.value)}
          required
        >
          <option value="">Selecciona un país</option>
          {countries.map(c => (
            <option key={c.Country_id} value={c.CountryName}>
              {c.CountryName}
            </option>
          ))}
        </select>
      </div>

      {/* Campo: Código Postal */}
      <div className="addCustomer__form-group">
        <label className="addCustomer__label">Código Postal</label>
        <input
          className="addCustomer__input"
          type="text"
          value={PostalCode}
          onChange={e => setPostalCode(e.target.value)}
          required
        />
      </div>

      {/* Botones del formulario */}
      <div className="addCustomer__actions">
        <Link to="/Customers">
          <button
            type="button"
            className="addCustomer__btn-back"
          >
            Volver
          </button>
        </Link>
        <button
          type="submit"
          className="addCustomer__btn-submit"
        >
          Añadir Cliente
        </button>
      </div>
    </form>
  </div>
);

};

export default AddCustomer;
