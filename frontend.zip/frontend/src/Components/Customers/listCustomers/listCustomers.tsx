// frontend/src/Components/Customers/listCustomers/ListCustomers.tsx
// Importación de módulos de React y librerías externas
import React, { useEffect, useState } from 'react';
// Para navegación entre rutas
import { Link } from 'react-router-dom';
// Para notificaciones
import toast, { Toaster } from 'react-hot-toast';
// Para ventanas de confirmación
import Swal from 'sweetalert2';
// Estilos de SweetAlert
import 'sweetalert2/dist/sweetalert2.min.css';
// Estilos generales
import "../../Styles/ListCommon.css";

// Importación correcta de tu CSS de estilos específicos
import './listCustomers.css';

// Importación del sidebar
import Menu from '../../../Components/Sidebar/Sidebar';

// Importación de iconos de FontAwesome
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// Iconos para editar y eliminar
import { faPenToSquare, faTrash } from '@fortawesome/free-solid-svg-icons';

// Definición de la interfaz de un cliente
interface Customer {
  Customer_id: number;
  Name: string;
  Surname: string;
  Phone: string;
  Adress: string;
  Country: string;
  PostalCode: string;
  is_active: number | null;
}


// Componente principal
const ListCustomers: React.FC = () => {
  // Estados del componente
  const [customers, setCustomers] = useState<Customer[]>([]);
  // Para mostrar mensaje de carga
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  // Número de clientes inactivos
  const [inactiveCount, setInactiveCount] = useState(0);

  // Paginación
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);

  // Función para obtener clientes activos
  const fetchCustomers = async () => {
    try {
      const resp = await fetch('http://localhost:8000/Customers');
      if (!resp.ok) throw new Error('Error al obtener los clientes');
      const data: Customer[] = await resp.json();
      // Filtrar clientes activos o con estado nulo
      const activos = data.filter(c => c.is_active === 1 || c.is_active === null);
      setCustomers(activos);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Error desconocido');
    } finally {
      setLoading(false);
    }
  };

  // Función para contar clientes dados de baja (inactivos)
  const fetchRemovedCount = async () => {
    try {
      const resp = await fetch('http://localhost:8000/Customers/removed');
      if (!resp.ok) throw new Error('Error al obtener los clientes de baja');
      const txt = await resp.text();
      const data: Customer[] = txt ? JSON.parse(txt) : [];
      setInactiveCount(data.length);
    } catch {
      setInactiveCount(0);
    }
  };

  // Comprobar si un cliente tiene pedidos asociados
  const checkIfCustomerHasOrders = async (id: number): Promise<boolean> => {
    try {
      const resp = await fetch(`http://localhost:8000/Customers/getCustomer_OrderById/${id}`);
      if (!resp.ok) throw new Error('Error al comprobar pedidos');
      const orders = await resp.json();
      return orders.length > 0;
    } catch {
      return true;
    }
  };

  // Eliminar cliente (soft delete)
  const handleDelete = async (id: number) => {
    const { isConfirmed } = await Swal.fire({
      title: '¿Estás seguro?',
      text: 'Esta acción desactivará el cliente',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#dc3545',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar'
    });
    if (!isConfirmed) return;

    // Verifica si el cliente tiene pedidos
    if (await checkIfCustomerHasOrders(id)) {
      Swal.fire({
        icon: 'error',
        title: 'No se puede eliminar',
        text: 'Este cliente tiene pedidos asociados.'
      });
      return;
    }

    // Realiza la desactivación del cliente
    try {
      const res = await fetch(`http://localhost:8000/Customers/softDeleteCustomer/${id}`, { method: 'PUT' });
      if (!res.ok) throw new Error('Error al desactivar el cliente');
      
      // Desactiva también la relación cliente-usuario
      await fetch(`http://localhost:8000/Customers/softDeleteUser_Customer/${id}`, { method: 'PUT' });
      
      // Refresca los datos
      await fetchCustomers();
      await fetchRemovedCount();

      // Notificación de éxito
      toast.success('Cliente desactivado con éxito', { icon: '🗑️' });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'No se pudo desactivar el cliente';
      toast.error(message, { icon: '❌' });
    }
  };

  // Llamar funciones al cargar el componente
  useEffect(() => {
    fetchCustomers();
    fetchRemovedCount();
  }, []);

  // Cálculos para paginación
  const last = currentPage * rowsPerPage;
  const first = last - rowsPerPage;
  const visible = customers.slice(first, last);
  const totalPages = Math.ceil(customers.length / rowsPerPage);

  // Mostrar mensaje de carga o error
  if (loading) return <div className="customers-container">Cargando clientes...</div>;
  if (error)   return <div className="customers-container">Error: {error}</div>;

  return (
    <div className="customers-container">
      <Toaster position="top-center" reverseOrder={false} />
      <Menu />
      <h1 className="customers-header">CUSTOMERS</h1>

      <div className="status-buttons">
        <Link to="/Customers/removed">
          <button className="status-btn inactive">
            Clientes de baja ({inactiveCount})
          </button>
        </Link>
        <Link to="/Customers">
          <button className="status-btn active">
            Clientes activos ({customers.length})
          </button>
        </Link>
      </div>

      <div className="table-container">
        <table className="list-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Nombre</th>
              <th>Apellido</th>
              <th>Teléfono</th>
              <th>Dirección</th>
              <th>País</th>
              <th>Código Postal</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {visible.map(c => (
              <tr key={c.Customer_id}>
                <td>{c.Customer_id}</td>
                <td>{c.Name}</td>
                <td>{c.Surname}</td>
                <td>{c.Phone}</td>
                <td>{c.Adress}</td>
                <td>{c.Country}</td>
                <td>{c.PostalCode}</td>
                <td className="actions-cell">
                  <Link to={`/Customers/editCustomer/${c.Customer_id}`}>
                    <button className="btn-edit">
                      <FontAwesomeIcon icon={faPenToSquare} />
                    </button>
                  </Link>
                  <button className="btn-delete" onClick={() => handleDelete(c.Customer_id)}>
                    <FontAwesomeIcon icon={faTrash} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="add-below">
        <Link to="/Customers/addCustomer">
          <button className="btn-add-customer">+ Añadir Cliente</button>
        </Link>
      </div>

      <div className="pagination">
        <label>
          Filas por página:&nbsp;
          <select
            value={rowsPerPage}
            onChange={e => { setRowsPerPage(+e.target.value); setCurrentPage(1); }}
          >
            {[5,10,25,50,100].map(n => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>
        </label>
        <button onClick={() => setCurrentPage(p => Math.max(1, p-1))} disabled={currentPage===1}>
          Prev
        </button>
        <span>Página {currentPage} de {totalPages}</span>
        <button onClick={() => setCurrentPage(p => Math.min(totalPages, p+1))} disabled={currentPage===totalPages}>
          Next
        </button>
      </div>
    </div>
  );
};

export default ListCustomers;
