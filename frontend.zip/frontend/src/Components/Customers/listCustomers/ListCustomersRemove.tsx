// frontend/src/Components/Customers/listCustomers/ListCustomersRemove.tsx
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import toast, { Toaster } from 'react-hot-toast';
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';
import './listCustomersRemove.css';
import Menu from '../../../Components/Sidebar/Sidebar';
// Componente de menú lateral
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserPlus } from '@fortawesome/free-solid-svg-icons';

// Definición de la interfaz de un cliente
interface Customer {
  Customer_id: number;
  Name: string;
  Surname: string;
  Phone: string;
  Adress: string;
  Country: string;
  PostalCode: string;
  is_active: number | null;
}


// Componente para listar clientes eliminados y reactivarlos
const ListCustomersRemove: React.FC = () => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [inactiveCount, setInactiveCount] = useState(0);
  const [activeCount, setActiveCount] = useState(0);

  // Paginación , para mostrar 5 filas por página
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);

  // Carga de datos
  const fetchRemoved = async () => {
    try {
      const res = await fetch('http://localhost:8000/Customers/removed');
      if (!res.ok) throw new Error('Error al obtener clientes eliminados');
      const data: Customer[] = await res.json();
      setCustomers(data);
      setInactiveCount(data.length);
      setError(null);
    } catch (e: unknown) {
      if (e instanceof Error) {
        setError(e.message);
      } else {
        setError('Ocurrió un error desconocido');
      }
    } finally {
      setLoading(false);
    }
  };

  // Carga de clientes activos
  // Función para obtener y contar clientes activos 
  const fetchCustomers = async () => {
    try {
      const resp = await fetch('http://localhost:8000/Customers');
      if (!resp.ok) throw new Error('Error al obtener los clientes');
      const data: Customer[] = await resp.json();
      // Filtrar sólo los clientes activos o con estado nulo
      const activos = data.filter(c => c.is_active === 1 || c.is_active === null);
      setActiveCount(activos.length);
    } catch (e: unknown) {
      console.error(e);
    }
  };


  // Efecto para cargar los datos al montar el componente
  // y para actualizar el número de clientes activos
  // al reactivar un cliente
  // Se usa el segundo efecto para evitar que se llame a la API de clientes activos
  useEffect(() => {
    fetchRemoved();
    fetchCustomers();
  }, []);


  // Paginación slicing , para mostrar sólo las filas necesarias
  // Se usa el estado de filas por página y la página actual
  const indexOfLast = currentPage * rowsPerPage;
  const indexOfFirst = indexOfLast - rowsPerPage;
  const currentCustomers = customers.slice(indexOfFirst, indexOfLast);
  const totalPages = Math.ceil(customers.length / rowsPerPage);

  // Funciones para manejar la paginación
  const handlePageChange = (newPage: number) => {
    if (newPage < 1 || newPage > totalPages) return;
    setCurrentPage(newPage);
  };

  // Cambia el número de filas por página y reinicia la página actual a 1
  const handleRowsPerPageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setRowsPerPage(Number(e.target.value));
    setCurrentPage(1);
  };

  // Reactivar cliente 
  const handleRevive = async (id: number) => {
    const { isConfirmed } = await Swal.fire({
      title: '¿Dar de alta este cliente?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Sí, activar',
      cancelButtonText: 'Cancelar',
      confirmButtonColor: '#a06e58',  // marrón medio
      cancelButtonColor: '#6c757d',
    });
    if (!isConfirmed) return;

    // Comprobar si el cliente tiene pedidos asociados
    try {
      const res = await fetch(
        `http://localhost:8000/Customers/activateCustomer/${id}`,
        { method: 'PUT' }
      );
      if (!res.ok) throw new Error('Error al activar cliente');

      // Reactiva también la relación usuario-cliente
      await fetch(
        `http://localhost:8000/Customers/activateUser_Customer/${id}`,
        { method: 'PUT' }
      );

      // Actualiza la lista de clientes eliminados y el número de clientes activos
      await fetchRemoved();
      await fetchCustomers();
      toast.success('Cliente reactivado correctamente', { icon: '✅' });
    } catch (e: unknown) {
      if (e instanceof Error) {
        toast.error(e.message || 'No se pudo reactivar', { icon: '❌' });
        setError(e.message);
      } else {
        toast.error('No se pudo reactivar', { icon: '❌' });
        setError('Ocurrió un error desconocido');
      }
    }
  };

  // Renderiza el componente
  if (loading) return <div className="customersRemove-container">Cargando clientes eliminados…</div>;
  if (error)   return <div className="customersRemove-container">Error: {error}</div>;

  return (
    <div className="customersRemove-container">
      <Toaster position="top-center" reverseOrder={false} />
      <Menu />

      <h1 className="customersRemove-header">CLIENTES ELIMINADOS</h1>

      <div className="status-buttons">
        <Link to="/Customers">
          <button className="status-btn active">
            Clientes activos ({activeCount})
          </button>
        </Link>
        <button className="status-btn inactive">
          Clientes de baja ({inactiveCount})
        </button>
      </div>

      <div className="table-container">
        {currentCustomers.length === 0 ? (
          <p className="no-data">No hay clientes eliminados.</p>
        ) : (
          <table className="list-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Teléfono</th>
                <th>Dirección</th>
                <th>País</th>
                <th>Código Postal</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {currentCustomers.map(c => (
                <tr key={c.Customer_id}>
                  <td>{c.Customer_id}</td>
                  <td>{c.Name}</td>
                  <td>{c.Surname}</td>
                  <td>{c.Phone}</td>
                  <td>{c.Adress}</td>
                  <td>{c.Country}</td>
                  <td>{c.PostalCode}</td>
                  <td className="actions-cell">
                    <button
                      className="btn-action btn-revive"
                      onClick={() => handleRevive(c.Customer_id)}
                    >
                      <FontAwesomeIcon icon={faUserPlus} /> Reactivar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Paginación */}
      <div className="pagination">
        <label>
          Filas por página:&nbsp;
          <select value={rowsPerPage} onChange={handleRowsPerPageChange}>
            {[5, 10, 25, 50, 100].map(n => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>
        </label>
        <button onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1}>
          Prev
        </button>
        <span>Página {currentPage} de {totalPages}</span>
        <button onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages}>
          Next
        </button>
      </div>
    </div>
  );
};

export default ListCustomersRemove;
