// src/Components/Perfil/Perfil.tsx
import React from 'react';
// Importación de componentes y hooks necesarios
import ProfileCard from './ProfileCard';
// Importación de componentes y hooks necesarios
import { useAuth } from '../Login/Auth/useAuth';
// Importación de estilos CSS
import './Perfil.css';

// Componente funcional para el perfil del usuario
const Perfil: React.FC = () => {
  const { user } = useAuth();

  // Si no hay usuario, puedes redirigir o mostrar nada.
  if (!user) return null;

  return (
    <div className="perfil-container">
        <ProfileCard />
    </div>
  );
};

export default Perfil;