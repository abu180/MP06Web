import './NavBar.css';
import { useState} from 'react';
import { useNavigate } from 'react-router-dom';
// Componente funcional de la barra de navegaciónimport { useNavigate } from 'react-router-dom';
import { FaSearch } from 'react-icons/fa';
import { IoBagHandleOutline } from "react-icons/io5";
// import { CgProfile } from 'react-icons/cg'
import SearchBar from "../SearchBar/SearchBar";
import Perfil from '../Perfil/Perfil';
// import ProfileCard from '../Perfil/ProfileCard';

// Componente funcional de la barra de navegación
function NavBar() {
    const navigate = useNavigate();
    const [isOpen, setIsOpen] = useState(false);

    return (
        /* CONTENEDOR GENERAL DEL MENÚ */
        <section className='NavBarSection-Container'>
            {/* CONTENEDOR PARA EL LOGO */}
            <div className='NavBarLogo-Container'>
                <img src='/MigaMiaLogo.png' onClick={() => navigate('/UserHome')} /> 
            </div>
            {/* CONTENEDOR GENERAL PARA LOS BOTONES */}
            <div className='NavBarButtonsSection-Container'>
                {/* CONTENEDOR PARA LOS BOTONES */}
                <div className='NavBarButtons-Container'>
                    {/* CONTENEDOR PARA EL BOTON DE CATÁLOGO */}
                    <div className='NavBarButtonCatalog-Container'>
                        <button onClick={() => navigate('/ProductsPage')}>CATÁLOGO</button>
                    </div>
                    {/* CONTENEDOR PARA EL BOTON DE SOBRE NOSOTROS */}
                    <div className='NavBarButtonAboutUs-Container'>
                        <button onClick={() => navigate('/AboutUs')}>SOBRE NOSOTROS</button>
                    </div>
                    {/* CONTENEDOR PARA EL BOTON DE CONTACTO */}
                    <div className='NavBarButtonContact-Container'>
                        <button onClick={() => navigate('/ContactUs')}>CONTACTO</button>
                    </div>
                </div>
                {/* CONTENEDOR PARA LA LUPA */}
                <div className='NavBarSearch-Container'>
                    <FaSearch className="search-icon" onClick={() => setIsOpen(!isOpen)} />
                    {isOpen && (
                        <div className='SearchBarOpened-Container'>
                            <SearchBar />
                        </div>
                    )}
                </div>

                {/* CONTENEDOR PARA EL CARRITO */}
                <div className='Cart-Container'>
                    <IoBagHandleOutline className='IoBagHandleOutline' onClick={() => navigate('/Cart')}/>
                </div>


                {/* CONTENEDOR PARA EL PERFIL */}
                <div className='NavBarProfile-Container'>
                    {/*<CgProfile className="cg-profile" onClick={() => setIsOpen(!isOpen)} />
                        {isOpen && (
                            <div className='ProfileOpened-Container'>
                                <ProfileCard />
                            </div>
                        )}*/}
                        <Perfil />
                </div>
            </div>
            
        </section>
    )
}

export default NavBar;