// Importación de estilos CSS para el componente
import './SearchBar.css';
// Importaciones necesarias desde React y librerías externas
import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

// Tipo para definir la estructura de los productos que se reciben del backend
type Product = {
    Product_id: number;
    ProductName: string;
};

// Componente funcional de barra de búsqueda
const SearchBar: React.FC = () => {
    // Estado local para la consulta del input
    const [query, setQuery] = useState("");
    // Estado para almacenar los resultados de búsqueda
    const [results, setResults] = useState<Product[]>([]);
    // Hook de navegación para redirigir a otras rutas
    const navigate = useNavigate();


    /*
        * Función que maneja el cambio en el input de búsqueda.
        * Si la consulta tiene más de 1 carácter, hace una solicitud al servidor para obtener los productos coincidentes.
    */
    const handleSearch = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setQuery(value);

        if (value.length > 1) {
            try {
                // Petición GET al backend con la query del usuario
                const response = await axios.get(`http://localhost:8000/products/search?q=${value}`);
                // Guarda los resultados en el estado
                setResults(response.data);
            } catch (error) {
                console.error("Error al buscar productos:", error);
            }
        } else {
            // Limpia los resultados si la consulta es muy corta
            setResults([]);
        }
    };

    /*
        * Función que se ejecuta al hacer clic sobre un producto en los resultados.
        * Limpia la barra de búsqueda y redirige a la página del producto seleccionado.
    */
    const handleSelect = (productName: string) => {
        // Vacía el input de búsqueda
        setQuery("");
        // Limpia los resultados
        setResults([]);
        // Navega a la página del producto
        navigate(`/products/${productName}`);
    };

    // Renderizado del componente
    return (
        <div className='SearchBar-Container'>
            <input
                type="text"
                placeholder="Buscar productos..."
                value={query}
                onChange={handleSearch}
            />
            
            {/* Si hay resultados, se muestran como una lista */}
            {results.length > 0 && (
                <ul className="ResultList">
                    {results.map((product) => (
                        <li key={product.Product_id} onClick={() => handleSelect(product.ProductName)}
                            style={{ padding: "5px", cursor: "pointer" }}>
                            {product.ProductName}
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

// Exportación del componente para su uso en otras partes de la aplicación
export default SearchBar;
