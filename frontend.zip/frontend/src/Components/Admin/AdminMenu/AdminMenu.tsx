// Importación del archivo de estilos específicos para el menú del administrador
import './AdminMenu.css';
// Importación de React para definir el componente
import React from 'react';
// Importación de Link de react-router-dom para la navegación entre rutas
import { Link } from 'react-router-dom';
// Importación del componente de perfil que se muestra en el menú
import Perfil from '../../Perfil/Perfil';


// Componente funcional que representa el menú lateral del administrador
function AdminMenu() {
    return (
        /* Contenedor principal del menú */
        <nav className='menu'>
            <h1 className="menu-title">¡WELKOME BACK!</h1>
            <div>
               { /* Lista de enlaces de navegación */}
                <ul className="menu-links">
                    <li>
                        {/* Enlace a la página principal del admin */}
                        <Link to="/AdminHome">HOME</Link>
                    </li>
                    <li>
                        {/* Enlaces a las secciones de gestión */}
                        <Link to="/Customers">CUSTOMERS</Link>
                        <Link to="/Products">PRODUCTS</Link>
                        <Link to="/Suppliers">SUPPLIERS</Link>
                    </li>
                </ul>
            </div>
            <div>
                {/* Componente de perfil que muestra información del usuario logueado */}
                <Perfil />
            </div>
        </nav>
    )
}

// Exportación del componente para su uso en otras partes de la aplicación
export default AdminMenu;