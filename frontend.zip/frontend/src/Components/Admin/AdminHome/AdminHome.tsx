// frontend/src/Components/Admin/AdminHome/AdminHome.tsx
import React from "react";
import ListOrders from "../../Orders/listOrders/listOrders";
import Sidebar from "../../Sidebar/Sidebar";

const AdminHome: React.FC = () => {
  return (
    <div className="admin-layout">
      {/* Sidebar a la izquierda */}
      <Sidebar />

      {/* Contenido principal a la derecha */}
      <main className="admin-content">
        <ListOrders />
      </main>
    </div>
  );
};

export default AdminHome;
