//Importa React y los hooks useState y useEffect.
import React, { useEffect, useState } from "react";
// Hook de React Router para redirigir a otras rutas del frontend de forma programática.
import { useNavigate } from "react-router-dom";

// Definen la estructura de los objetos utilizados:
interface Company {
    Company_id: number;
    CompanyName: string;
    SocialNumber: string;
    CompanyAdress: string;
}

interface Product {
    name: string;
    description: string;
    unit_price: number;
    quantity: number;
}

interface Customer {
    Customer_id: number;
    Name: string;
    Surname: string;
    Address: string;
}

// Componente funcional que utiliza React Hooks para gestionar estados y efectos.
const SuccessCheckout: React.FC = () => {
    const navigate = useNavigate();
    //Información de la empresa que emite la factura.
    const [company, setCompany] = useState<Company | null>(null);
    // Lista de productos comprados.
    const [products, setProducts] = useState<Product[]>([]);
    //Datos del cliente.
    const [customer, setCustomer] = useState<Customer | null>(null);


    // Realiza una petición GET para obtener los datos de la empresa desde el backend.
    const fetchCompany = async () => {
        try {
            const response = await fetch('http://localhost:8000/Company/getCompany');
            const data = await response.json();
            setCompany(data);
            console.log("Datos de la empresa:", data);
        } catch(error) {
            console.error('Error al obtener la empresa:', error);
        }
    }

    
    /*
        Extrae parámetros de la URL (products y customer) codificados en JSON.

        Llama a fetchCompany para obtener la empresa desde el backend.

        Se ejecuta solo una vez (al montar el componente). 

    */
    useEffect(() => {
        const params = new URLSearchParams(window.location.search);

        const productsParam = params.get('products');
        if (productsParam) {
            setProducts(JSON.parse(decodeURIComponent(productsParam)));
        }

        const customerParam = params.get('customer');
        if (customerParam) {
            setCustomer(JSON.parse(decodeURIComponent(customerParam)));
        }
        fetchCompany();
    }, []);

    return (
        <div>
            <h1>GRACIAS POR TU COMPRA</h1>
            <h2>DETALLES FACTURA</h2>

            {company && (
                <div key={company.Company_id}>
                    <p><strong>Nombre de la Empresa:</strong> {company.CompanyName}</p>
                    <p><strong>NIF:</strong> {company.SocialNumber}</p>
                    <p><strong>Dirección:</strong> {company.CompanyAdress}</p>
                </div>
            )}
            <h2>Detalles del Cliente:</h2>
            {customer && (
                <div>
                    <p><strong>Nombre:</strong> {customer.Name} {customer.Surname}</p>
                    <p><strong>Dirección:</strong> {customer.Address}</p>
                </div>
            )}
            <h2>Detalles de la Compra:</h2>
            <ul>
                {products.map((product, index) => (
                    <li key={index}>
                        <strong>{product.name}</strong> - {product.description} <br />
                        <p>IMPUESTO: <b>21%</b> {(product.unit_price * 21) / 10000}</p>
                        <p>PRECIO BASE: {product.unit_price / 100 - product.unit_price * 21 / 10000}€</p>
                        <p><b>TOTAL: {product.unit_price / 100}€</b></p>
                        <p>Cantidad: {product.quantity} unidades</p>
                        <p><b>SUBTOTAL {product.unit_price / 100 * product.quantity}</b>€</p>
                        <p><b>TRAJETA CF ENTREGADO: {product.unit_price / 100 * product.quantity}€ CAMBIO: 0,00€</b></p>
                    </li>
                ))}
            </ul>
            <button onClick={() => navigate('/UserHome')}>VOLVER</button>
        </div>
    );
};

export default SuccessCheckout;