// CSS
import './CancelCheckout.css';
// HOOK NAVEGACION
import { useNavigate } from 'react-router-dom';
// HOOK ESTADOS
import { useEffect, useState } from 'react';

// Define la forma de un objeto Product
interface Product {
    name: string;
    description: string;
    unit_price: number;
    quantity: number;
}

// FUNCION PRINCIPAL
const CancelCheckout: React.FC = () => {
    const navigate = useNavigate();
    //Estado que almacena los productos que estaban en proceso de compra.
    const [products, setProducts] = useState<Product[]>([]);
    
    // Extrae los productos que fueron enviados como parámetro en la URL (?products=...) al redirigir tras cancelar el pago.
    useEffect(() => {
        const params = new URLSearchParams(window.location.search);
        
        const productsParam = params.get('products');
            if (productsParam) {
                setProducts(JSON.parse(decodeURIComponent(productsParam)));
            }
    
            console.log("Productos cancelados:", products);
    }, []);

    return (
        <div>
            <h1>SE HA CANCELADO LA COMPRA</h1>

            <div>
            <h2>Detalles de la Compra:</h2>
            <ul>
                {products.map((product, index) => (
                    <li key={index}>
                        <strong>{product.name}</strong> - {product.description} <br />
                        <p>IMPUESTO: <b>21%</b> {(product.unit_price * 21) / 10000}</p>
                        <p>PRECIO BASE: {product.unit_price / 100 - product.unit_price * 21 / 10000}€</p>
                        <p><b>TOTAL: {product.unit_price / 100}€</b></p>
                        <p>Cantidad: {product.quantity} unidades</p>
                        <p><b>SUBTOTAL {product.unit_price / 100 * product.quantity}</b>€</p>
                        <p><b>TRAJETA CF ENTREGADO: {product.unit_price / 100 * product.quantity}€ CAMBIO: 0,00€</b></p>
                    </li>
                ))}
            </ul>
            </div>

            <h2>VUELVE PRONTO</h2>
            <button onClick={() => navigate('/UserHome')}>VOLVER</button>
        </div>
    )
}

export default CancelCheckout;