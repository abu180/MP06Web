// frontend/src/Components/Products/editProducts/EditProduct.tsx
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import Menu from '../../Sidebar/Sidebar';
// import '../../Styles/ListCommon.css';
import './editProducts.css';
// Importación de librerías para notificaciones
import Swal from 'sweetalert2';
// Importación de estilos para SweetAlert
import 'sweetalert2/dist/sweetalert2.min.css';
// Importación de iconos de FontAwesome
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// Iconos para editar y eliminar
import { faPencilAlt, faTrash } from '@fortawesome/free-solid-svg-icons';

// Definición de la interfaz de un producto
interface Supplier {
  Supplier_id: number;
  Ingredient: string;
  CompanyName: string;
  ContactName: string;
  Phone: string;
  Adress: string;
  Country: string;
  Postal_code: string;
}

// Definición de la interfaz de los datos del producto
interface ProductData {
  ProductName: string;
  UnitPrice: string;
  Quantity: string;
  UnitsOnOrder: string;
  ProductDescription: string;
}

//  Componente principal
const EditProduct: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<ProductData>({
    ProductName: '',
    UnitPrice: '',
    Quantity: '',
    UnitsOnOrder: '',
    ProductDescription: '',
  });
  //  Estado para almacenar la lista de proveedores
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  // Este error depende de las actualizacion de la dependencia
  const [success, setSuccess] = useState(false);

  // Carga inicial de producto
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`http://localhost:8000/Products/${id}`);
        if (!res.ok) throw new Error('Error al cargar datos del producto');
        setProduct(await res.json());
      } catch (e: any) {
        setError(e.message);
      }
    })();
  }, [id]);

  // Carga inicial de proveedores asociados
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`http://localhost:8000/Products/getProduct_Supplier/${id}`);
        if (!res.ok) throw new Error('Error al cargar proveedores');
        setSuppliers(await res.json());
      } catch {
        // ignorar
      } finally {
        setLoading(false);
      }
    })();
  }, [id]);

  // Manejo de cambios en el formulario
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setProduct(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };


  // Manejo del envío del formulario
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const { isConfirmed } = await Swal.fire({
      title: '¿Actualizar este producto?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Sí, guardar cambios',
      cancelButtonText: 'Cancelar',
    });
    if (!isConfirmed) return;

    // Validación de campos
    try {
      const res = await fetch(`http://localhost:8000/Products/updateProduct/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(product),
      });
      if (!res.ok) throw new Error('Error al actualizar');
      setSuccess(true);
      Swal.fire({
        icon: 'success',
        title: 'Producto actualizado',
        timer: 1500,
        showConfirmButton: false
      });
    } catch (e: unknown) {
      const errorMessage = e instanceof Error ? e.message : 'Error desconocido';
      setError(errorMessage);
      Swal.fire({
        icon: 'error',
        title: '¡Oops!',
        text: errorMessage || 'No se pudo actualizar'
      });
    }
  };

  // Manejo de eliminación de proveedores
  const handleDeleteSupplier = async (supplierId: number) => {
    const { isConfirmed } = await Swal.fire({
      title: '¿Eliminar este proveedor?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
    });
    if (!isConfirmed) return;

    // Validación de eliminación
    try {
      const resDel = await fetch(
        `http://localhost:8000/Products/deleteProduct_Supplier/${supplierId}`,
        { method: 'DELETE' }
      );
      if (!resDel.ok) throw new Error('Error al eliminar proveedor');

      // recargar lista
      const res = await fetch(`http://localhost:8000/Products/getProduct_Supplier/${id}`);
      setSuppliers(await res.json());
//      setSuccess(true);
      Swal.fire({
        icon: 'success',
        title: 'Proveedor eliminado',
        timer: 1200,
        showConfirmButton: false
      });
    } catch (e: unknown) {
      const errorMessage = e instanceof Error ? e.message : 'No se pudo eliminar';
      Swal.fire({
        icon: 'error',
        title: '¡Error!',
        text: errorMessage
      });
    }
  };

  // Manejo de errores y carga
  if (loading) return <div className="content-container">Cargando...</div>;
  if (error) return <div className="content-container">Error: {error}</div>;

return (
  <div className="editProduct__container">
    <Menu />

    {/* Header marrón ancho completo */}
    <h1 className="editProduct__header">Actualizar Producto</h1>

    {/* Tarjeta blanca centrada con el formulario */}
    <form className="editProduct__form" onSubmit={handleSubmit}>
      <div className="editProduct__group">
        <label className="editProduct__label">Nombre</label>
        <input
          className="editProduct__input"
          name="ProductName"
          type="text"
          value={product.ProductName}
          onChange={handleChange}
          required
        />
      </div>

      <div className="editProduct__group">
        <label className="editProduct__label">Precio Unidad (€)</label>
        <input
          className="editProduct__input"
          name="UnitPrice"
          type="number"
          step="0.01"
          value={product.UnitPrice}
          onChange={handleChange}
          required
        />
      </div>

      <div className="editProduct__group">
        <label className="editProduct__label">Stock</label>
        <input
          className="editProduct__input"
          name="Quantity"
          type="text"
          value={product.Quantity}
          onChange={handleChange}
        />
      </div>

      <div className="editProduct__group">
        <label className="editProduct__label">Cant. Pedida</label>
        <input
          className="editProduct__input"
          name="UnitsOnOrder"
          type="text"
          value={product.UnitsOnOrder}
          onChange={handleChange}
        />
      </div>

      <div className="editProduct__group">
        <label className="editProduct__label">Descripción</label>
        <input
          className="editProduct__input"
          name="ProductDescription"
          type="text"
          value={product.ProductDescription}
          onChange={handleChange}
        />
      </div>

      <div className="editProduct__actions">
        <Link to="/Products">
          <button type="button" className="editProduct__btn-back">
            Volver
          </button>
        </Link>
        <button type="submit" className="editProduct__btn-submit">
          Guardar Cambios
        </button>
      </div>
    </form>

    {/* Subtabla de proveedores */}
    <div className="editProduct__subtable">
      <h2 className="editProduct__subheader">Proveedores Asociados</h2>
      <table className="editProduct__table">
        <thead>
          <tr>
            <th>ID</th><th>Ingrediente</th><th>Empresa</th><th>Contacto</th>
            <th>Teléfono</th><th>Dirección</th><th>País</th><th>C.P.</th><th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {suppliers.map(s => (
            <tr key={s.Supplier_id}>
              <td>{s.Supplier_id}</td>
              <td>{s.Ingredient}</td>
              <td>{s.CompanyName}</td>
              <td>{s.ContactName}</td>
              <td>{s.Phone}</td>
              <td>{s.Adress}</td>
              <td>{s.Country}</td>
              <td>{s.Postal_code}</td>
              <td className="editProduct__cell-actions">
                <Link to={`/Products/editProduct_Supplier/${s.Supplier_id}`}>
                  <button className="editProduct__btn-edit">
                    <FontAwesomeIcon icon={faPencilAlt} />
                  </button>
                </Link>
                <button
                  className="editProduct__btn-delete"
                  onClick={() => handleDeleteSupplier(s.Supplier_id)}
                >
                  <FontAwesomeIcon icon={faTrash} />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <Link to={`/Products/addProduct_Supplier/${id}`}>
        <button className="editProduct__btn-add">Añadir Proveedor</button>
      </Link>
    </div>
  </div>
);

};

export default EditProduct;
