// frontend/src/Components/Products/addProducts/AddProduct.tsx
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Menu from '../../../Components/Sidebar/Sidebar';
import '../../Styles/ListCommon.css';
import './addProducts.css';

// Componente para agregar un producto
const AddProduct: React.FC = () => {
  const [ProductName,    setProductName]    = useState<string>('');
  const [UnitPrice,      setUnitPrice]      = useState<number>(0);
  const [Quantity,       setQuantity]       = useState<string>('');
  const [UnitsOnOrder,   setUnitsOnOrder]   = useState<string>('');
  const [Description,    setDescription]    = useState<string>('');
  const [image,          setImage]          = useState<File | null>(null);
  const [error,          setError]          = useState<string | null>(null);
  const [success,        setSuccess]        = useState<boolean>(false);

  // Maneja el cambio de imagen
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setImage(e.target.files?.[0] || null);
  };

  // Maneja el envío del formulario
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(false);

    if (!image) {
      setError('Por favor, selecciona una imagen.');
      return;
    }

    // FormData con los nombres que espera tu API
    const formData = new FormData();
    formData.append('ProductName',       ProductName);
    formData.append('UnitPrice',         UnitPrice.toString());
    formData.append('Quantity',          Quantity);
    formData.append('UnitsOnOrder',      UnitsOnOrder);
    formData.append('ProductDescription',Description);       // <-- cambio aquí
    formData.append('ProductImage',      image);             // o 'Image' si tu backend lo llama así

    // Enviar la solicitud al backend
    try {
      const res = await fetch('http://localhost:8000/Products/addProduct', {
        method: 'POST',
        body: formData
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || 'Error al agregar el producto');
      }
      setSuccess(true);
      // resetear formulario
      setProductName('');
      setUnitPrice(0);
      setQuantity('');
      setUnitsOnOrder('');
      setDescription('');
      setImage(null);
    } catch (e: unknown) {
      if (e instanceof Error) {
        setError(e.message);
      } else {
        setError('Error desconocido');
      }
    }
  };

return (
  <div className="addProduct__container">
    <Menu />

    {/* Header marrón ancho completo */}
    <h1 className="addProduct__header">Agregar Producto</h1>

    {/* Tarjeta blanca centrada */}
    <form className="addProduct__form" onSubmit={handleSubmit}>
      <div className="addProduct__group">
        <label className="addProduct__label">Nombre</label>
        <input
          className="addProduct__input"
          type="text"
          value={ProductName}
          onChange={e => setProductName(e.target.value)}
          required
        />
      </div>

      <div className="addProduct__group">
        <label className="addProduct__label">Precio Unidad</label>
        <input
          className="addProduct__input"
          type="number"
          step="0.01"
          value={UnitPrice}
          onChange={e => setUnitPrice(e.target.value === '' ? 0 : parseFloat(e.target.value))}
          required
        />
      </div>

      <div className="addProduct__group">
        <label className="addProduct__label">Stock</label>
        <input
          className="addProduct__input"
          type="text"
          value={Quantity}
          onChange={e => setQuantity(e.target.value)}
        />
      </div>

      <div className="addProduct__group">
        <label className="addProduct__label">Cant. Pedida</label>
        <input
          className="addProduct__input"
          type="text"
          value={UnitsOnOrder}
          onChange={e => setUnitsOnOrder(e.target.value)}
        />
      </div>

      <div className="addProduct__group">
        <label className="addProduct__label">Descripción</label>
        <textarea
          className="addProduct__textarea"
          value={Description}
          onChange={e => setDescription(e.target.value)}
          rows={3}
        />
      </div>

      <div className="addProduct__group">
        <label className="addProduct__label">Imagen del Producto</label>
        <input
          className="addProduct__input"
          type="file"
          accept="image/*"
          onChange={handleImageChange}
        />
      </div>

      <div className="addProduct__actions">
        <Link to="/Products">
          <button type="button" className="addProduct__btn-back">
            Volver
          </button>
        </Link>
        <button type="submit" className="addProduct__btn-submit">
          Añadir Producto
        </button>
      </div>

      {error && <p className="addProduct__error">{error}</p>}
      {success && <p className="addProduct__success">Producto agregado correctamente</p>}
    </form>
  </div>
);

};

export default AddProduct;
