import './StockBarProgress.css';
import React from "react";

// Componente para mostrar la barra de progreso del stock
const StockBarProgress: React.FC<{ quantity: number}> = ({ quantity }) => {
    return (
        <div className='StockBarProgress-Container'>
            <div className='StockBarProgress-StockContainer'>
                <p>Stock Disponible: {quantity}</p>
            </div>
            <div className='StockBarProgress-ProgressBar'>
                <div 
                    style={{
                        height: '100%',
                        width: `${Math.min(quantity * 10, 100)}%`,
                        backgroundColor: 
                            quantity <= 5
                                ? 'red'
                                : quantity <= 10
                                ? 'yellow'
                                : 'green',
                        transition: 'width 0.3s ease',
                    }}
                >
                </div>
            </div>
        </div>
    )
}

export default StockBarProgress;