import './Products.css';
//************ COMPONENTES ************/
import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";
import StockBarProgress from "../StockBarProgress/StockBarProgress";
import NavBar from '../../../NavBar/NavBar';

// Tipos de datos
type Product = {
    Product_id: number,
    ProductName: string, 
    UnitPrice: number,
    Quantity: number,
    UnitsOnOrder: number,
    ProductImage: string,
    ProductDescription: string,
}

// Componente de la página del producto
const ProductPage = () => {
    const storedUser = localStorage.getItem('user');
    const user = storedUser ? JSON.parse(storedUser) : null;
    const user_id = user.userId;
    console.log("ID del usuario:", user_id);
    // Obtenemos el nombre del producto de la URL
    const { productName } = useParams();
    console.log(productName);
    // Estado para almacenar el producto
    const [product, setProduct] = useState<Product | null>(null);
    const [quantity, setQuantity] = useState<number>(1);
    const incrementQuantity = () => setQuantity(q => q + 1);
    const decrementQuantity = () => setQuantity(q => q > 1 ? q -1 : 1);
    
    // Cargamos el producto al montar el componente
    useEffect(() => {
        const fetchProduct = async () => {
            try {
                const response = await axios.get(`http://localhost:8000/products/name/${productName}`)
                console.log("Respuesta del backend:", response.data);
                setProduct(response.data[0]);
            } catch (error) {
                console.error("Error al cargar el producto:", error);
            }
        };
        fetchProduct();
    }, [productName]);

    console.log(product);

    if(!product) {
        return <h2>Loading...</h2>
    }

    // Función para añadir el producto al carrito
    const handleAddToCart = async () => {
        try {
            await axios.post('http://localhost:8000/Cart/addToCart', {
                user_id: user_id,
                product_id: product.Product_id,
                quantity: quantity,
            });
            alert('Producto añadido al carrito');
        } catch (error) {
            console.error('Error al añadir el producto al carrito:', error);
        }
    };

    return (
        <section className="ProductSection-Container">
            <div className='ProductsNavBar-Container'>
                <NavBar />
            </div>
            <div className='ProductElements-Container'>
                <div className='ElementsSection-Container' key={product.Product_id}>
                    <div className='ProductsElementsImage-Container'>
                        <img src={`http://localhost:8000${product.ProductImage}`} />
                    </div>
                    <div className='ProductsElementsContent-Container'>
                        <div className='ProductsElementsName-Container'>
                            <h2>{product.ProductName}</h2>
                        </div>
                        <div className='ProductsElementsDescription-Container'>
                            <p>{product.ProductDescription}</p>
                        </div>
                        <div className='ProductsElementsPrice-Container'>
                            <p>{product.UnitPrice}</p>
                        </div>
                            
                        {/* BARRA DE PROGRESO PARA SEGUN EL STOCK DEL PRODUCTO */}
                        <div className='ProductsElementsStockCount-Container'>
                            <div className='ProductsElementsStock-Container'>
                                <StockBarProgress quantity={product.Quantity}/>
                            </div>
                            <div className='ProductsElementsCount-Container'>
                                <div className='Count-Container'>
                                    <button 
                                        onClick={decrementQuantity} 
                                        disabled={product.Quantity === 0}
                                    >
                                        -
                                    </button>
                                    <span style={{ color: '#ffffff' }}>{quantity}</span>
                                    <button 
                                        onClick={incrementQuantity} 
                                        style={{ padding: '5px 10px' }}
                                        disabled={product.Quantity === 0 || quantity >= product.Quantity}
                                    >
                                        +
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div className='AddToCartButton-Container'>
                            <button id="buttonAddToCart" onClick={handleAddToCart}>Añadir al Carrito</button>
                        </div>
                        {/*<button id="buttonCheckout" onClick={handleCheckout}>PAY</button>*/}
                    </div>           
                </div>
            </div>
        </section>
        
    );
};

export default ProductPage;