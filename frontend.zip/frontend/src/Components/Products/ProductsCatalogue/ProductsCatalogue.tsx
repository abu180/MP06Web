import './ProductsCatalogue.css';
import React, { useEffect, useState } from "react";
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import NavBar from '../../NavBar/NavBar';

// Tipo para definir la estructura de los productos que se reciben del backend
type Product = {
    Product_id: number,
    ProductName: string, 
    UnitPrice: number,
    ProductImage: string,
}

// Componente funcional de catálogo de productos
function ProductsCatalogue() {
    const [products, setProducts] = useState<Product[]>([]);

    const navigate = useNavigate();

// Hook para cargar los productos al montar el componente
    useEffect(() => {
        axios.get('http://localhost:8000/Products')
            .then(response => setProducts(response.data))
            .catch(error => console.error('Error al obtener los productos:', error))
    }, []);


    return (
        <section>
            <div className='ProductsNavBar-Container'>
                <NavBar />
            </div>  
            <div className="ProductsCatalogue-Container">
                <div className='Product-Container'>
                    {products.map(product => (

                        <div key={product.Product_id} className='Product-Card'>
                            <div className='Product-Card-Image'>
                                <img
                                    src={`http://localhost:8000${product.ProductImage}`}
                                    alt={product.ProductName}
                                />                         
                            </div>
                            <div className='Product-Card-Name'>
                                <h2>{product.ProductName}</h2>
                            </div>
                            <div className='Product-Card-Price'>
                                <p> {product.UnitPrice} €</p>
                            </div>
                            <div className='Product-Card-ViweDetails'>
                                <button onClick={() => navigate(`/products/${product.ProductName}`)}>VER</button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    )
}

export default ProductsCatalogue;