import './ProductsPage.css';
import ProductsCatalogue from "../ProductsCatalogue/ProductsCatalogue";

// Componente funcional de la página de productos
function ProductsPage() {
    return (
        <section className='Products-Catalogue-Container'>
            <ProductsCatalogue />
        </section>
    )
}

export default ProductsPage;