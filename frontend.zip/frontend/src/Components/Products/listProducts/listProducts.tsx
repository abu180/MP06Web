// frontend/src/Components/Products/listProducts/ListProducts.tsx
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import toast, { Toaster } from 'react-hot-toast';
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';
import Menu from '../../../Components/Sidebar/Sidebar';
import "../../Styles/ListCommon.css";
import './listProducts.css';
// Importación de librerías para notificaciones
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faTrash, faPlus } from '@fortawesome/free-solid-svg-icons';


// Importación de iconos de FontAwesome
interface Product {
  Product_id: number;
  ProductName: string;
  UnitPrice: string;
  Quantity: string;
  ProductDescription: string;
  UnitsOnOrder: string;
}

// Componente de la lista de productos
const ListProducts: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState<string | null>(null);

  //  PAGINACIÓN 
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);

  // Función para obtener los productos
  const fetchProducts = async () => {
    try {
      const res = await fetch('http://localhost:8000/Products');
      if (!res.ok) throw new Error('Error al obtener los productos');
      const data: Product[] = await res.json();
      setProducts(data);
      setError(null);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  // Función para eliminar un producto
  const handleDelete = async (id: number) => {
    const result = await Swal.fire({
      title: '¿Eliminar producto?',
      text: 'Esta acción no se puede deshacer',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#dc3545',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar'
    });
    if (!result.isConfirmed) return;

    try {
      const res = await fetch(`http://localhost:8000/Products/deleteProduct/${id}`, {
        method: 'DELETE'
      });
      if (!res.ok) throw new Error('Error al eliminar el producto');
      toast.success('Producto eliminado', { icon: '🗑️' });
      fetchProducts();
    } catch (e: any) {
      toast.error(e.message || 'No se pudo eliminar', { icon: '❌' });
    }
  };

  // CARGA DE PRODUCTOS AL INICIAR
  useEffect(() => {
    fetchProducts();
  }, []);

  // CÁLCULO DE PAGINACIÓN
  const totalPages = Math.ceil(products.length / rowsPerPage);
  const startIndex = (currentPage - 1) * rowsPerPage;
  const visible    = products.slice(startIndex, startIndex + rowsPerPage);

  // Si la página actual supera el total tras filtrar o cambiar filas, reajustar
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages || 1);
    }
  }, [totalPages, currentPage]);


  // Renderizado del componente
  if (loading) return <div className="content-container">Cargando productos…</div>;
  if (error)   return <div className="content-container">Error: {error}</div>;

  return (
    <div className="products-container">
      <Toaster position="top-center" reverseOrder={false} />
      <Menu />

      <h1 className="products-header">PRODUCTS</h1>

      <div className="table-container">
        <table className="list-table">
          <thead>
            <tr>
              <th>PRODUCTO</th>
              <th>PRECIO UNIDAD</th>
              <th>STOCK</th>
              <th>DESCRIPCIÓN</th>
              <th>CANT. PEDIDA</th>
              <th>ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {visible.map(p => (
              <tr key={p.Product_id}>
                <td>{p.ProductName}</td>
                <td>{p.UnitPrice}</td>
                <td>{p.Quantity}</td>
                <td>{p.ProductDescription}</td>
                <td>{p.UnitsOnOrder}</td>
                <td className="actions-cell">
                  <Link to={`/Products/editProduct/${p.Product_id}`}>
                    <button className="btn-edit">
                      <FontAwesomeIcon icon={faPenToSquare} />
                    </button>
                  </Link>
                  <button
                    className="btn-delete"
                    onClick={() => handleDelete(p.Product_id)}
                  >
                    <FontAwesomeIcon icon={faTrash} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="add-button-container">
        <Link to="/Products/addProduct">
          <button className="btn-add-product">
            <FontAwesomeIcon icon={faPlus} /> Añadir Producto
          </button>
        </Link>
      </div>
      {/* PAGINACIÓN */}
      <div className="pagination">
        <label>
          Filas por página:&nbsp;
          <select
            value={rowsPerPage}
            onChange={e => {
              setRowsPerPage(+e.target.value);
              setCurrentPage(1);
            }}
          >
            {[5, 10, 25, 50, 100].map(n => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>
        </label>
        <button
          onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
          disabled={currentPage === 1}
        >
          Prev
        </button>
        <span>Página {currentPage} de {totalPages || 1}</span>
        <button
          onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
          disabled={currentPage === totalPages || totalPages === 0}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default ListProducts;
