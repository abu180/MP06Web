// frontend/src/Components/Products_Supplier/addProduct_Supplier/AddProduct_Supplier.tsx

import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import toast, { Toaster } from 'react-hot-toast';
import './addProduct_Supplier.css';

// Componente del menú lateral
type Product = {
  Product_id: number;
  ProductName: string;
};
// Definición del tipo para los países
type Country = {
  Country_id: number;
  CountryName: string;
};
// Definición del tipo para los proveedores
type Supplier = {
  Supplier_id: number;
  CompanyName: string;
  Ingredient: string;
  Phone: string;
  Adress: string;
  Country: string;
  Postal_code: string;
  product_id: number;
};

// Componente para agregar un proveedor a un producto
const AddProduct_Supplier: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const productId = Number(id);
// Verificación de que el ID del producto es válido
  const [Ingredient, setIngredient] = useState('');
  const [CompanyName, setCompanyName] = useState('');
  const [ContactName, setContactName] = useState('');
  const [Phone, setPhone] = useState('');
  const [Adress, setAdress] = useState('');
  const [Country, setCountry] = useState('');
  const [Postal_code, setPostal_code] = useState('');
  const [Product_id, setProduct_id] = useState(productId);
//  Estado para almacenar los productos, países y proveedores existentes
  const [products, setProducts] = useState<Product[]>([]);
  const [countries, setCountries] = useState<Country[]>([]);
  const [existingSuppliers, setExistingSuppliers] = useState<Supplier[]>([]);

  // Carga inicial: productos, países y proveedores actuales
  useEffect(() => {
    (async () => {
      try {
        const [pRes, cRes, sRes] = await Promise.all([
          fetch('http://localhost:8000/Products'),
          fetch('http://localhost:8000/Countries'),
          fetch(`http://localhost:8000/Products/getProduct_Supplier/${productId}`)
        ]);
        if (!pRes.ok) throw new Error('No se pudieron cargar los productos');
        if (!cRes.ok) throw new Error('No se pudieron cargar los países');
        if (!sRes.ok) throw new Error('No se pudieron cargar los proveedores existentes');
        // Cargar los datos en el estado
        setProducts(await pRes.json());
        setCountries(await cRes.json());
        setExistingSuppliers(await sRes.json());
      } catch (err: unknown) {
        if (err instanceof Error) {
          toast.error(err.message || 'Error al inicializar datos');
        } else {
          toast.error('Error al inicializar datos');
        }
      }
    })();
  }, [productId]);

  // Manejo del envío del formulario
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Comprobación de duplicado: mismo CompanyName para este producto
    if (existingSuppliers.some(s => s.CompanyName === CompanyName)) {
      toast.error('Este proveedor ya está asociado a este producto');
      return;
    }

    // Confirmación de la acción
    try {
      const res = await fetch(
        `http://localhost:8000/Products/addProduct_Supplier/${productId}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            Ingredient,
            CompanyName,
            ContactName,
            Phone,
            Adress,
            Country,
            Postal_code,
            product_id: productId,
          }),
        }
      );
      if (!res.ok) throw new Error('Error al agregar el proveedor');

      toast.success('Proveedor agregado con éxito');

      // Limpiar formulario
      setIngredient('');
      setCompanyName('');
      setContactName('');
      setPhone('');
      setAdress('');
      setCountry('');
      setPostal_code('');

      // Volver a cargar la lista de proveedores
      const sRes = await fetch(`http://localhost:8000/Products/getProduct_Supplier/${productId}`);
      if (sRes.ok) setExistingSuppliers(await sRes.json());
    } catch (err: unknown) {
      if (err instanceof Error) {
        toast.error(err.message || 'No se pudo agregar');
      } else {
        toast.error('No se pudo agregar');
      }
    }
  };

  return (
    <div className="product-supplier-container">
      <Toaster position="top-center" />
      <h2 className="product-supplier-header">Agregar Proveedor al Producto</h2>

      <form className="product-supplier-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Ingrediente</label>
          <input
            type="text"
            value={Ingredient}
            onChange={e => setIngredient(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Empresa</label>
          <input
            type="text"
            value={CompanyName}
            onChange={e => setCompanyName(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Contacto</label>
          <input
            type="text"
            value={ContactName}
            onChange={e => setContactName(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Teléfono</label>
          <input
            type="text"
            value={Phone}
            onChange={e => setPhone(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Dirección</label>
          <input
            type="text"
            value={Adress}
            onChange={e => setAdress(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>País</label>
          <select
            value={Country}
            onChange={e => setCountry(e.target.value)}
            required
          >
            <option value="">Selecciona un país</option>
            {countries.map(c => (
              <option key={c.Country_id} value={c.CountryName}>
                {c.CountryName}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label>Código Postal</label>
          <input
            type="text"
            value={Postal_code}
            onChange={e => setPostal_code(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Producto</label>
          <select
            value={Product_id}
            onChange={e => setProduct_id(Number(e.target.value))}
            required
          >
            <option value={0}>Selecciona un producto</option>
            {products.map(p => (
              <option key={p.Product_id} value={p.Product_id}>
                {p.ProductName}
              </option>
            ))}
          </select>
        </div>

        <div className="form-actions">
          <button type="submit" className="btn-submit-supplier">
            Agregar
          </button>
          <Link to="/Products" className="btn-back-supplier">
            Volver
          </Link>
        </div>
      </form>
    </div>
  );
};

export default AddProduct_Supplier;
