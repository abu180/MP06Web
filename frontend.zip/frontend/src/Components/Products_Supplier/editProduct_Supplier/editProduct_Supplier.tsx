// frontend/src/Components/Products_Supplier/editProduct_Supplier/EditProduct_Supplier.tsx
import './editProduct_Supplier.css';
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';

interface Product {
  Product_id: number;
  ProductName: string;
}

interface Country {
  Country_id: number;
  CountryName: string;
}

const EditProduct_Supplier: React.FC = () => {
  // Pillamos el ID de la URL para saber a quién editamos
  const { id } = useParams<{ id: string }>();
  // Estados para manejar mensajes de error/éxito
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<boolean>(false);
  // Lista de productos y países para los selects
  const [product, setProduct] = useState<Product[]>([]);
  const [countries, setCountries] = useState<Country[]>([]);
  // Estado que contiene los datos del proveedor que vamos a editar
  const [productSupplier, setProduct_Supplier] = useState({
    Ingredient: '',
    CompanyName: '',
    ContactName: '',
    Phone: '',
    Adress: '',
    Country: '',
    Product_id: 0,
    Postal_code: '',
    ProductName: '',
  });

  // —— Primero, cargamos los datos del proveedor a editar ——
  useEffect(() => {
    const fetchProduct_Supplier = async () => {
      try {
        const response = await fetch(
          `http://localhost:8000/Products/getProduct_SupplierById/${id}`
        );
        if (!response.ok) {
          throw new Error('Error al obtener los datos del proveedor');
        }
        const data = await response.json();
        console.log('Datos recibidos del back:', data);
        setProduct_Supplier(data); // metemos los datos en el estado
      } catch (err) {
        console.error(err);
        setError('No se pudo cargar el proveedor');
      }
    };

    fetchProduct_Supplier();
  }, [id]);

  // —— Cargamos todas las opciones de productos ——  
  const fetchProduct = async () => {
    try {
      const response = await fetch('http://localhost:8000/Products');
      if (!response.ok) throw new Error('Error al obtener los productos');
      const data: Product[] = await response.json();
      setProduct(data);
    } catch (err) {
      console.error(err);
      setError('Error al cargar la lista de productos');
    }
  };

  // —— Cargamos todas las opciones de países ——
  const fetchCountries = async () => {
    try {
      const response = await fetch('http://localhost:8000/Countries');
      if (!response.ok) throw new Error('Error al obtener los países');
      const data: Country[] = await response.json();
      setCountries(data);
    } catch (err) {
      console.error(err);
      // No marcamos error para no bloquear toda la vista si falla este fetch
    }
  };

  // Hacemos los dos fetches solo una vez al montar
  useEffect(() => {
    fetchProduct();
    fetchCountries();
  }, []);

  // —— Cada vez que cambie un campo del form, lo volcamos en el estado ——  
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setProduct_Supplier(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  // —— Al pulsar “UPDATE SUPPLIER” ——  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Confirmación clásica
    const confirmEdit = window.confirm(
      '¿Estás seguro de que quieres actualizar este proveedor?'
    );
    if (!confirmEdit) return;

    setError(null);
    setSuccess(false);

    try {
      const response = await fetch(
        `http://localhost:8000/Products/updateProduct_Supplier/${id}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(productSupplier),
        }
      );
      if (!response.ok) throw new Error('Error al actualizar el proveedor');
      setSuccess(true);  // Marco éxito
    } catch (err) {
      console.error(err);
      setError('No se pudo actualizar el proveedor');
    }
  };

return (
  <div className="edit-product-supplier-container">
    <h2 className="edit-product-supplier-header">UPDATE SUPPLIER</h2>

    <form className="edit-product-supplier-form" onSubmit={handleSubmit}>
      <div className="form-group">
        <label>Ingrediente</label>
        <input
          type="text"
          name="Ingredient"
          value={productSupplier.Ingredient}
          onChange={handleChange}
          required
        />
      </div>

      <div className="form-group">
        <label>Empresa</label>
        <input
          type="text"
          name="CompanyName"
          value={productSupplier.CompanyName}
          onChange={handleChange}
          required
        />
      </div>

      <div className="form-group">
        <label>Contacto</label>
        <input
          type="text"
          name="ContactName"
          value={productSupplier.ContactName}
          onChange={handleChange}
          required
        />
      </div>

      <div className="form-group">
        <label>Teléfono</label>
        <input
          type="text"
          name="Phone"
          value={productSupplier.Phone}
          onChange={handleChange}
        />
      </div>

      <div className="form-group">
        <label>Dirección</label>
        <input
          type="text"
          name="Adress"
          value={productSupplier.Adress}
          onChange={handleChange}
        />
      </div>

      <div className="form-group">
        <label>País</label>
        <select
          name="Country"
          value={productSupplier.Country}
          onChange={handleChange}
          required
        >
          <option value="">Selecciona un país</option>
          {countries.map((c, idx) => (
            <option key={idx} value={c.CountryName}>
              {c.CountryName}
            </option>
          ))}
        </select>
      </div>

      <div className="form-group">
        <label>Producto</label>
        <select
          name="Product_id"
          value={productSupplier.Product_id}
          onChange={e =>
            setProduct_Supplier({
              ...productSupplier,
              Product_id: Number(e.target.value),
            })
          }
          required
        >
          <option value="">Selecciona un producto</option>
          {product.map((p, idx) => (
            <option key={idx} value={p.Product_id}>
              {p.ProductName}
            </option>
          ))}
        </select>
      </div>

      <div className="form-group">
        <label>Código Postal</label>
        <input
          type="text"
          name="Postal_code"
          value={productSupplier.Postal_code}
          onChange={handleChange}
        />
      </div>

      <div className="form-actions">
        <button type="submit" className="btn-update-supplier">
          UPDATE SUPPLIER
        </button>
        <Link to="/Products" className="btn-back-supplier">
          BACK
        </Link>
      </div>
    </form>

    {error && <p className="error">{error}</p>}
    {success && <p className="success">Supplier updated successfully</p>}
  </div>
);

};

export default EditProduct_Supplier;
