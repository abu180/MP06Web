import './Menu.css';
import React from 'react';
import { Link } from 'react-router-dom';
import Perfil from '../Perfil/Perfil';

// Componente funcional para el menú de navegación
function Menu() {
    return (
        <nav className='menu'>
            <div>
                <h1 className="menu-title">PANADERIA</h1>
                <ul className="menu-links">
                    <li>
                        <Link to="/UserHome">HOME</Link>
                    </li>
                    <li>
                        <Link to="/ProductsPage">PRODUCTS CATALOGUE</Link>
                        <Link to="/Cart">CART</Link>
                    </li>
                </ul>
            </div>
            <div className='menu-right'>
                <Perfil />
            </div>
        </nav>
    )
}

export default Menu;