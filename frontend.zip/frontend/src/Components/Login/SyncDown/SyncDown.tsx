// frontend/src/Components/Login/SyncDown/SyncDown.tsx
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../Auth/useAuth';

// Componente funcional para cerrar sesión y redirigir al login
const SyncDown = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();

  // Efecto para cerrar sesión y redirigir al login
  useEffect(() => {
    logout();               // Cierra la sesión
    navigate('/');     // Redirige al login después de cerrar sesión
  }, [logout, navigate]);

  return (
    <div>
      <h2>Cerrando sesión...</h2>
    </div>
  );
};

export default SyncDown;