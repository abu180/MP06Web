// frontend/src/Components/Login/SyncUp/SyncUp.tsx
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../Auth/useAuth';
import '../../Styles/SyncUp.css';
// Librería de iconos de FontAwesome
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faLock } from '@fortawesome/free-solid-svg-icons';

// Definimos la interfaz para la respuesta del login
interface LoginResponse {
  user: {
    User_id: number;
    Email: string;
    UserName: string;
    customer_id: number;
    avatar?: string | null;
  };
  message: string;
}

// Componente de inicio de sesión
const SyncUp: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!email || !password) {
      setError('Todos los campos son obligatorios.');
      return;
    }
    // Limpiamos el error
    try {
      const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:8000';
      const res = await fetch(`${apiUrl}/Users/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data: LoginResponse & { message?: string } = await res.json();

      if (!res.ok) {
        setError(data.message || 'Error en la autenticación.');
        return;
      }

      // Guardamos datos en el contexto de Auth
      login({
        userId: data.user.User_id,
        email: data.user.Email,
        token: '', // Si recibes un token del backend, ponlo aquí
        name: data.user.UserName,
        lastname: '',
        avatar: data.user.avatar || '',
      });

      // Si es el admin oficial (email y pass), vamos a AdminHome
      if (email === 'admin@gmail.com' && password === 'admin') {
        navigate('/AdminHome', { replace: true });
      } else {
        navigate('/UserHome', { replace: true });
      }

    } catch (err) {
      console.error('Error en el login:', err);
      setError('Error en la conexión con el servidor.');
    }
  };

  return (
    <div className="login-container">
      <div className="login-box">
        {/* Ajusta la ruta de la imagen según dónde la pongas en /public */}
        <img src="/MigaMiaLogo.png" alt="Logo" className="login-logo" />
        <h2>Iniciar Sesión</h2>
        {error && <p className="error-message">{error}</p>}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <input
              type="email"
              placeholder="Correo Electrónico"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
            />
            <FontAwesomeIcon icon={faUser} className="icon" />
          </div>
          <div className="form-group">
            <input
              type="password"
              placeholder="Contraseña"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
            />
            <FontAwesomeIcon icon={faLock} className="icon" />
          </div>
          <button type="submit">Iniciar Sesión</button>
        </form>

        <Link to="/register" className="register-link">
          ¿No tienes cuenta? Regístrate
        </Link>
      </div>
    </div>
  );
};

export default SyncUp;
