// Estilos específicos del carrito
import './Cart.css';
// Hooks de React
import React, { useEffect, useState } from 'react';
// Hook para navegar entre rutas
import { useNavigate } from 'react-router-dom';
// Cliente HTTP
import axios from 'axios';
// Componente de navegación superior
import NavBar from '../NavBar/NavBar';
// Icono de papelera
import { FaTrash } from "react-icons/fa";


// objeto carrito con sus campos
type CartItem = {
    Product_id: number,
    ProductName: string,
    UnitPrice: number,
    Quantity: number,
    ProductImage: string,
};


// objeto cliente con sus datos
type Customer = {
    Customer_id: number,
    Name: string,
    Surname: string,
    Address: string,
}


const Cart: React.FC = () => {
    // Navegación entre rutas
    const navigate = useNavigate();
    // Recupera el usuario del localStorage
    const storedUser = localStorage.getItem('user');
    // Parsea si existe
    const user = storedUser ? JSON.parse(storedUser) : null;
    
    const [cartItems, setCartItems] = useState<CartItem[]>([]);
    const [customerData, setCustomerData] = useState<Customer | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<boolean>(false);
    
    const user_id = user.userId
    console.log("ID del usuario:", user_id);

    //Obtiene los productos del carrito y los datos del cliente desde la API.
    const fetchCart = async () => {
            try {
                const response = await axios.get(`http://localhost:8000/Cart/getCart/${user_id}`);
                setCartItems(response.data);
                const customerResponse = await axios.get(`http://localhost:8000/Customers/getCustomerUserCart/${user_id}`);
                setCustomerData(customerResponse.data);
            } catch (error) {
                console.error('Error al obtener el carrito:', error);
            }
        };


    // Realiza el proceso completo de compra:
    const handleCheckout = async () => {
        try {
            // mapeamos para obtener los productos del carrito
            const products = cartItems.map((item) => ({
                product_id: item.Product_id,
                name: item.ProductName,
                description: item.ProductName,
                unit_price: item.UnitPrice * 100,
                quantity: item.Quantity
            }));

            // datos del cliente
            const customer = customerData;
            console.log("Cliente enviado:", customer);


            // peticion backend para el pago de la compra
            const response = await fetch('http://localhost:8000/Checkout/createSession', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ products, customer })
            });

            // datos de la compra en formato JSON
            const data = await response.json();

            // Si es exitoso y la compra se realiza correctamente, acutalizamos la cantidad pedida de ese producto
            if(response.ok && data.url) {
                
                for (const product of products) {
                    try {
                        await fetch('http://localhost:8000/Cart/updateProductOrder', {
                            method: 'PUT',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({
                                id: product.product_id,
                                quantity: product.quantity
                            })
                        });

                        //CREAMOS UN PEDIDO CON EL ID DEL USUARIO
                        const orderResponse = await fetch(`http://localhost:8000/Cart/createOrder/${user_id}`, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                        });

                        const orderData = await orderResponse.json();
                        console.log("Resultado de la creación del pedido:", orderData);

                        //VERIFICAMOS QUE EL PEDIDO SE HA CREADO CORRECTAMENTE Y ELIMINAMOS LOS PRODUCTOS DEL CARRITO
                        if(!orderResponse.ok) {
                            throw new Error('Error al crear el pedido');
                        } else {
                            const id = product.product_id;
                            const updateCartAfterCheckoutResponse = await fetch(`http://localhost:8000/Cart/deleteProductCart/${id}`, {
                                method: 'DELETE'
                            });

                            if(!updateCartAfterCheckoutResponse.ok) {
                                throw new Error('Error al eliminar el producto del carrito');
                            }
                            console.log("Producto eliminado del carrito después de la compra");

                        }


                        //ESTE ID ES EL DEL PEDIDO QUE SE HA CREADO, LO UTILIZAREMOS PARA CREAR EL DETALLE DEL PEDIDO
                        const order_id = orderData.Order_id;
                        console.log("ID del pedido:", order_id);


                        //CREAREMOS EL DETALLE DEL PEDIDO (Order_Details)
                        const orderDetailsResponse = await fetch('http://localhost:8000/OrderDetails/makeOrderDetail', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body : JSON.stringify({
                                order_id,
                                products
                            })
                        });

                        console.log("Datos enviados al backend para OrderDetails:", {
                            order_id,
                            products,
                        });

                        const orderDetailsData = await orderDetailsResponse.json();
                        console.log("Resultado de la creación del detalle del pedido:", orderDetailsData);
                        
                        if(!orderDetailsResponse.ok) {
                            throw new Error('Error al crear el detalle del pedido');
                        }

                    } catch (error) {
                        console.error('Error al actualizar el stock del producto:', error);
                    }
                }

                console.log(data);
                window.location.href = data.url;

            } else {
                console.log("No se ha recibido el enlace de pago.");
            }
        } catch (error) {
            console.error('Error al realizar el pago:', error);
        }
    };

    // funcion backend para eliminar un producto del carrito
    const handleDelete = async (id:number) => {
        const confirmDelete = window.confirm("¿Estás seguro de que quieres eliminarlo del carrito?");

        if(!confirmDelete) {
            return;
        }

        try {
            // peticion para eliminar el producto seleccionado
            const response = await fetch(`http://localhost:8000/Cart/deleteProductCart/${id}`, {
                method: 'DELETE'
            });

            if(!response.ok) {
                throw new Error('Error al eliminar el producto del carrito');
            }

            setSuccess(true);
            fetchCart();
        } catch(err: unknown) {
            if (err instanceof Error) {
                setError(err.message);
              } else {
                setError('Error desconocido');
              }
        }
    }

    useEffect(() => {
        fetchCart();
    }, []);


    if(error) {
        return <div>Error: {error}</div>;
    }


    return (
        <section className='CartSection-Container'>
            <div className='CartNavBar-Container'>
                <NavBar />
            </div>
            <div className='CartElements-Container'>
                <div className='Elements-Container'>
                    <div className='CartTitle-Container'>
                        <h2>Tu Cesta</h2>
                    </div>

                    <div className='Elements'>
                        {cartItems.map((item) => (
                            <div key={item.Product_id} className='ElementsContent-Container'>
                                <div className='ElementsImage-Container'>
                                    <img src={item.ProductImage} alt={item.ProductName} />
                                </div>
                                <div className='ElementsContent'>
                                    <div className='Element-TitleContainer'>
                                        <p><b>{item.ProductName}</b></p>
                                    </div>
                                    <div className='Element-PriceContainer'> 
                                        <p>{item.UnitPrice} €</p>
                                    </div>
                                    <div className='Element-QuantityContainer'>
                                        <p>Cantidad: {item.Quantity}</p>
                                    </div>
                                    <div className='Element-TotalPrice'>
                                        <p>Total: {item.UnitPrice * item.Quantity} €</p>
                                    </div>
                                </div>

                                <div className='Elements-TrashContainer'>
                                    <FaTrash onClick={() => handleDelete(item.Product_id)} className='TrashButton'></FaTrash>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                <div className='CartMessage-Container'>
                    <div className='CartErrorMessage-Container'>
                        {error && <div>Error: {error}</div>}
                    </div>
                    <div className='CartSuccessMessage-Container'>
                        {success && <div>Producto eliminado con éxito del carrito</div>}
                    </div>
                </div>

                <div className='CartButtons-Container'>
                    <div className='CartPayButton-Container'>
                        <button onClick={handleCheckout}>PAGAR</button>
                    </div>
                    <div className='CartBackButton-Container'>
                        <button onClick={() => navigate('/UserHome')}>VOLVER</button>
                    </div>
                </div>
            </div>

            

        </section>
    );
};

export default Cart;