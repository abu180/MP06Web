import React from "react";
import SearchBar from "../SearchBar/SearchBar";

// Componente funcional de la barra de navegación
const Navbar: React.FC = () => {

  return (
    <nav style={{ display: "flex", justifyContent: "space-between", padding: "10px", background: "#333", color: "white" }}>
      <h1>Shopy</h1>
      <SearchBar />
    </nav>
  );
};

export default Navbar;
