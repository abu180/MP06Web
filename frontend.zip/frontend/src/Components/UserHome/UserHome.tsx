//import Menu from '../Menu/Menu';
//import Navbar from '../Navbar/Navbar';
import './UserHome.css';
import HomeIntro from '../../Pages/HomeIntro/HomeIntro';
import Compromise from '../../Pages/Compromise/Compromise';
import Diferences from '../../Pages/Diferences/Diferences';
import Reviews from '../../Pages/Reviews/Reviews';
import TakeAway from '../../Pages/TakeAway/TakeAway';
import Service from '../../Pages/Service/Service';

// Componente funcional de la página de inicio del usuario
const UserHome: React.FC = () => {
    return (
        <section className='App-Container'>
          <HomeIntro />
          <Compromise />
          <Diferences />
          <Reviews />
          <TakeAway />
          <Service />
        </section>
      )
}

export default UserHome;