// src/Components/Orders/listOrders/ListOrders.tsx
import React, { useEffect, useState, useMemo } from "react";
// Importar estilos CSS específicos para el componente
import "../../Styles/ListCommon.css";
// Importar estilos CSS específicos para el componente
import Menu from "../../../Components/Sidebar/Sidebar";
// Importar iconos de FontAwesome
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// Importar iconos específicos
import { faHourglassHalf, faTimesCircle } from "@fortawesome/free-solid-svg-icons";
// Importar SweetAlert2 para mostrar alertas
import Swal from "sweetalert2";
// Importar estilos de SweetAlert2
import "sweetalert2/dist/sweetalert2.min.css";

// Definición del tipo para los pedidos
interface Order {
  Order_id: number;
  Name: string;
  Surname: string;
  Phone: string;
  Adress: string;
  OrderDate: string;
  customer_id: number;
  State: string;
}

// Estados disponibles
const STATES = ["Pendiente", "Procesando", "Enviado", "Entregado", "Cancelado"] as const;
type StateFilter = typeof STATES[number] | "All";

const ListOrders: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<StateFilter>("All");

  // Paginación
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);

  // Clases CSS por estado
  const stateClassMap: Record<StateFilter, string> = {
    All: "btn-all",
    Pendiente: "btn-pending",
    Procesando: "btn-process",
    Enviado: "btn-delivery",
    Entregado: "btn-finished",
    Cancelado: "btn-denied",
  };

  // 1) Traer todos los pedidos
  const fetchOrders = async () => {
    try {
      const res = await fetch("http://localhost:8000/Orders");
      if (!res.ok) throw new Error("Error al obtener los pedidos");
      setOrders(await res.json());
    } catch (e: unknown) {
      if (e instanceof Error) {
        setError(e.message);
      } else {
        setError("Error desconocido");
      }
    }
  };

  // 1) Cargar pedidos al inicio
  useEffect(() => {
    fetchOrders();
  }, []);

  // 2) Contadores por estado, incluidos “All”
  const counts = useMemo(() => {
    const c: Record<StateFilter, number> = {
      All: orders.length,
      Pendiente: 0,
      Procesando: 0,
      Enviado: 0,
      Entregado: 0,
      Cancelado: 0,
    };
    orders.forEach(o => {
      // si el estado está en el mapa, sumamos
      if (STATES.includes(o.State as typeof STATES[number])) {
        c[o.State as StateFilter] += 1;
      }
    });
    return c;
  }, [orders]);

  // 3) Lógica de filtrado cliente
  const filteredOrders = useMemo(() => {
    return filter === "All"
      ? orders
      : orders.filter(o => o.State === filter);
  }, [orders, filter]);

  // 4) Paginación
  const totalPages = Math.ceil(filteredOrders.length / rowsPerPage);
  const visibleOrders = filteredOrders.slice(
    (currentPage - 1) * rowsPerPage,
    (currentPage - 1) * rowsPerPage + rowsPerPage
  );

  // 5) Handlers de estado con confirmación
  const handleStateChange = async (
    id: number,
    apiPath: string,
    successMsg: string,
    errorMsg: string
  ) => {
    const { isConfirmed } = await Swal.fire({
      title: successMsg,
      icon: apiPath.includes("Cancel") ? "warning" : "question",
      showCancelButton: true,
      confirmButtonText: "Sí",
      cancelButtonText: "Cancelar",
      confirmButtonColor: apiPath.includes("Cancel") ? "#c0392b" : "#f39c12",
    });
    if (!isConfirmed) return;

    try {
      const res = await fetch(
        `http://localhost:8000/Orders/${apiPath}/${id}`,
        { method: "PUT" }
      );
      if (!res.ok) throw new Error();
      await fetchOrders(); // refrescamos TODO para recalcular counts y tabla
      Swal.fire("Éxito", successMsg, "success");
    } catch {
      Swal.fire("Error", errorMsg, "error");
    }
  };

  if (error) return <div className="content-container">Error: {error}</div>;

  return (
    <div className="content-container">
      <Menu />
      <h1 className="page-title">Lista de Pedidos</h1>

      {/* Botones de filtro */}
      <div className="order-filter-buttons">
        {STATES.map(state => (
          <button
            key={state}
            className={`${stateClassMap[state]}${filter === state ? " active" : ""}`}
            onClick={() => { setFilter(state); setCurrentPage(1); }}
          >
            {state.toUpperCase()} ({counts[state]})
          </button>
        ))}
      </div>

      {/* Tabla */}
      <div className="table-container">
        <table className="list-table">
          <thead>
            <tr>
              <th>NAME</th>
              <th>SURNAME</th>
              <th>PHONE</th>
              <th>ADDRESS</th>
              <th>ORDER DATE</th>
              <th>ORDER STATE</th>
              <th>ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {visibleOrders.map(o => (
              <tr key={o.Order_id}>
                <td>{o.Name}</td>
                <td>{o.Surname}</td>
                <td>{o.Phone}</td>
                <td>{o.Adress}</td>
                <td>{new Date(o.OrderDate).toLocaleString()}</td>
                <td>{o.State}</td>
                <td className="actions-cell">
                  <button
                    className="btn-action btn-process"
                    onClick={() =>
                      handleStateChange(
                        o.Order_id,
                        "updateOrderInProcessState",
                        'Marcar como "En proceso"',
                        "No se pudo actualizar a Procesando"
                      )
                    }
                    disabled={o.State !== "Pendiente"}
                  >
                    <FontAwesomeIcon icon={faHourglassHalf} /> En Proceso
                  </button>
                  <button
                    className="btn-action btn-cancel"
                    onClick={() =>
                      handleStateChange(
                        o.Order_id,
                        "updateOrderCancelState",
                        "Cancelar pedido",
                        "No se pudo cancelar"
                      )
                    }
                  >
                    <FontAwesomeIcon icon={faTimesCircle} /> Cancelar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Paginación */}
      <div className="pagination">
        <label>
          Filas por página:&nbsp;
          <select
            value={rowsPerPage}
            onChange={e => {
              setRowsPerPage(Number(e.target.value));
              setCurrentPage(1);
            }}
          >
            {[5, 10, 25, 50, 100].map(n => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>
        </label>

        <button
          onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
          disabled={currentPage === 1}
        >Prev</button>

        <span>Página {currentPage} de {totalPages || 1}</span>

        <button
          onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))}
          disabled={currentPage === totalPages}
        >Next</button>
      </div>
    </div>
  );
};

export default ListOrders;
