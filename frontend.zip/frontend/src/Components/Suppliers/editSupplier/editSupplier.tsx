// frontend/src/Components/Suppliers/editSupplier/EditSupplier.tsx

import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import Menu from '../../Sidebar/Sidebar';
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';
import toast, { Toaster } from 'react-hot-toast';
import './editSupplier.css';

// Tipos para definir la estructura de los productos y países
type Product = { Product_id: number; ProductName: string; };
type Country = { Country_id: number; CountryName: string; };

// Componente para editar un proveedor
const EditSupplier: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [loading, setLoading] = useState(true);
  const [supplier, setSupplier] = useState({
    Ingredient: '',
    CompanyName: '',
    ContactName: '',
    Phone: '',
    Adress: '',
    Country: '',
    Postal_code: '',
    Product_id: 0,
  });
  // Estado para almacenar la lista de productos y países
  const [productList, setProductList] = useState<Product[]>([]);
  const [countries, setCountries] = useState<Country[]>([]);

  // Carga de datos al montar el componente
  useEffect(() => {
    async function load() {
      try {
        const [sRes, pRes, cRes] = await Promise.all([
          fetch(`http://localhost:8000/Suppliers/${id}`),
          fetch('http://localhost:8000/Products'),
          fetch('http://localhost:8000/Countries'),
        ]);
        if (!sRes.ok) throw new Error('No se pudo cargar el proveedor');
        if (!pRes.ok) throw new Error('No se pudo cargar productos');
        if (!cRes.ok) throw new Error('No se pudo cargar países');
        setSupplier(await sRes.json());
        setProductList(await pRes.json());
        setCountries(await cRes.json());
      } catch (e: any) {
        toast.error(e.message);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [id]);

  // Función para manejar el envío del formulario
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validación de campos
    const { isConfirmed } = await Swal.fire({
      title: '¿Actualizar este proveedor?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Sí, actualizar',
      cancelButtonText: 'Cancelar',
      confirmButtonColor: '#4e2235',
      cancelButtonColor: '#6c757d',
    });
    if (!isConfirmed) return;
    // Envío de datos al backend
    try {
      const res = await fetch(
        `http://localhost:8000/Suppliers/updateSupplier/${id}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(supplier),
        }
      );
      // Manejo de la respuesta
      if (!res.ok) throw new Error('Error al actualizar proveedor');
      toast.success('Proveedor actualizado correctamente');
    } catch (e: any) {
      toast.error(e.message || 'Error desconocido');
    }
  };

  // Manejo de errores
  if (loading) return <div className="edit-supplier-container">Cargando proveedor…</div>;

  return (
    <div className="edit-supplier-container">
      <Toaster position="top-center" />
      <Menu />

      <header className="edit-supplier-header">
        Editar Proveedor
      </header>

      <div className="edit-supplier-card">
        <form className="edit-supplier-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Ingrediente</label>
            <input
              type="text"
              value={supplier.Ingredient}
              onChange={e =>
                setSupplier({ ...supplier, Ingredient: e.target.value })
              }
              required
            />
          </div>

          <div className="form-group">
            <label>Compañía</label>
            <input
              type="text"
              value={supplier.CompanyName}
              onChange={e =>
                setSupplier({ ...supplier, CompanyName: e.target.value })
              }
              required
            />
          </div>

          <div className="form-group">
            <label>Contacto</label>
            <input
              type="text"
              value={supplier.ContactName}
              onChange={e =>
                setSupplier({ ...supplier, ContactName: e.target.value })
              }
              required
            />
          </div>

          <div className="form-group">
            <label>Teléfono</label>
            <input
              type="text"
              value={supplier.Phone}
              onChange={e =>
                setSupplier({ ...supplier, Phone: e.target.value })
              }
            />
          </div>

          <div className="form-group">
            <label>Dirección</label>
            <input
              type="text"
              value={supplier.Adress}
              onChange={e =>
                setSupplier({ ...supplier, Adress: e.target.value })
              }
            />
          </div>

          <div className="form-group">
            <label>País</label>
            <select
              value={supplier.Country}
              onChange={e =>
                setSupplier({ ...supplier, Country: e.target.value })
              }
            >
              <option value="">Selecciona un país</option>
              {countries.map(c => (
                <option key={c.Country_id} value={c.CountryName}>
                  {c.CountryName}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>Código Postal</label>
            <input
              type="text"
              value={supplier.Postal_code}
              onChange={e =>
                setSupplier({ ...supplier, Postal_code: e.target.value })
              }
            />
          </div>

          <div className="form-group">
            <label>Producto</label>
            <select
              value={supplier.Product_id}
              onChange={e =>
                setSupplier({ ...supplier, Product_id: Number(e.target.value) })
              }
            >
              <option value={0}>Selecciona un producto</option>
              {productList.map(p => (
                <option key={p.Product_id} value={p.Product_id}>
                  {p.ProductName}
                </option>
              ))}
            </select>
          </div>

          <div className="form-actions">
            <Link to="/Suppliers">
              <button type="button" className="btn-back">Volver</button>
            </Link>
            <button type="submit" className="btn-submit">Guardar cambios</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditSupplier;
