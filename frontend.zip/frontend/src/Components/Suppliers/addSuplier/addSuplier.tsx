// frontend/src/Components/Suppliers/addSupplier/AddSupplier.tsx

import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Menu from '../../Sidebar/Sidebar';
import toast, { Toaster } from 'react-hot-toast';
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';
import '../../Styles/ListCommon.css';
import './addSupplier.css';

// Tipos para definir la estructura de los productos y países
type Product = { Product_id: number; ProductName: string; };
type Country = { Country_id: number; CountryName: string; };

// Componente para añadir un proveedor
const AddSupplier: React.FC = () => {
  const [Ingredient, setIngredient] = useState('');
  const [CompanyName, setCompanyName] = useState('');
  const [ContactName, setContactName] = useState('');
  const [Phone, setPhone] = useState('');
  const [Adress, setAdress] = useState('');
  const [Country, setCountry] = useState('');
  const [Postal_code, setPostal_code] = useState('');
  const [Product_id, setProduct_id] = useState<number | ''>('');
  const [products, setProducts] = useState<Product[]>([]);
  const [countries, setCountries] = useState<Country[]>([]);
  const navigate = useNavigate();

  // Carga de productos y países
  useEffect(() => {
    (async () => {
      try {
        const [pRes, cRes] = await Promise.all([
          fetch('http://localhost:8000/Products'),
          fetch('http://localhost:8000/Countries'),
        ]);
        if (!pRes.ok || !cRes.ok) throw new Error();
        setProducts(await pRes.json());
        setCountries(await cRes.json());
      } catch (e) {
        console.error(e);
      }
    })();
  }, []);

// Función para manejar el envío del formulario
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const { isConfirmed } = await Swal.fire({
      title: '¿Agregar este proveedor?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Sí, agregar',
      cancelButtonText: 'Cancelar',
      confirmButtonColor: '#8c6239',
      cancelButtonColor: '#6c757d',
    });
    if (!isConfirmed) return;
    
    // Validación de campos
    try {
      const res = await fetch('http://localhost:8000/Suppliers/addSupplier', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          Ingredient,
          CompanyName,
          ContactName,
          Phone,
          Adress,
          Country,
          Postal_code,
          Product_id,
        }),
      });
      if (!res.ok) throw new Error('Error al agregar el proveedor');
      toast.success('Proveedor agregado con éxito');
      // reset form
      setIngredient('');
      setCompanyName('');
      setContactName('');
      setPhone('');
      setAdress('');
      setCountry('');
      setPostal_code('');
      setProduct_id('');
      navigate('/Suppliers');
    } catch (e: unknown) {
      if (e instanceof Error) {
        toast.error(e.message || 'No se pudo agregar');
      } else {
        toast.error('No se pudo agregar');
      }
    }
  };

  return (
    <div className="edit-supplier-container">
      {/* Toasts */}
      <Toaster position="top-center" reverseOrder={false} />
      {/* Sidebar */}
      <Menu />

      {/* Header marrón ancho completo */}
      <h1 className="edit-supplier-header">Añadir Proveedor</h1>

      {/* Tarjeta blanca centrada */}
      <div className="edit-supplier-card">
        <form className="edit-supplier-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Ingrediente</label>
            <input
              type="text"
              value={Ingredient}
              onChange={e => setIngredient(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Compañía</label>
            <input
              type="text"
              value={CompanyName}
              onChange={e => setCompanyName(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Contacto</label>
            <input
              type="text"
              value={ContactName}
              onChange={e => setContactName(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Teléfono</label>
            <input
              type="text"
              value={Phone}
              onChange={e => setPhone(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Dirección</label>
            <input
              type="text"
              value={Adress}
              onChange={e => setAdress(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>País</label>
            <select
              value={Country}
              onChange={e => setCountry(e.target.value)}
              required
            >
              <option value="">Selecciona un país</option>
              {countries.map(c => (
                <option key={c.Country_id} value={c.CountryName}>
                  {c.CountryName}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>Código Postal</label>
            <input
              type="text"
              value={Postal_code}
              onChange={e => setPostal_code(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Producto</label>
            <select
              value={Product_id}
              onChange={e => setProduct_id(Number(e.target.value))}
              required
            >
              <option value="">Selecciona un producto</option>
              {products.map(p => (
                <option key={p.Product_id} value={p.Product_id}>
                  {p.ProductName}
                </option>
              ))}
            </select>
          </div>

          {/* Botones */}
          <div className="form-actions">
            <Link to="/Suppliers">
              <button type="button" className="btn-back">Volver</button>
            </Link>
            <button type="submit" className="btn-submit">Añadir Proveedor</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddSupplier;
