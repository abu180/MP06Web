// frontend/src/Components/Suppliers/listSuppliers/listSuppliers.tsx
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Menu from '../../Sidebar/Sidebar';
import toast, { Toaster } from 'react-hot-toast';
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';
import './listSuppliers.css';
// Importación de librerías para notificaciones
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPen, faTrash, faPlus } from '@fortawesome/free-solid-svg-icons';

// Importación de estilos
interface Supplier {
  Supplier_id: number;
  CompanyName: string;
  ContactName: string;
  Phone: string;
  Adress: string;
  Country: string;
  Postal_code: string;
}

// Componente para listar proveedores
const ListSuppliers: React.FC = () => {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Estados para paginación
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);

  // Función para cargar proveedores
  const fetchSuppliers = async () => {
    try {
      const res = await fetch('http://localhost:8000/Suppliers');
      if (!res.ok) throw new Error('Error al obtener los proveedores');
      setSuppliers(await res.json());
      setError(null);
    } catch (e: unknown) {
      if (e instanceof Error) {
        setError(e.message);
      } else {
        setError('Ocurrió un error desconocido');
      }
    } finally {
      setLoading(false);
    }
  };

  // Función para eliminar un proveedor
  const handleDelete = async (id: number) => {
    const result = await Swal.fire({
      title: '¿Eliminar proveedor?',
      text: 'Esta acción no se puede deshacer',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#dc3545',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar'
    });

    // Si el usuario cancela la acción, no hacemos nada
    if (!result.isConfirmed) return;

    // Si el usuario confirma, procedemos a eliminar
    try {
      const res = await fetch(`http://localhost:8000/Suppliers/deleteSupplier/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Error al eliminar el proveedor');
      await fetchSuppliers();
      toast.success('Proveedor eliminado con éxito');
    } catch (e: unknown) {
      if (e instanceof Error) {
        toast.error(e.message || 'No se pudo eliminar');
      } else {
        toast.error('No se pudo eliminar');
      }
    }
  };
  
  // Función para manejar el cambio de página
  useEffect(() => {
    fetchSuppliers();
  }, []);

  // Manejo de errores y carga
  if (loading) return <div className="content-container">Cargando proveedores...</div>;
  if (error) return <div className="content-container">Error: {error}</div>;

  // Cálculo de paginación
  const last = currentPage * rowsPerPage;
  const first = last - rowsPerPage;
  const visibleSuppliers = suppliers.slice(first, last);
  const totalPages = Math.ceil(suppliers.length / rowsPerPage);

  return (
     <div className="suppliers-container">
      <Toaster position="top-center" reverseOrder={false} />
      <Menu />

      <h1 className="suppliers-header">PROVEEDORES</h1>

      <div className="table-container">
        <table className="list-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Company Name</th>
              <th>Contact Name</th>
              <th>Phone</th>
              <th>Address</th>
              <th>Country</th>
              <th>Postal Code</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {visibleSuppliers.map(s => (
              <tr key={s.Supplier_id}>
                <td>{s.Supplier_id}</td>
                <td>{s.CompanyName}</td>
                <td>{s.ContactName}</td>
                <td>{s.Phone}</td>
                <td>{s.Adress}</td>
                <td>{s.Country}</td>
                <td>{s.Postal_code}</td>
                <td className="actions-cell">
                  <Link to={`/Suppliers/editSupplier/${s.Supplier_id}`}>
                    <button className="btn-action btn-edit" title="Editar">
                      <FontAwesomeIcon icon={faPen} />
                    </button>
                  </Link>
                  <button
                    className="btn-action btn-delete"
                    title="Eliminar"
                    onClick={() => handleDelete(s.Supplier_id)}
                  >
                    <FontAwesomeIcon icon={faTrash} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Botón para añadir */}
      <div className="add-supplier">
        <Link to="/Suppliers/addSupplier">
          <button className="btn-add-supplier">
            <FontAwesomeIcon icon={faPlus} /> Añadir Proveedor
          </button>
        </Link>
      </div>

      {/* Paginación */}
      <div className="pagination">
        <label>
          Filas por página:&nbsp;
          <select
            value={rowsPerPage}
            onChange={e => { setRowsPerPage(+e.target.value); setCurrentPage(1); }}
          >
            {[5, 10, 25, 50, 100].map(n => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>
        </label>
        <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}>
          Prev
        </button>
        <span>Página {currentPage} de {totalPages}</span>
        <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages}>
          Next
        </button>
      </div>
    </div>
  );
};

export default ListSuppliers;
