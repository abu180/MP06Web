// Componente para editar un usuario
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
// Librería para la barra de fuerza de contraseña.
import PasswordStrengthBar from 'react-password-strength-bar';
// Librería para alertas bonitas
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';
// El CSS del componente
import './editCustomer_User.css';
// Librería de iconos de FontAwesome
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faTrash } from '@fortawesome/free-solid-svg-icons';

// Para comprobar la fuerza de la contraseña
const PasswordStrengthBarAny = PasswordStrengthBar as unknown as React.FC<{ password: string }>;

// Definimos la interfaz para el usuario
type ExistingUser = {
  UserName: string;
  Email: string;
};

// Definimos la interfaz para el estado del usuario
const EditCustomer_User: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [customer_user, setCustomer_User] = useState({
    UserName: '',
    Email: '',
    Password: '',
    UserNameExists: false,
    EmailExists: false,
  });
  const [showPasswordPopup, setShowPasswordPopup] = useState(false);
  const [newPassword, setNewPassword] = useState('');

  // Cuando el componente arranca, pillamos los datos del usuario
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`http://localhost:8000/Customers/getCustomer_UserById/${id}`);
        if (!res.ok) throw new Error();
        const data = await res.json();
        setCustomer_User(data); // metemos la info en el state
      } catch {
        Swal.fire('Error', 'No se pudo cargar los datos del usuario', 'error');
      }
    })();
  }, [id]);

  // Para actualizar el estado al cambiar inputs
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCustomer_User(prev => ({ ...prev, [name]: value }));
  };

  // Chequeamos si el user o el email ya existen
  const checkUserExists = async (field: 'UserName' | 'Email', value: string) => {
    if (!value) return;
    try {
      const res = await fetch('http://localhost:8000/Users');
      if (!res.ok) throw new Error();
      const data: ExistingUser[] = await res.json();
      // filtramos el user actual para no chocar con él mismo
      const filtered = data.filter(u => u[field] !== customer_user[field]);
      const exists = filtered.some(u => u[field] === value);
      setCustomer_User(prev => ({ ...prev, [`${field}Exists`]: exists }));
    } catch {
      // aquí no rompemos nada si falla
    }
  };

  // Cuando das a “Actualizar usuario”
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // SweetAlert2 bonito para confirmar
    const { isConfirmed } = await Swal.fire({
      title: '¿Actualizar usuario?',
      text: '¿Estás seguro de que quieres guardar los cambios?',
      icon: 'question',
      showCancelButton: true,
      cancelButtonText: 'Cancelar',
      confirmButtonText: 'Sí, actualizar',
    });
    if (!isConfirmed) return;

    // Aquí hacemos la petición PUT para actualizar el usuario
    try {
      const res = await fetch(`http://localhost:8000/Customers/updateCustomer_User/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(customer_user),
      });
      if (!res.ok) throw new Error();
      await Swal.fire('¡Listo!', 'El usuario se ha actualizado con éxito.', 'success');
    } catch {
      Swal.fire('Error', 'Error al actualizar el usuario', 'error');
    }
  };

  // Cuando guardas la nueva contraseña
  const handlePasswordUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    const { isConfirmed } = await Swal.fire({
      title: '¿Cambiar contraseña?',
      text: '¿Deseas actualizar la contraseña?',
      icon: 'question',
      showCancelButton: true,
      cancelButtonText: 'Cancelar',
      confirmButtonText: 'Sí, cambiar',
    });
    if (!isConfirmed) return;

    // Aquí hacemos la petición PUT para actualizar la contraseña
    try {
      const res = await fetch(
        `http://localhost:8000/Customers/updateCustomer_UserPassword/${id}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ Password: newPassword }),
        }
      );
      if (!res.ok) throw new Error();
      setShowPasswordPopup(false);
      setNewPassword('');
      Swal.fire('¡Listo!', 'La contraseña se ha actualizado con éxito.', 'success');
    } catch {
      Swal.fire('Error', 'No se pudo actualizar la contraseña', 'error');
    }
  };

  return (
    <div className="content-container">
      {/* Título con iconito, usando clase exclusiva */}
      <h1 className="edit-customer-header">
        <FontAwesomeIcon icon={faPenToSquare} className="header-icon" />
        EDITAR USUARIO
      </h1>

      <form className="add-customer-form" onSubmit={handleSubmit}>
        {/* Campo de nombre de usuario */}
        <div className="form-group">
          <label>Nombre de Usuario</label>
          <input
            type="text"
            name="UserName"
            value={customer_user.UserName}
            onChange={e => {
              handleChange(e);
              checkUserExists('UserName', e.target.value);
            }}
            placeholder="Nombre de Usuario"
            required
          />
          {customer_user.UserNameExists && (
            <p className="form-error">Este nombre de usuario ya está en uso.</p>
          )}
        </div>

        {/* Campo de email */}
        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            name="Email"
            value={customer_user.Email}
            onChange={e => {
              handleChange(e);
              checkUserExists('Email', e.target.value);
            }}
            placeholder="Email"
            required
          />
          {customer_user.EmailExists && (
            <p className="form-error">Este correo electrónico ya está en uso.</p>
          )}
        </div>

        {/* Botón para abrir el popup de contraseña */}
        <div className="form-group">
          <button
            type="button"
            className="btn-submit"
            onClick={() => setShowPasswordPopup(true)}
          >
            Cambiar Contraseña
          </button>
        </div>

        {/* Botones de Actualizar y Volver */}
        <div className="form-actions">
          <button
            type="submit"
            className="btn-submit"
            disabled={customer_user.UserNameExists || customer_user.EmailExists}
          >
            ACTUALIZAR USUARIO
          </button>
          <Link to="/Customers">
            <button type="button" className="btn-back">
              <FontAwesomeIcon icon={faTrash} className="back-icon" />
              BACK
            </button>
          </Link>
        </div>
      </form>

      {/* Popup para cambiar contraseña */}
      {showPasswordPopup && (
        <>
          <div className="password-popup-backdrop" />
          <div className="password-popup">
            <h3>Cambiar Contraseña</h3>
            <form onSubmit={handlePasswordUpdate}>
              <div className="form-group">
                <label>Nueva Contraseña</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  placeholder="Nueva Contraseña"
                  required
                />
                <PasswordStrengthBarAny password={newPassword} />
              </div>
              <div className="form-actions">
                <button type="submit" className="btn-submit">
                  Guardar
                </button>
                <button
                  type="button"
                  className="btn-back"
                  onClick={() => setShowPasswordPopup(false)}
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </>
      )}
    </div>
  );
};

export default EditCustomer_User;
