// frontend/src/Components/Customers_Users/addCustomer_User/AddCustomer_User.tsx
import React, { useState, useEffect } from 'react';
import PasswordStrengthBar from 'react-password-strength-bar';
import { useParams, Link } from 'react-router-dom';
import Menu from '../../Sidebar/Sidebar';
import './addCustomer_User.css';

// Adaptación del componente de fuerza de contraseña a un tipo más flexible
const PasswordStrengthBarAny = PasswordStrengthBar as unknown as React.FC<{ password: string }>;

// Definición del tipo para los datos de usuario
interface UserData {
  UserName: string;
  Email: string;
  Password: string;
  confirmPassword: string;
  avatar?: string;
  avatarFile?: File;
  UserNameExists?: boolean;
  EmailExists?: boolean;
}
// Definición del tipo para los usuarios existentes
type ExistingUser = { UserName: string; Email: string; };

// Componente para agregar usuarios a un cliente
const AddCustomer_User: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const customerId = Number(id);

  // Estados para manejar los datos de los usuarios
  const [existingUsers, setExistingUsers] = useState<ExistingUser[]>([]);
  const [users, setUsers] = useState<UserData[]>([{
    UserName: '',
    Email: '',
    Password: '',
    confirmPassword: '',
    avatar: '',
    UserNameExists: false,
    EmailExists: false
  }]);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<boolean>(false);

  useEffect(() => {
    // Carga usuarios existentes para validaciones
    const checkUserExists = async () => {
      try {
        const res = await fetch('http://localhost:8000/Users');
        const text = await res.text();
        const data: ExistingUser[] = text ? JSON.parse(text) : [];
        setExistingUsers(data);
      } catch (e) {
        console.error(e);
      }
    };
    checkUserExists();
  }, []);

  // Función para manejar cambios en los campos de usuario
  const handleUserChange = (idx: number, field: keyof UserData, value: string) => {
    setUsers(prev => prev.map((u, i) => {
      if (i !== idx) return u;
      const updated = { ...u, [field]: value };
      if (field === 'UserName')
        updated.UserNameExists = existingUsers.some(x => x.UserName === value);
      if (field === 'Email')
        updated.EmailExists = existingUsers.some(x => x.Email === value);
      return updated;
    }));
  };

  // Funciones para agregar y eliminar usuarios
  const handleAddUser = () =>
    setUsers(prev => [...prev, { UserName: '', Email: '', Password: '', confirmPassword: '', avatar: '' }]);

  // Función para eliminar un usuario
  const handleRemoveUser = (idx: number) =>
    setUsers(prev => prev.filter((_, i) => i !== idx));

  // Función para manejar cambios en el campo de archivo
  const handleFileChange = (idx: number, e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const file = e.target.files[0];
    const url = URL.createObjectURL(file);
    setUsers(prev => prev.map((u, i) =>
      i === idx ? { ...u, avatar: url, avatarFile: file } : u
    ));
  };

  // Función para manejar el envío del formulario
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(false);

    // validaciones
    for (let i = 0; i < users.length; i++) {
      const { UserName, Email, Password, confirmPassword } = users[i];
      if (!UserName || !Email || !Password || !confirmPassword) {
        setError(`Todos los campos son obligatorios (usuario #${i + 1}).`);
        return;
      }
      if (users[i].UserNameExists || users[i].EmailExists) {
        setError(`Usuario o correo duplicado (usuario #${i + 1}).`);
        return;
      }
      if (Password !== confirmPassword) {
        setError(`Las contraseñas no coinciden (usuario #${i + 1}).`);
        return;
      }
    }

    // envío al endpoint corregido
    try {
      const payload = {
        customer_id: customerId,
        users: users.map(u => ({
          UserName: u.UserName,
          Email: u.Email,
          Password: u.Password
        }))
      };
      // Envío de datos al backend
      const res = await fetch('http://localhost:8000/Users/addUsersToCustomer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

    // Comprobación de respuesta
      if (!res.ok) throw new Error('Error al agregar usuarios');
      setSuccess(true);
      setUsers([{ UserName: '', Email: '', Password: '', confirmPassword: '', avatar: '' }]);
    } catch (e: any) {
      setError(e.message || 'Error desconocido');
    }
  };

  return (
    <div className="add-customer-user-container">
      {/* Menú lateral */}
      <Menu />

      {/* Encabezado de la página */}
      <header className="add-customer-user-header">
        Agregar Usuarios al Cliente
      </header>

      {/* Tarjeta principal */}
      <div className="add-customer-user-card">
        <form onSubmit={handleSubmit}>
          {users.map((user, idx) => (
            <div className="user-card" key={idx}>
              <h4>
                Usuario #{idx + 1}
                <button
                  type="button"
                  className="remove-user-btn"
                  onClick={() => handleRemoveUser(idx)}
                >
                  ×
                </button>
              </h4>

              <div className="form-group">
                <label>Nombre de Usuario:</label>
                <input
                  type="text"
                  value={user.UserName}
                  onChange={e => handleUserChange(idx, 'UserName', e.target.value)}
                  required
                />
                {user.UserNameExists && <p className="error-message">Este nombre ya existe.</p>}
              </div>

              <div className="form-group">
                <label>Email:</label>
                <input
                  type="email"
                  value={user.Email}
                  onChange={e => handleUserChange(idx, 'Email', e.target.value)}
                  required
                />
                {user.EmailExists && <p className="error-message">Este email ya existe.</p>}
              </div>

              <div className="form-group">
                <label>Contraseña:</label>
                <input
                  type="password"
                  value={user.Password}
                  onChange={e => handleUserChange(idx, 'Password', e.target.value)}
                  required
                />
                <div className="password-strength-bar">
                  <PasswordStrengthBarAny password={user.Password} />
                </div>
              </div>

              <div className="form-group">
                <label>Confirmar Contraseña:</label>
                <input
                  type="password"
                  value={user.confirmPassword}
                  onChange={e => handleUserChange(idx, 'confirmPassword', e.target.value)}
                  required
                />
                {user.confirmPassword && user.Password !== user.confirmPassword && (
                  <p className="error-message">Las contraseñas no coinciden.</p>
                )}
              </div>

              <div className="form-group">
                <label>Avatar:</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={e => handleFileChange(idx, e)}
                />
                {user.avatar && (
                  <div className="avatar-preview">
                    <img src={user.avatar} alt={`Avatar ${idx + 1}`} />
                  </div>
                )}
              </div>
            </div>
          ))}

          <button type="button" className="add-user-btn" onClick={handleAddUser}>
            + Usuario
          </button>

          <div className="form-actions">
            <button type="submit" className="btn-save">
              Guardar
            </button>
            <Link to="/Customers">
              <button type="button" className="btn-back">
                Volver
              </button>
            </Link>
          </div>

          {error && <p className="error-message">{error}</p>}
          {success && <p className="success-message">Usuarios agregados con éxito</p>}
        </form>
      </div>
    </div>
  );

};

export default AddCustomer_User;
