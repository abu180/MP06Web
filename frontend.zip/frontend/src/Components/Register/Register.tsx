// frontend/src/Components/Register/Register.tsx

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../../Styles/FormCommon.css';
import './Register.css';

// Definición de la interfaz para los datos del formulario de registro
interface RegisterFormData {
  Name: string;
  Surname: string;
  Phone: string;
  Adress: string;
  Country: string;
  PostalCode: string;
  UserName: string;
  Email: string;
  Password: string;
  ConfirmPassword: string;
}

// Componente de registro
const Register: React.FC = () => {
  const [formData, setFormData] = useState<RegisterFormData>({
    Name: '',
    Surname: '',
    Phone: '',
    Adress: '',
    Country: '',
    PostalCode: '',
    UserName: '',
    Email: '',
    Password: '',
    ConfirmPassword: ''
  });
  // Estados para manejar errores y mensajes de éxito
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const navigate = useNavigate();

  // Función para manejar el cambio en los campos del formulario
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  // Función para manejar el envío del formulario
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    // Validación de contraseña
    if (formData.Password !== formData.ConfirmPassword) {
      setError('Las contraseñas no coinciden');
      return;
    }

    // Validación de campos vacíos
    try {
      const resp = await fetch('http://localhost:8000/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          Name: formData.Name,
          Surname: formData.Surname,
          Phone: formData.Phone,
          Adress: formData.Adress,
          Country: formData.Country,
          PostalCode: formData.PostalCode,
          UserName: formData.UserName,
          Email: formData.Email,
          Password: formData.Password,
        }),
      });
      const data = await resp.json();
      if (!resp.ok) {
       // Manejo de errores 
        setError(data.message || 'Error en el registro.');
      } else {
        // Registro exitoso
        setSuccess(data.message || 'Registro exitoso.');
        setTimeout(() => navigate('/login'), 1000);
      }
      // Reiniciar el formulario
    } catch {
      setError('Error en la conexión con el servidor.');
    }
  };

  return (
    <div className="register-container">
      <h2 className="page-header">Registro de Usuario y Cliente</h2>
  
      {error && <div className="form-error">{error}</div>}
      {success && <div className="form-success">{success}</div>}
  
      <form className="form-card" onSubmit={handleSubmit}>
        <h3>Datos del Cliente</h3>
        <div className="form-group">
          <label htmlFor="Name">Nombre</label>
          <input
            type="text"
            id="Name"
            name="Name"
            placeholder="Nombre"
            value={formData.Name}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="Surname">Apellidos</label>
          <input
            type="text"
            id="Surname"
            name="Surname"
            placeholder="Apellidos"
            value={formData.Surname}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="Phone">Teléfono</label>
          <input
            type="text"
            id="Phone"
            name="Phone"
            placeholder="Teléfono"
            value={formData.Phone}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="Adress">Dirección</label>
          <input
            type="text"
            id="Adress"
            name="Adress"
            placeholder="Dirección"
            value={formData.Adress}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="Country">País</label>
          <input
            type="text"
            id="Country"
            name="Country"
            placeholder="País"
            value={formData.Country}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="PostalCode">Código Postal</label>
          <input
            type="text"
            id="PostalCode"
            name="PostalCode"
            placeholder="Código Postal"
            value={formData.PostalCode}
            onChange={handleChange}
            required
          />
        </div>
  
        <h3>Datos del Usuario</h3>
        <div className="form-group">
          <label htmlFor="UserName">Nombre de Usuario</label>
          <input
            type="text"
            id="UserName"
            name="UserName"
            placeholder="Nombre de Usuario"
            value={formData.UserName}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="Email">Email</label>
          <input
            type="email"
            id="Email"
            name="Email"
            placeholder="Email"
            value={formData.Email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="Password">Contraseña</label>
          <input
            type="password"
            id="Password"
            name="Password"
            placeholder="Contraseña"
            value={formData.Password}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="ConfirmPassword">Confirmar Contraseña</label>
          <input
            type="password"
            id="ConfirmPassword"
            name="ConfirmPassword"
            placeholder="Confirmar Contraseña"
            value={formData.ConfirmPassword}
            onChange={handleChange}
            required
          />
        </div>
  
        <div className="form-actions">
          <button type="submit" className="btn-submit">Registrarse</button>
        </div>
  
        <p className="form-footer">
          ¿Ya tienes cuenta? <Link to="/login">Inicia Sesión</Link>
        </p>
      </form>
    </div>
  );
  
};

export default Register;
