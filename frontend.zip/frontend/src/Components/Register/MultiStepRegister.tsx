// src/Components/Register/MultiStepRegister.tsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PasswordStrengthBar from 'react-password-strength-bar';
import './MultiStepRegister.css';

// Importar componentes de formularios
const PasswordStrengthBarAny = PasswordStrengthBar as unknown as React.FC<{ password: string }>;

// Definición de tipos y constantes
enum Step {
  CUSTOMER = 1,
  USERS = 2,
}

// Definición de interfaces para los datos del cliente y usuario
interface CustomerData {
  Name: string;
  Surname: string;
  Phone: string;
  Adress: string;
  Country: string;
  PostalCode: string;
}
// Definición de la interfaz para los datos del usuario
interface UserData {
  UserName: string;
  Email: string;
  Password: string;
  confirmPassword: string;
  avatar?: string;
  avatarFile?: File;
}

// Definición de la interfaz para los datos de registro
interface RegistrationData {
  customer: CustomerData;
  users: UserData[];
}

// Función para omitir una propiedad de un objeto
function omit<T extends object, K extends keyof T>(obj: T, key: K): Omit<T, K> {
  const newObj = { ...obj };
  delete newObj[key];
  return newObj;
}

// Componente principal de registro multi-paso
const MultiStepRegister: React.FC = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>(Step.CUSTOMER);
  const [regData, setRegData] = useState<RegistrationData>({
    customer: { Name: '', Surname: '', Phone: '', Adress: '', Country: '', PostalCode: '' },
    users: [{ UserName: '', Email: '', Password: '', confirmPassword: '', avatar: '' }],
  });
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // PASO 1: Validación datos cliente
  const handleCustomerSubmit = (customerData: CustomerData) => {
    if (Object.values(customerData).some(v => !v)) {
      setError('Todos los campos del cliente son obligatorios.');
      return;
    }
    setRegData(prev => ({ ...prev, customer: customerData }));
    setError(null);
    setStep(Step.USERS);
  };

  // PASO 2: Validación datos usuarios
  const handleUsersSubmit = (usersData: UserData[]) => {
    for (let i = 0; i < usersData.length; i++) {
      const { UserName, Email, Password, confirmPassword } = usersData[i];
      if (!UserName || !Email || !Password || !confirmPassword) {
        setError(`Todos los campos de usuario son obligatorios (usuario #${i + 1}).`);
        return;
      }
      if (Password !== confirmPassword) {
        setError(`Las contraseñas no coinciden en el usuario #${i + 1}.`);
        return;
      }
    }
    setError(null);
    setRegData(prev => ({ ...prev, users: usersData }));
    handleFinalSubmit({ ...regData, users: usersData });
  };

  // Subida de avatar
  const uploadAvatarFile = async (file: File): Promise<string> => {
    const formData = new FormData();
    formData.append('avatar', file);
    const response = await fetch('http://localhost:8000/Users/UploadAvatar', {
      method: 'POST',
      body: formData,
    });
    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.message || 'Error al subir el avatar');
    }
    return (await response.json()).avatar;
  };

  // PASO 3: Envío final
  const handleFinalSubmit = async (finalData: RegistrationData) => {
    try {
      // Subir avatars si hay
      const usersWithAvatar = await Promise.all(
        finalData.users.map(async user => {
          if (user.avatarFile) {
            const url = await uploadAvatarFile(user.avatarFile);
            return { ...user, avatar: url };
          }
          return user;
        })
      );

      const payload = {
        ...finalData.customer,
        users: usersWithAvatar.map(u => omit(u, 'confirmPassword')),
      };
      // Enviar datos al backend
      const res = await fetch('http://localhost:8000/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.message || 'Error en el registro.');
      } else {
        setSuccess('Registro exitoso.');
        navigate('/login');
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error en la conexión con el servidor.';
      setError(msg);
    }
  };

  // Funciones para manejar la navegación
  const handleCancel = () => navigate('/');
  const handleBack = () => setStep(Step.CUSTOMER);

  return (
    <div className="register-container">
      <h2>Registro Multi-Paso</h2>
      {error && <p className="form-error">{error}</p>}
      {success && <p className="form-success">{success}</p>}

      {step === Step.CUSTOMER && (
        <CustomerForm
          initialData={regData.customer}
          onSubmit={handleCustomerSubmit}
          onCancel={handleCancel}
        />
      )}

      {step === Step.USERS && (
        <UsersForm
          initialData={regData.users}
          onSubmit={handleUsersSubmit}
          onCancel={handleCancel}
          onBack={handleBack}
        />
      )}
    </div>
  );
};

export default MultiStepRegister;

/* -------------------------------------------------------------------------- */
// Componentes de formulario para el cliente y los usuarios
/* -------------------------------------------------------------------------- */
type CustomerFormProps = {
  initialData: CustomerData;
  onSubmit: (data: CustomerData) => void;
  onCancel: () => void;
};
const CustomerForm: React.FC<CustomerFormProps> = ({ initialData, onSubmit, onCancel }) => {
  const [form, setForm] = useState<CustomerData>(initialData);
  const handleChange = (k: keyof CustomerData, v: string) => setForm(prev => ({ ...prev, [k]: v }));
  return (
    <form onSubmit={e => { e.preventDefault(); onSubmit(form); }}>
      {(['Name', 'Surname', 'Phone', 'Adress', 'Country', 'PostalCode'] as (keyof CustomerData)[]).map(field => (
        <div className="form-group" key={field}>
          <label>{field === 'PostalCode' ? 'Código Postal' : field}:</label>
          <input
            type="text"
            value={form[field]}
            onChange={e => handleChange(field, e.target.value)}
            required
          />
        </div>
      ))}
      <div className="form-actions">
        <button type="button" className="btn-back" onClick={onCancel}>Cancelar</button>
        <button type="submit" className="btn-next">Siguiente</button>
      </div>
    </form>
  );
};

/* -------------------------------------------------------------------------- */
// Componente de formulario para los usuarios
/* -------------------------------------------------------------------------- */
type UsersFormProps = {
  initialData: UserData[];
  onSubmit: (users: UserData[]) => void;
  onCancel: () => void;
  onBack: () => void;
};
const UsersForm: React.FC<UsersFormProps> = ({ initialData, onSubmit, onCancel, onBack }) => {
  const [users, setUsers] = useState<UserData[]>(initialData);

  const changeField = (i: number, field: keyof UserData, val: string | File) => {
    setUsers(prev => prev.map((u, idx) => idx === i ? { ...u, [field]: val } : u));
  };

  const addUser = () => setUsers(prev => [...prev, { UserName: '', Email: '', Password: '', confirmPassword: '', avatar: '' }]);
  const removeUser = (i: number) => setUsers(prev => prev.filter((_, idx) => idx !== i));

  const handleFile = (i: number, e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0]) return;
    const file = e.target.files[0];
    changeField(i, 'avatarFile', file);
    changeField(i, 'avatar', URL.createObjectURL(file));
  };

  return (
    <form onSubmit={e => { e.preventDefault(); onSubmit(users); }}>
      <h3>Usuarios Asociados al Cliente</h3>
      {users.map((user, idx) => (
        <div className="user-card" key={idx}>
          <h4>Usuario #{idx + 1}</h4>
          <button type="button" className="btn-remove-user" onClick={() => removeUser(idx)}>X</button>
          {(['UserName', 'Email', 'Password', 'confirmPassword'] as (keyof UserData)[]).map(f => (
            <div className="form-group" key={f}>
              <label>{f === 'confirmPassword' ? 'Confirmar Contraseña' : f}:</label>
              <input
                type={f.includes('Password') ? 'password' : f === 'Email' ? 'email' : 'text'}
                value={user[f] as string}
                onChange={e => changeField(idx, f, e.target.value)}
                required
              />
              {f === 'Password' && <PasswordStrengthBarAny password={user.Password} />}
              {f === 'confirmPassword' && user.confirmPassword && user.Password !== user.confirmPassword && (
                <p className="form-error">Las contraseñas no coinciden</p>
              )}
            </div>
          ))}
          <div className="form-group">
            <label>Avatar:</label>
            <input type="file" accept="image/*" onChange={e => handleFile(idx, e)} />
            {user.avatar && <img src={user.avatar} alt={`Avatar ${idx + 1}`} />}
          </div>
        </div>
      ))}
      <button type="button" className="btn-add-user" onClick={addUser}>+ Usuario</button>
      <div className="form-actions">
        <button type="button" className="btn-back" onClick={onCancel}>Cancelar</button>
        <button type="button" className="btn-next" onClick={onBack}>Atrás</button>
        <button type="submit" className="btn-save">Guardar</button>
      </div>
    </form>
  );
};
export { MultiStepRegister, CustomerForm, UsersForm };