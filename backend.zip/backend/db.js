// MODULO PARA CONFIGURAR LAS VARIABLES DE BASE DE DATOS
require('dotenv').config({ path: './dbVariables.env' });

// TESTING
console.log('Conectando con la base de datos...');
console.log(`Usuario: ${process.env.DB_USER}`);
console.log(`Base de datos: ${process.env.DB_NAME}`);

// MODULO SQL NECESARIO PARA INICIAR BASE DE DATOS
const mysql = require('mysql2/promise');

// MODULO QUE SE ENCARGA DE CONECTARSE CON EL SERVIDOR SQL
const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: 3306,
});

// EXPORTAMOS EL MODULO
module.exports = pool;