// IMPORTAMOS LA BASE DE DATOS
const db = require('../db');

// OBTIENE LOS PRODUCTOS DEL CARRITO DE UN USUARIO ESPECÍFICO
async function getCartValues(user_id) {
    const [cart] = await db.query(
        "SELECT P.Product_id, P.ProductName, P.UnitPrice, C.Cart_id, C.user_id, C.product_id, C.Quantity FROM Cart AS C INNER JOIN Products AS P ON P.Product_id = C.product_id WHERE C.user_id = ?",
        [user_id]
    );
    return cart;
}


// AÑADE UN PRODUCTO AL CARRITO DEL USUARIO O ACTUALIZA LA CANTIDAD SI YA EXISTE
async function addToCartValues(user_id, product_id, quantity) {
    // VERIFICA SI EL PRODUCTO YA ESTÁ EN EL CARRITO
    const [existing] = await db.query(
        "SELECT * FROM Cart WHERE user_id = ? AND product_id = ?",
        [user_id, product_id]
    );

    // SI EL PRODUCTO EXISTE, ACTUALIZA LA CANTIDAD
    if (existing.length > 0) {
        await db.query(
            "UPDATE Cart SET Quantity = Quantity + ? WHERE user_id = ? AND product_id = ?",
            [quantity, user_id, product_id]
        );
    } else {
        // SI NO EXISTE, LO INSERTA EN EL CARRITO
        await db.query(
            "INSERT INTO Cart (user_id, product_id, Quantity) VALUES (?, ?, ?)",
            [user_id, product_id, quantity]
        );
    }
}


// ELIMINA UN PRODUCTO DEL CARRITO POR SU ID DE PRODUCTO
async function deleteCartProductValues(id) {
    const [sql] = await db.query(
        "DELETE FROM Cart WHERE product_id = ?",
        [id]
    );
    return sql;
}


// CREA UN NUEVO PEDIDO PARA EL USUARIO
async function createOrderValues(user_id) {
    // INSERTA UN NUEVO PEDIDO CON LA FECHA ACTUAL PARA EL CLIENTE RELACIONADO AL USUARIO
    const [result] = await db.query(
        "INSERT INTO Orders (OrderDate, customer_id) SELECT CURDATE(), C.Customer_id FROM Customers C JOIN Users U ON U.customer_id = C.Customer_id WHERE U.User_id = ?;",
        [user_id]
    );

    // OBTIENE EL ID DEL PEDIDO RECIÉN CREADO
    const [orderIdResult] = await db.query("SELECT LAST_INSERT_ID() AS order_id;");
    return orderIdResult[0];
}

// ACTUALIZA LAS UNIDADES EN PEDIDO Y REDUCE LA CANTIDAD EN STOCK DE UN PRODUCTO
async function updateProductOrderValues(id, quantity) {
    const [sql] = await db.query(
        "UPDATE Products SET UnitsOnOrder = UnitsOnOrder + ?, Quantity = Quantity - ? WHERE Product_id = ?",
        [quantity, quantity, id]
    )

    // VERIFICA EL STOCK ACTUAL DEL PRODUCTO
    const [checkStock] = await db.query(
        "SELECT Quantity FROM Products WHERE Product_id = ?",
        [id]
    );

    // SI EL STOCK ES INFERIOR A 15, SE REPONE EN 1 UNIDAD
    if(checkStock[0].quantity < 15) {
        await db.query(
            "UPDATE Products SET Quantity = Quantity + 1 WHERE Product_id = ?",
            [id]
        )
    }

    return sql;
}


// REPONE AUTOMÁTICAMENTE EL STOCK DE TODOS LOS PRODUCTOS CON CANTIDAD MENOR A 15
async function replenishStock() {
    
    try {
        // SELECCIONA PRODUCTOS CON BAJO STOCK
        const [lowStock] = await db.query(
            "SELECT Product_id, Quantity FROM Products WHERE Quantity < 15"
        );

        if (lowStock.length === 0) {
            console.log("No hay productos con bajo stock.");
            return false; // No se actualizó ningún producto
        }

        // AUMENTA EN 1 LA CANTIDAD DE CADA PRODUCTO CON BAJO STOCK
        for (const product of lowStock) {
            await db.query(
                "UPDATE Products SET Quantity = Quantity + 1 WHERE Product_id = ?",
                [product.Product_id]
            );
            console.log(`Producto con ID ${product.Product_id} actualizado. Nuevo stock: ${product.Quantity + 1}`);
        }

        console.log("Stock actualizado para productos con bajo inventario.");
        return true; // Se actualizó al menos un producto
    } catch (error) {
        console.error("Error al actualizar el stock:", error);
        throw error;
    }
}


// EXPORTA TODAS LAS FUNCIONES PARA USO EXTERNO
module.exports = {
    addToCartValues,
    getCartValues,
    deleteCartProductValues,
    createOrderValues,
    updateProductOrderValues,
    replenishStock
};