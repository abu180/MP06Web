const express = require('express');
const { addToCart, getCart, deleteProductCart, updateProductOrder, createOrder } = require('./CartController.js');

// IMPORTAMOS EL MODULO DE EXPRESS
const router = express.Router();
// RUTAS PARA EL CARRITO
router.post('/addToCart', addToCart);
router.get('/getCart/:user_id', getCart);
router.delete('/deleteProductCart/:id', deleteProductCart)
router.put('/updateProductOrder', updateProductOrder)
router.post('/createOrder/:user_id', createOrder);

module.exports = router;