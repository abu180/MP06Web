// TODAS LAS FUNCIONES SQL RELACIONADO CON EL CARRITO DE COMPRAS.
const { addToCartValues, getCartValues, deleteCartProductValues, updateProductOrderValues, replenishStock, createOrderValues } = require('./CartModel');


// FUNCION PARA AGREGAR UN PRODUCTO AL CARRITO DE COMPRAS
async function addToCart(req, res) {
    //ESTOS PARAMETROS SON NECESARIOS YA QUE LOS PRODUCTOS QUE HAY EN UN CARRO SON DE UN UNICO CLIENTE (user_id)
    const { user_id, product_id, quantity } = req.body;

    // PROBAMOS DE ANADIR, LLAMAMOS LA FUNCION SQL.
    try {
        await addToCartValues(user_id, product_id, quantity);
        res.status(201).json({ message: 'Producto añadido al carrito' });
    } catch (error) {
        console.error('Error al añadir el producto al carrito:', error);
        res.status(500).json({ error: 'Error al añadir el producto al carrito' });
    }
}


// FUNCION PARA OBTENER LOS PRODUCTOS QUE HAY EN EL CARRO
async function getCart(req, res) {
    // NECESITAMOS EL ID DEL USUARIO PARA SABER QUE PRODUCTOS TIENE EN EL CARRO
    const { user_id } = req.params;

    // LLAMAMOS A LA FUNCION SQL
    try {
        const cart = await getCartValues(user_id);
        res.status(200).json(cart);
    } catch (error) {
        console.error('Error al obtener el carrito:', error);
        res.status(500).json({ error: 'Error al obtener el carrito' });
    }
}


// FUNCION PARA ELIMINAR UN PRODUCTO DEL CARRITO
async function deleteProductCart(req, res) {
    // NECESITAMOS EL ID DEL USUARIO PARA SABER QUE PRODUCTOS TIENE EN EL CARRO
    const { id } = req.params;

    // LLAMAMOS A LA FUNCION SQL
    try {
        await deleteCartProductValues(id);
        res.status(204).end();
    } catch (error) {
        console.log(error);
    }
}

// FUNCION PARA CREAR UN PEDIDO DESPUES DE REALIZAR UNA COMPRA
async function createOrder(req, res) {
    // ID DEL USUARIO NECESARIO PARA PODER CREAR EL PEDIDO
    const { user_id } = req.params;

    // DESPUES DE HACER UNA COMPRA, CREAMOS EL PEDIDO
    // EJECUTAMOS LA FUNCION SQL
    try {
        const orderData = await createOrderValues(user_id);
        console.log("ID del pedido creado:", orderData.order_id);
        res.status(201).json({ message: 'Pedido creado', Order_id: orderData.order_id });
    } catch (error) {
        console.error('Error al crear el pedido:', error);
        res.status(500).json({ error: 'Error al crear el pedido' });
    }
}


/* 
    CUANDO SE CREA UN PEDIDO Y SE REALIZA UNA COMPRA, HAY QUE INSERTAR LA CANTIDAD COMPRADA DE ESE 
    PRODUCTO EN LA BASE DE DATOS 
*/
async function updateProductOrder(req, res) {
    const { id, quantity } = req.body;

    try {
        await updateProductOrderValues(id, quantity);
        res.status(200).json({ message: 'Stock Actualizado' });
    } catch(error) {
        console.log(error);
        res.status(500).json({ error: 'Error al actualizar el stock' });
    }
}


// EXPORTAMOS TODAS LAS FUNCIONES
module.exports = {
    addToCart,
    getCart,
    deleteProductCart,
    createOrder,
    updateProductOrder
};