// FUNCIONES SQL NECESARIAS
const { getCustomerValues, addContactValues } = require('./ContactModel');

// CONTROLADOR PARA OBTENER CLIENTE
async function getCustomer(req, res) {
    const { user_id } = req.params;

    try {
        const response = await getCustomerValues(user_id);
        res.json(response);
    } catch(error) {
        console.log(error);
    }
}

// CONTROLADOR PARA ANADIR UN CONTACTO
async function addContact(req, res) {
    const { customer_id, name, email, affair, message } = req.body;

    try {
        const response = await addContactValues(customer_id, name, email, affair, message);
        res.status(201).json(response);
    } catch(error) {
        console.log(error)
    }
}

// EXPORTAMOS MODULOS
module.exports = {
    getCustomer,
    addContact,
}