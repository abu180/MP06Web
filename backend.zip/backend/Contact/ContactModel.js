// BASE DE DATOS IMPORTADA
const db = require('../db');

// OBTENEMOS LOS VALORES DEL CLIENTE EN ESPECIFICO
async function getCustomerValues(user_id) {
    const [sql] = await db.query(
        "SELECT C.Name, U.Email, U.customer_id FROM Customers C JOIN Users U ON U.customer_id = C.Customer_id WHERE U.User_id = ?",
        [user_id]
    );
    return sql;
}

// ANADIMOS UN CONTACTO 
async function addContactValues(customer_id, name, email, affair, message) {
    const [sql] = await db.query(
        "INSERT INTO Contact (customer_id, Name, Email, Affair, Message) VALUES(?, ?, ?, ?, ?)",
        [customer_id, name, email, affair, message]
    );
    return sql;
}

// EXPORTAMOS LOS MODULOS
module.exports = {
    getCustomerValues,
    addContactValues,
}