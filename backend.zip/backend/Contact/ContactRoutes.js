// MODULOS Y FUNCIONES NECESARIAS PARA EL ENRRUTADOR
const express = require('express');
const router = express.Router();
const { getCustomer, addContact, } = require('./ContactController');

// RUTA PARA OBTENER EL CLIENTE
router.get('/getCustomer/:user_id', getCustomer);
// RUTA PARA ANADIR UN CONTACTO (FORMULARIO DE CONTACTO) DESDE FRONTEND
router.post('/addContact', addContact);

// EXPORTAMOS LOS MODULOS
module.exports = router;