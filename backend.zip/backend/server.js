// MODULOS NECESARIO PARA INICIAR EL SERVIDOR
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const multer = require('multer');

// ENRUTADORES NECESARIOS PARA CONECTAR AL SERVIDOR
const companyRoutes = require('./Company/CompanyRoutes');
const usersRoutes = require('./Users/UsersRoutes');
const registerRoutes = require('./Register/RegisterRoutes');
const customersRoutes = require('./Customers/CustomersRoutes');
const productsRoutes = require('./Products/ProductsRoutes');
const supplierRoutes = require('./Suppliers/SuppliersRoutes');
const cartRoutes = require('./Cart/CartRoutes');
const checkoutRoutes = require('./Checkout/CheckoutRoutes');
const ordersRoutes = require('./Orders/OrdersRoutes');
const orderDetailsRoutes = require('./OrderDetails/OrderDetailsRoutes');
const countriesRoutes = require('./Countries/CountriesRoutes');
const reviewsRoutes = require('./Reviews/ReviewsRoutes');
const contactRoutes = require('./Contact/ContactRoutes');
const { replenishStock } = require('./Cart/CartModel');
const { updateOrderSendState, updateOrderArrived } = require('./Orders/OrdersModel');
const app = express();

//MIDDLEWARE
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CONECTOR CON BACKEND Y SERVIDOR PARA SUBIR UNA IMAGEN
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads')));

//RUTAS PARA CONECTAR DE SERVIDOR A BACKEND
app.use('/Company', companyRoutes)
app.use('/Users', usersRoutes);
app.use('/api', registerRoutes);
app.use('/Customers', customersRoutes);
app.use('/Products', productsRoutes);
app.use('/Suppliers', supplierRoutes);
app.use('/Cart', cartRoutes);
app.use('/Orders', ordersRoutes);
app.use('/OrderDetails', orderDetailsRoutes);
app.use('/Checkout', checkoutRoutes);
app.use('/Countries', countriesRoutes);
app.use('/Reviews', reviewsRoutes);
app.use('/Contact', contactRoutes);


// CRONOMETRO PARA ACTUALIZAR EL STOCK DE LOS PRODUCTOS CADA 20s
setInterval(async () => {
    try {
        await replenishStock();
    } catch (error) {
        console.log(error);
    } 
}, 20 * 1000);

// CRONOMETRO PARA QUE EL PRODUCTO PASE DE EN PROCESO A ENVIADO
setInterval(async () => {
    try {
        const sendOrder = await updateOrderSendState();

        if (sendOrder.affectedRows > 0) {
            console.log("Pedido en camino");
        }
    } catch(error) {
        console.log(error);
    } 
}, 10 * 1000);

// CRONOMETRO PARA QUE EL PRODUCTO PASE DE ENVIADO A ENTREGADO
setInterval(async () => {
    try {
        const arrivedOrder = await updateOrderArrived();

        if(arrivedOrder.affectedRows > 0) {
            console.log("Pedido entregado");
        }
    } catch(error) {
        console.log(error);
    }
}, 30 * 1000);


// PUERTO PARA CONECTAR BACKEND CON SERVIDOR
const PORT = process.env.PORT || 8000;

//INICIAMOS EL SERVIDOR
app.listen(PORT, ()=> {
    //startStockTimer();
    console.log(`Servidor corriendo`);
})