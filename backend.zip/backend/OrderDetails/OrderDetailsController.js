// FUNCIONES SQL NECESARIAS
const { makeOrderDetailsValues } = require('./OrderDetailsModel');

// CREAR EL DETALLE DE UN PEDIDO
async function makeOrderDetail(req, res) {
    // PASAMOS EL ID DEL PEDIDO Y LOS PRODUCTOS
    const { order_id, products } = req.body;

    console.log("Datos recibidos en el backend para OrderDetails:", { order_id, products });

    // SI NO SE PASAN VALORES, NO EJECUTAMOS NADA
    if (!order_id || !products || products.length === 0) {
        return res.status(400).json({ error: 'Faltan datos para crear los detalles del pedido' });
    }

    // PROVAMOS DE CREAR EL DETALLE DE UN PEDIDO
    try {
        const orderDetails = await makeOrderDetailsValues(order_id, products);
        console.log('Detalles del pedido creados:', orderDetails);
        res.status(201).json({ message: 'Detalles del pedido creados', orderDetails });
    } catch (error) {
        console.error('Error al crear los detalles del pedido:', error);
        res.status(500).json({ error: 'Error al crear los detalles del pedido' });
    }
}

// EXPORTAMOS LOS MODULOS
module.exports = {
    makeOrderDetail,
};