// IMPORTAMOS BASE DE DATOS
const db = require('../db');

// FUNCIONS SQL PARA INSERTAR LOS DATOS DEL DETALLE DE UN PEDIDO
async function makeOrderDetailsValues(order_id, products) {
    // VALORES 
    const values = products.map(product => [
        order_id,
        product.product_id,
        product.unit_price,
        product.quantity,
    ]);

    console.log("Valores para la consulta SQL:", values);

    // CONSULTA SQL
    const sql = `
        INSERT INTO OrderDetails (order_id, product_id, UnitPrice, Quantity)
        VALUES ?
    `;

    // PROBAMOS DE HACER EL INSERT
    try {
        const [result] = await db.query(sql, [values]);
        console.log("Resultado de la consulta SQL:", result);
        return result;
    } catch (error) {
        console.error("Error en la consulta SQL:", error);
        throw error;
    }
}

// EXPORTAMOS EL MODULO
module.exports = {
    makeOrderDetailsValues,
};