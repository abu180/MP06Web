// MODULOS Y FUNCIONES NECESARIAS PARA EL ENRUTAMIENTO
const express = require('express');
const router = express.Router();
const { makeOrderDetail } = require('./OrderDetailsController');

// RUTA PARA CREAR EL DETALLE DE UN PEDIDO
router.post('/makeOrderDetail', makeOrderDetail);

// EXPORTAMOS EL ENRUTADOR
module.exports = router;