// backend/Orders/OrdersController.js

// Importamos las funciones SQL del modelo
const {
  getOrdersValues,
  getOrdersByStateValues,
  countOrdersByStateValues,
  updateOrderInProcessState: modelUpdateOrderInProcessState,
  updateOrderCancelState: modelUpdateOrderCancelState
} = require('./OrdersModel');

/**
 * GET /
 * Devuelve todos los pedidos
 */
async function getOrders(req, res) {
  try {
    const orders = await getOrdersValues();
    res.json(orders);
  } catch (error) {
    console.error('Error al obtener pedidos:', error);
    res.status(500).json({ error: 'Error al obtener los pedidos' });
  }
}

/**
 * GET /state/:state
 * Devuelve los pedidos filtrados por estado
 */
async function getOrdersByState(req, res) {
  const { state } = req.params;
  try {
    const ordersState = await getOrdersByStateValues(state);
    res.json(ordersState);
  } catch (error) {
    console.error(`Error al obtener pedidos con estado ${state}:`, error);
    res.status(500).json({ error: 'Error al filtrar pedidos por estado' });
  }
}

/**
 * GET /counts/:state
 * Devuelve el número de pedidos en un estado dado
 */
async function getOrderCounts(req, res) {
  const { state } = req.params;
  try {
    const [orderCount] = await countOrdersByStateValues(state);
    res.json(orderCount);
  } catch (error) {
    console.error(`Error al contar pedidos con estado ${state}:`, error);
    res.status(500).json({ error: 'Error al obtener conteo de pedidos' });
  }
}

/**
 * PUT /updateOrderInProcessState/:id
 * Pasa un pedido de "Pendiente" a "Procesando"
 */
async function updateOrderInProcessState(req, res) {
  const { id } = req.params;
  try {
    await modelUpdateOrderInProcessState(id);
    res.sendStatus(204);
  } catch (error) {
    console.error(`Error al actualizar a "Procesando" orden ${id}:`, error);
    res.status(500).json({ error: 'Error al actualizar el estado a Procesando' });
  }
}

/**
 * PUT /updateOrderCancelState/:id
 * Pasa un pedido de "Pendiente" a "Cancelado"
 */
async function updateOrder_CancelState(req, res) {
  const { id } = req.params;
  try {
    await modelUpdateOrderCancelState(id);
    res.sendStatus(204);
  } catch (error) {
    console.error(`Error al cancelar orden ${id}:`, error);
    res.status(500).json({ error: 'Error al cancelar la orden' });
  }
}

module.exports = {
  getOrders,
  getOrdersByState,
  getOrderCounts,
  updateOrderInProcessState,
  updateOrder_CancelState,
};
