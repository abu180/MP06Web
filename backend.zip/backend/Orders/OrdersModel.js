// backend/Orders/OrdersModel.js
const db = require('../db');

// ─── Obtener todas las órdenes ─────────────────────────
async function getOrdersValues() {
  const [rows] = await db.query(
    `SELECT O.Order_id, O.OrderDate, O.State,
            C.Name, C.Surname, C.Phone, C.Adress
     FROM Orders O
     JOIN Customers C ON C.Customer_id = O.customer_id;`
  );
  return rows;
}

// ─── Órdenes por estado ────────────────────────────────
async function getOrdersByStateValues(state) {
  const [rows] = await db.query(
    `SELECT O.Order_id, O.OrderDate, O.State,
            C.Name, C.Surname, C.Phone, C.Adress
     FROM Orders O
     JOIN Customers C ON C.Customer_id = O.customer_id
     WHERE O.State = ?;`,
    [state]
  );
  return rows;
}

// ─── Conteo de órdenes por estado ──────────────────────
async function countOrdersByStateValues(state) {
  const [rows] = await db.query(
    "SELECT COUNT(*) AS count FROM Orders WHERE State = ?;",
    [state]
  );
  // devolvemos el primer objeto: { count: n }
  return rows[0];
}

// ─── Marcar un pedido como “Procesando” ────────────────
async function updateOrderInProcessState(orderId) {
  const [result] = await db.query(
    "UPDATE Orders SET State = 'Procesando' WHERE Order_id = ?",
    [orderId]
  );
  return result;
}

// ─── Marcar un pedido como “Enviado” ───────────────────
async function updateOrderSendState(orderId) {
  const [result] = await db.query(
    "UPDATE Orders SET State = 'Enviado' WHERE State = 'Procesando'",
    [orderId]
  );
  return result;
}

// ─── Marcar un pedido como “Entregado” ────────────────
async function updateOrderArrived(orderId) {
  const [result] = await db.query(
    "UPDATE Orders SET State = 'Entregado' WHERE State = 'Enviado'",
    [orderId]
  );
  return result;
}

// ─── Marcar un pedido como “Cancelado” ────────────────
async function updateOrderCancelState(orderId) {
  const [result] = await db.query(
    "UPDATE Orders SET State = 'Cancelado' WHERE Order_id = ?",
    [orderId]
  );
  return result;
}

module.exports = {
  getOrdersValues,
  getOrdersByStateValues,
  countOrdersByStateValues,
  updateOrderInProcessState,
  updateOrderSendState,
  updateOrderArrived,
  updateOrderCancelState,
};
