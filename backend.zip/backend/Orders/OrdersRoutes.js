// backend/Orders/OrdersRoutes.js

const express = require('express');
const router = express.Router();
const {
  getOrders,                   // GET    /            → lista todas las órdenes
  getOrdersByState,           // GET    /state/:state → filtra por estado
  getOrderCounts,             // GET    /counts/:state→ cuenta por estado
  updateOrderInProcessState,  // PUT    /updateOrderInProcessState/:id → a “Procesando”
  updateOrder_CancelState

} = require('./OrdersController');

// Listado completo
router.get('/', getOrders);

// Filtrado por estado
router.get('/state/:state', getOrdersByState);

// Conteo por estado
router.get('/counts/:state', getOrderCounts);

// Cambiar a “Procesando”
router.put('/updateOrderInProcessState/:id', updateOrderInProcessState);
router.put('/updateOrderCancelState/:id', updateOrder_CancelState);


module.exports = router;
