// backend/Customers/CustomersRoutes.js
const express = require('express');
const router = express.Router();
// FUNCIONES NECESARIAS PARA CREAR LAS RUTAS
const {
  getCustomers,
  addCustomer,
  updateCustomer,
  deleteAssociateUser,
  softDeleteCustomer,
  softDeleteUser_Customer,
  getCustomerById,
  getRemovedCustomers,
  activateCustomer,
  activeUser_Customer,
  getUserCustomerCart,
  getAllUsers_Customer,
  getCustomer_User,
  getCustomer_UserById,
  addCustomer_User,
  updateCustomer_User,
  updateCustomer_UserPassword,
  deleteCustomer_User,
  getCustomer_OrderById,
  updateCustomer_OrderInProcessState,
  updateCustomer_OrderSentState,
  updateCustomer_OrderDeliveredState,
  deleteCustomer_Order,
  deleteCustomer_OrderDetails
} = require('./CustomersController');

// ─── Rutas Clientes ─────────────────────────────────────────
router.get('/', getCustomers);                             // Obtener clientes activos
router.get('/removed', getRemovedCustomers);               // Obtener clientes de baja
router.put('/activateCustomer/:id', activateCustomer);     // Reactivar cliente
router.put('/activateUser_Customer/:id', activeUser_Customer)
router.get('/:id', getCustomerById);                       // Obtener cliente por ID
router.post('/addCustomer', addCustomer);                  // Añadir cliente
router.put('/updateCustomer/:id', updateCustomer);         // Actualizar cliente
router.put('/softDeleteCustomer/:id', softDeleteCustomer);
router.put('/softDeleteUser_Customer/:id', softDeleteUser_Customer);
router.delete('/deleteAssociateUser/:id', deleteAssociateUser); // Eliminar usuarios asociados

// ─── Rutas Carrito de usuario ────────────────────────────────
router.get('/getCustomerUserCart/:id', getUserCustomerCart);

// ─── Rutas Usuarios asociados ────────────────────────────────
router.get('/getAllUsers', getAllUsers_Customer);
router.get('/getCustomer_User/:id', getCustomer_User);
router.get('/getCustomer_UserById/:id', getCustomer_UserById);
router.post('/addCustomer_User/:id', addCustomer_User);
router.put('/updateCustomer_User/:id', updateCustomer_User);
router.put('/updateCustomer_UserPassword/:id', updateCustomer_UserPassword);
router.delete('/deleteCustomer_User/:id', deleteCustomer_User);

// ─── Rutas Órdenes asociadas ────────────────────────────────
router.get('/getCustomer_OrderById/:id', getCustomer_OrderById);
router.put('/updateCustomer_OrderInProcessState/:id', updateCustomer_OrderInProcessState);
router.put('/updateCustomer_OrderSentState/:id', updateCustomer_OrderSentState);
router.put('/updateCustomer_OrderDeliveredState/:id', updateCustomer_OrderDeliveredState);
router.delete('/deleteCustomer_Order/:orderId', deleteCustomer_Order);
router.delete('/deleteCustomer_Order/:orderId',deleteCustomer_Order);
module.exports = router;
