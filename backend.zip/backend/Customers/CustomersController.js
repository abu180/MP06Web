// backend/Customers/CustomersController.js
const bcrypt = require('bcrypt');
const db = require('../db');

// TODAS LAS FUNCIONES SQL RELACIONADAS CON EL CLIENTE
const {
  getAllCustomers,
  getRemovedCustomersValues,
  addCustomerValues,
  updateCustomerValues,
  deleteAssociateUserValues,
  deleteCustomerValues,
  getCustomerByIdValues,
  getUserCustomerCart_Values,
  getAllUsers_CustomerValues,
  getAllProducts_CustomerValues,
  getCustomer_UserValues,
  getCustomer_UserByIdValues,
  addCustomer_UserValues,
  updateCustomer_UserValues,
  updateCustomer_UserPasswordValues,
  deleteCustomer_UserValues,
  getCustomer_OrdersByIdValues,
  updateCustomer_OrdersInProcessStateValue,
  updateCustomer_OrdersSentStateValue,
  updateCustomer_OrdersDeliveredValue,
  deleteCustomer_OrderValues,
  deleteCustomer_OrderDetailsValues
} = require('./CustomersModel');

/* ─── Clientes activos ─── */
async function getCustomers(req, res) {
  try {
    const customers = await getAllCustomers();
    res.json(customers);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al obtener clientes activos' });
  }
}

/* ─── Añadir cliente ─── */
async function addCustomer(req, res) {
  const { Name, Surname, Phone, Adress, Country, PostalCode } = req.body;
  try {
    const newId = await addCustomerValues({ Name, Surname, Phone, Adress, Country, PostalCode });
    res.status(201).json({ Customer_id: newId });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al añadir el cliente' });
  }
}

/* ─── Editar cliente ─── */
async function updateCustomer(req, res) {
  const { id } = req.params;
  const { Name, Surname, Phone, Adress, Country, PostalCode } = req.body;
  try {
    const updated = await updateCustomerValues(id, { Name, Surname, Phone, Adress, Country, PostalCode });
    res.json(updated);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al editar el cliente' });
  }
}

/* ─── SoftDelete ─── */
async function softDeleteCustomer(req, res) {
  const { id } = req.params;
  try {
    await db.query('UPDATE Customers SET is_active = 0 WHERE Customer_id = ?', [id]);
    res.sendStatus(204);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al desactivar el cliente' });
  }
}

async function softDeleteUser_Customer(req, res) {
  const { id } = req.params;
  try {
    await db.query('UPDATE Users SET is_Active = 0 WHERE customer_id = ?', [id])
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al desactivar el usuario' });
  }
}

/* ─── Eliminar usuario asociado ─── */
async function deleteAssociateUser(req, res) {
  const { id } = req.params;
  try {
    await deleteAssociateUserValues(id);
    res.sendStatus(204);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al eliminar usuario asociado' });
  }
}

/* ─── Obtener cliente por ID ─── */
async function getCustomerById(req, res) {
  const { id } = req.params;
  try {
    const customer = await getCustomerByIdValues(id);
    res.json(customer);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al obtener el cliente' });
  }
}

/* ─── Clientes de baja ─── */
async function getRemovedCustomers(req, res) {
  try {
    const rows = await getRemovedCustomersValues();
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al obtener clientes de baja' });
  }
}

/* ─── Reactivar cliente ─── */
async function activateCustomer(req, res) {
  const { id } = req.params;
  try {
    await db.query('UPDATE Customers SET is_active = 1 WHERE Customer_id = ?', [id]);
    res.sendStatus(204);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al reactivar cliente' });
  }
}

/* ─── Reactivar usuario ─── */
async function activeUser_Customer(req, res) {
  const { id } = req.params;
  try {
    await db.query('UPDATE Users SET is_Active = 1 WHERE customer_id = ?', [id])
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al reactivar el usuario' });
  }
}



/* ─── Obtener carrito de usuario asociado ─── */
async function getUserCustomerCart(req, res) {
  const { id } = req.params;
  try {
    const data = await getUserCustomerCart_Values(id);
    res.json(data);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al obtener datos del carrito del cliente' });
  }
}

/* ─── Subformulario Usuarios ─── */
async function getAllUsers_Customer(req, res) {
  try {
    const users = await getAllUsers_CustomerValues();
    res.json(users);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al obtener los usuarios' });
  }
}

// OBTENER PEDIDOS DE UN CLIENTE ASOCIADO
async function getAllOrders_Customer(req, res) {
  const { id } = req.params;
  try {
    const data = await getAllProducts_CustomerValues(id)
    res.json(data);
  } catch(error) {
    console.log(error);
  }
}

// OBTENER USUARIOS ASOCIADOS A UN CLIENTE
async function getCustomer_User(req, res) {
  const { id } = req.params;
  try {
    const customer_user = await getCustomer_UserValues(id);
    res.json(customer_user);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al obtener datos de usuario' });
  }
}

// OBTENER UN USUARIO EN CONCRETO ASOCIADO A UN CLIENTE
async function getCustomer_UserById(req, res) {
  const { id } = req.params;
  try {
    const customer_user = await getCustomer_UserByIdValues(id);
    res.json(customer_user);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al obtener usuario por ID' });
  }
}

// AGREGAR UN USUARIO ASOCIADO PARA UN CLIENTE
async function addCustomer_User(req, res) {
  const users = req.body;
  try {
    const saltRounds = 10;
    const results = [];
    for (const user of users) {
      const { UserName, Email, Password, customer_id } = user;
      if (!UserName || !Email || !Password) {
        return res.status(400).json({ error: 'Todos los campos son obligatorios' });
      }
      const hashed = await bcrypt.hash(Password, saltRounds);
      const newId = await addCustomer_UserValues({ UserName, Email, Password: hashed, customer_id });
      results.push(newId);
    }
    res.status(201).json({ message: 'Usuarios agregados con éxito', results });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al añadir los datos para el usuario.' });
  }
}

// ACTUALIZAR UN USUARIO ASOCIADO A UN CLIENTE 
async function updateCustomer_User(req, res) {
  const { id } = req.params;
  const { UserName, Email, Password } = req.body;
  try {
    const updated = await updateCustomer_UserValues(id, { UserName, Email, Password });
    res.status(200).json(updated);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al editar los datos del usuario.' });
  }
}

// ACTUALIZAR LA CONTRASENA DEL USUARIO ASOCIADO A UN CLIENTE
async function updateCustomer_UserPassword(req, res) {
  const { id } = req.params;
  const { Password } = req.body;
  try {
    const saltRounds = 10;
    if (!Password) {
      return res.status(400).json({ error: 'Todos los campos son obligatorios' });
    }
    const hashed = await bcrypt.hash(Password, saltRounds);
    const updated = await updateCustomer_UserPasswordValues(id, { Password: hashed });
    res.status(200).json(updated);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al cambiar contraseña' });
  }
}

// ELIMINAR UN USUARIO ASOCIADO A UN CLIENTE
async function deleteCustomer_User(req, res) {
  const { id } = req.params;
  try {
    await deleteCustomer_UserValues(id);
    res.sendStatus(204);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al eliminar los datos del usuario.' });
  }
}




/* ─── Subformulario Órdenes ─── */
async function getCustomer_OrderById(req, res) {
  const { id } = req.params;
  try {
    const orders = await getCustomer_OrdersByIdValues(id);
    res.json(orders);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al obtener los datos de la orden' });
  }
}

// PASAR UN PEDIDO DE UN CLIENTE AL ESTADO PENDIENTE
async function updateCustomer_OrderInProcessState(req, res) {
  const { id } = req.params;
  try {
    await updateCustomer_OrdersInProcessStateValue(id);
    res.sendStatus(204);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al actualizar el estado de la orden' });
  }
}

// PASAR UN PEDIDO DE UN CLIENTE AL ESTADO ENVIADO
async function updateCustomer_OrderSentState(req, res) {
  const { id } = req.params;
  try {
    await updateCustomer_OrdersSentStateValue(id);
    res.sendStatus(204);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al actualizar el estado de la orden' });
  }
}

// PASAR UN PEDIDO DE UN CLIENTE AL ESTADO ENTREGADO
async function updateCustomer_OrderDeliveredState(req, res) {
  const { id } = req.params;
  try {
    await updateCustomer_OrdersDeliveredValue(id);
    res.sendStatus(204);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al actualizar el estado de la orden' });
  }
}


/* ELIMINAMOS EL PEDIDO QUE TIENE UN CUSTOMER */
async function deleteCustomer_Order(req, res) {
  const { orderId } = req.params;
  try {
    // 1) borrar detalles
    await deleteCustomer_OrderDetailsValues(orderId);
    // 2) borrar la propia orden
    await deleteCustomer_OrderValues(orderId);
    return res.sendStatus(204);
  } catch (error) {
    console.error('Error al eliminar pedido y detalles:', error);
    return res.status(500).json({ error: 'No se pudo eliminar el pedido' });
  }
}


// EXPORTAMOS LAS FUNCIONES
module.exports = {
  getCustomers,
  addCustomer,
  updateCustomer,
  deleteAssociateUser,
  softDeleteCustomer,
  softDeleteUser_Customer,
  getCustomerById,
  getRemovedCustomers,
  activateCustomer,
  activeUser_Customer,
  getUserCustomerCart,
  getAllUsers_Customer,
  getAllOrders_Customer,
  getCustomer_User,
  getCustomer_UserById,
  addCustomer_User,
  updateCustomer_User,
  updateCustomer_UserPassword,
  deleteCustomer_User,
  getCustomer_OrderById,
  updateCustomer_OrderInProcessState,
  updateCustomer_OrderSentState,
  updateCustomer_OrderDeliveredState,
  deleteCustomer_Order,
};
