// backend/Customers/CustomersModel.js
const db = require('../db');

// ─── Clientes ─────────────────────────────────────────

// Obtener todos los clientes activos y de baja
async function getAllCustomers() {
  const [rows] = await db.query('SELECT * FROM Customers');
  return rows;
}

// Obtener solo los clientes dados de baja (is_active = 0)
async function getRemovedCustomersValues() {
  const [rows] = await db.query('SELECT * FROM Customers WHERE is_active = 0');
  return rows;
}

// Añadir cliente (por defecto is_active = 1)
async function addCustomerValues(Customer) {
  const { Name, Surname, Phone, Adress, Country, PostalCode } = Customer;
  const [sql] = await db.query(
    'INSERT INTO Customers (Name, Surname, Phone, Adress, Country, PostalCode, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)',
    [Name, Surname, Phone, Adress, Country, PostalCode]
  );
  return sql.insertId;
}

// Actualizar cliente
async function updateCustomerValues(id, Customer) {
  const { Name, Surname, Phone, Adress, Country, PostalCode } = Customer;
  const [sql] = await db.query(
    'UPDATE Customers SET Name = ?, Surname = ?, Phone = ?, Adress = ?, Country = ?, PostalCode = ? WHERE Customer_id = ?',
    [Name, Surname, Phone, Adress, Country, PostalCode, id]
  );
  return sql;
}

// Eliminar usuario asociado
async function deleteAssociateUserValues(id) {
  const [sql] = await db.query(
    'DELETE FROM Users WHERE customer_id = ?',
    [id]
  );
  return sql;
}

// Eliminar cliente
async function deleteCustomerValues(id) {
  const [sql] = await db.query(
    'DELETE FROM Customers WHERE Customer_id = ?',
    [id]
  );
  return sql;
}

// Obtener cliente por ID
async function getCustomerByIdValues(id) {
  const [rows] = await db.query(
    'SELECT * FROM Customers WHERE Customer_id = ?',
    [id]
  );
  return rows[0];
}

// Obtener carrito de usuario
async function getUserCustomerCart_Values(id) {
  const [sql] = await db.query(
    `SELECT C.Customer_id, C.Name, C.Surname, C.Adress
     FROM Customers C JOIN Users U
     ON U.customer_id = C.Customer_id
     WHERE U.User_id = ?`,
    [id]
  );
  return sql[0];
}

// ─── Usuarios asociados ────────────────────────────────

async function getAllUsers_CustomerValues() {
  const [sql] = await db.query('SELECT User_id, UserName, Email FROM Users');
  return sql;
}

async function getCustomer_UserValues(id) {
  const [sql] = await db.query(
    'SELECT User_id, UserName, Email, Password FROM Users WHERE customer_id = ?',
    [id]
  );
  return sql;
}


// ─── Pedidos asociados a el ────────S
async function getAllProducts_CustomerValues(id) {
  const [sql] = await db.query(
    "SELECT * Orders O JOIN Users U ON U.customer_id = O.customer_id WHERE U.User_id = ?",
    [id]
  )
  return sql;
}

// OBTENER LOS VALORES DE UN USUARIO EN CONCRETO QUE ESTA ASOCIADO AL CLIENTE
async function getCustomer_UserByIdValues(user_id) {
  const [rows] = await db.query(
    'SELECT User_id, UserName, Email, Password FROM Users WHERE User_id = ?',
    [user_id]
  );
  return rows[0];
}

// AGREGAR VALORES PARA UN USUARIO QUE ESTA ASOCIADO A UN CLIENTE
async function addCustomer_UserValues({ UserName, Email, Password, customer_id }) {
  const [sql] = await db.query(
    'INSERT INTO Users (UserName, Email, Password, customer_id, is_active) VALUES (?, ?, ?, ?, 1)',
    [UserName, Email, Password, customer_id]
  );
  return sql.insertId;
}

// ACTUALIZAAR LOS DATOS DE UN USUARIO QUE ESTA ASOCIADO A UN CLIENTE
async function updateCustomer_UserValues(id, { UserName, Email, Password }) {
  const [sql] = await db.query(
    'UPDATE Users SET UserName = ?, Email = ?, Password = ? WHERE User_id = ?',
    [UserName, Email, Password, id]
  );
  return sql;
}

// ACTUALIZAR LA CONTRASENA DE UN USUARIO ASOCIADO AL CLIENTE
async function updateCustomer_UserPasswordValues(id, { Password }) {
  const [sql] = await db.query(
    'UPDATE Users SET Password = ? WHERE User_id = ?',
    [Password, id]
  );
  return sql;
}

// ELIMINAR LOS VALORES DE UN USUARIO QUE ESTA ASOCIADO A UN CLIENTE
async function deleteCustomer_UserValues(id) {
  const [sql] = await db.query(
    'DELETE FROM Users WHERE User_id = ?',
    [id]
  );
  return sql;
}

// ─── Órdenes asociadas ─────────────────────────────────

async function getCustomer_OrdersByIdValues(id) {
  const [sql] = await db.query(
    `SELECT O.Order_id, C.Name, C.Surname, C.Adress, C.PostalCode,
            C.Country, O.OrderDate, O.State
     FROM Orders O
     JOIN Customers C ON C.Customer_id = O.customer_id
     WHERE C.customer_id = ?`,
    [id]
  );
  return sql;
}

// PASAR LOS PEDIDOS DE UN CLIENTE A EN PROCESO
async function updateCustomer_OrdersInProcessStateValue(id) {
  const [sql] = await db.query(
    "UPDATE Orders SET State = 'Procesando' WHERE Order_id = ?",
    [id]
  );
  return sql;
}

// PASAR LOS PEDIDOS A ESTADO ENVIADO
async function updateCustomer_OrdersSentStateValue(id) {
  const [sql] = await db.query(
    "UPDATE Orders SET State = 'Enviado' WHERE Order_id = ?",
    [id]
  );
  return sql;
}

// PASAR LOS PEDIDOS A ESTADO ENTREGADO
async function updateCustomer_OrdersDeliveredValue(id) {
  const [sql] = await db.query(
    "UPDATE Orders SET State = 'Entregado' WHERE Order_id = ?",
    [id]
  );
  return sql;
}

// Borramos los detalles de la orden por su order_id
async function deleteCustomer_OrderDetailsValues(orderId) {
  return db.query(
    'DELETE FROM OrderDetails WHERE order_id = ?',
    [orderId]
  );
}

// Borramos la orden por su Order_id
async function deleteCustomer_OrderValues(orderId) {
  return db.query(
    'DELETE FROM Orders WHERE Order_id = ?',
    [orderId]
  );
}

// EXPORTAMOS LOS MODULOS
module.exports = {
  getAllCustomers,
  getRemovedCustomersValues,
  addCustomerValues,
  updateCustomerValues,
  deleteAssociateUserValues,
  deleteCustomerValues,
  getCustomerByIdValues,
  getUserCustomerCart_Values,
  getAllUsers_CustomerValues,
  getAllProducts_CustomerValues,
  getCustomer_UserValues,
  getCustomer_UserByIdValues,
  addCustomer_UserValues,
  updateCustomer_UserValues,
  updateCustomer_UserPasswordValues,
  deleteCustomer_UserValues,
  getCustomer_OrdersByIdValues,
  updateCustomer_OrdersInProcessStateValue,
  updateCustomer_OrdersSentStateValue,
  updateCustomer_OrdersDeliveredValue,
  deleteCustomer_OrderValues,
  deleteCustomer_OrderDetailsValues
};
