// FUNCIONES SQL NECESARIAS
const { getAllReviewsValues, getCustomerValues, getProductValues, addReviewValues } = require('./ReviewsModel');

// CONTROLADOR PARA OBTENER LAS VALORACIONES
async function getReviews(req, res) {
    try {
        const reviewsData = await getAllReviewsValues();
        res.json(reviewsData)
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Error al obtener las valoraciones" });

    }
}

// CONTROLADOR PARA OBTENER LOS DATOS DEL CLIENTE PARA EL FORMULARIO DE DEJAR UNA VALORACION
async function getCustomer(req, res) {
    const { user_id } = req.params;

    try {
        const response = await getCustomerValues(user_id);
        res.json(response);
    } catch(error) {
        console.log(error);
        res.status(500).json({ message: "Error al obtener los datos del cliente" });
    }
}

// CONTROLADOR PARA OBTENER LOS PRODUCTOS PARA QUE USUARIO ESCOGA EL PRODUCTO PARA HACER LA VALORACION
async function getProducts(req, res) {
    try {
        const response = await getProductValues();
        res.json(response);
    } catch(error) {
        console.log(error);
    }
}

// CONTROLADOR PARA ANADIR UNA VALORACION
async function addReview(req, res) {
    const { product_id, customer_id, review } = req.body;

    try {
        const response = await addReviewValues(product_id, customer_id, review);
        res.status(201).json(response);
    } catch(error) {
        console.log(error);
    }
}

// EXPORTAMOS LOS CONTROLADORES
module.exports = {
    getReviews,
    getCustomer,
    getProducts,
    addReview,
}