// IMPORTAMOS LA BASE DE DATOS
const db = require('../db');

async function getAllReviewsValues() {
    const [sql] = await db.query(
        'SELECT * FROM Reviews'
    );
    return sql;
}

// OBTENEMOS LOS DATOS DE UN CLIENTE
async function getCustomerValues(user_id) {
    const [sql] = await db.query(
        "SELECT customer_id FROM Users WHERE User_id = ?",
        [user_id]
    );
    return sql;
}

// OBTENEMOS LOS DATOS DE UN PRODUCTO
async function getProductValues() {
    const [sql] = await db.query(
        "SELECT Product_id, ProductName FROM Products"
    );
    return sql;
}

// AGREAGAR UNA VALORACION
async function addReviewValues(product_id, customer_id, review) {
    const [sql] = await db.query(
        "INSERT INTO Reviews SET product_id = ?, customer_id = ?, Review = ?",
        [product_id, customer_id, review]
    );
    return sql;
}

// EXPORTAMOS LAS FUNCIONES SQL
module.exports = {
    getAllReviewsValues,
    getCustomerValues,
    getProductValues,
    addReviewValues,
}