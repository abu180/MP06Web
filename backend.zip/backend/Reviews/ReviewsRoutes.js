// FUNCIONES Y MODULOS NECESARIOS PARA EL ENRUTAMIENTO
const express = require('express');
const router = express.Router();
const { getReviews, getCustomer, getProducts, addReview } = require('./ReviewsController');

// RUTA PARA OBTENER LAS VALORACIONES
router.get('/', getReviews);
// RUTA PARA OBTENER EL CLIENTE QUE ESTA ASOCIADO AL USUARIO
router.get('/getCustomer/:user_id', getCustomer);
// RUTA PARA OBTENER PRODUCTOS
router.get('/getProducts', getProducts);
// RUTA PARA ANADIR UNA VALORACION
router.post('/addReview', addReview);

// EXPORTAMOS EL ENRUTADOR
module.exports = router;