// OBTENEMOS FUNCIONES SQL
const { getCompanyValues } = require('./CompanyModel');

// OBTENEMOS LOS DATOS DEL LOCAL
async function getCompany(req, res) {
    try {
        const company = await getCompanyValues();
        res.json(company);
    } catch(error) {
        console.log(error);
    }
}

// EXPORTAMOS EL MODULO
module.exports = {
    getCompany,
}