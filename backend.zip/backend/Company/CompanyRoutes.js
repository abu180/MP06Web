// MODULOS NECESARIOS PARA EL ENRUTAMIENTO
const express = require('express');
// FUNCIONES NECESARIAS
const { getCompany } = require('./CompanyController');
// ENRUTADOR
const router = express.Router();

// OBTENEMOS EL LOCAL
router.get('/getCompany', getCompany);

// EXPORTAMOS EL MODULO
module.exports = router;