// IMPORTAMOS LA BASE DE DATOS
const db = require('../db');

// OBTENEMOS LOS VALORES DEL LOCAL
async function getCompanyValues() {
    const [sql] = await db.query(
        "SELECT Company_id, CompanyName, SocialNumber, CompanyAdress FROM Company;"
    );

    return sql[0];
}

// EXPORTAMOS EL MODULO
module.exports = {
    getCompanyValues,
}