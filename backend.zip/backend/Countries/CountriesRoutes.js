// MODULOS Y FUNCIONES NECESARIAS PARA EL ENRUTADOR
const express = require('express');
const router = express.Router();
const { getCountries } = require('./CountriesController');

// RUTA PARA OBTENER LOS PAISES
router.get('/', getCountries);

// EXPORTAMOS EL MODULO
module.exports = router;