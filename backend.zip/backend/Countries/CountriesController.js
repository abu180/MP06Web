// FUNCIONES SQL NECESARIAS
const { getCountriesValues } = require('./CountriesModel');

// CONTROLADOR PARA OBTENER LOS PAISES
async function getCountries(req, res) {
    try {
        const countries = await getCountriesValues();
        res.json(countries);
    } catch(error) {
        console.log('Error al obtener los datos de los paises', error);
        res.status(500).json({ message: 'Error al obtener los paises' });
    }
}

// MODULOS EXPORTADOS
module.exports = {
    getCountries,
}