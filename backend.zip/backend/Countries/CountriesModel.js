// IMPORTAMOS BASE DE DATOS
const db = require('../db');

// OBTENEMOS DATOS DE LOS PAISES (NOMRE DEL PAIS...)
async function getCountriesValues() {
    const [sql] = await db.query(
        "SELECT Country_id, CountryName FROM Countries"
    );
    return sql;
}

// EXPORTAMOS LOS MODULOS
module.exports = {
    getCountriesValues,
}