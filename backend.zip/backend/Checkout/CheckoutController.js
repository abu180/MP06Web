// MODULOS NODEMAILER PARA ENVIAR MAIL DESPUES DE LA COMPRA
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');
// CONTROLADOR PARA ENVIAR UN CORREO
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'abu.bardani@gmail.com',
        pass: 'yffj oksd ywqb tmhv ',
    },
})


//MODULOS DE STRIPE (MODULO DE PAGO)
const Stripe = require('stripe');
const stripe = new Stripe('sk_test_51R4QpuID4ug4aLnhcFx6mo64uBwStxCDyzIrqE32YWhoPNfmNZlzJttR3RLPZIugyi3qtZvPWxD1LvvnQfoDQFOg00ipBSshS4');

// CREAMOS UNA SESION DE PAGO
const createSession = async (req, res) => {
    // RECIBIMOS LOS PRODUCTOS DEL CARRITO Y LOS DATOS DEL CLIENTE
    const { products, customer } = req.body;
    // VERIFICAR LOS DATOS EN LA CONSOLA
    console.log(products);
    console.log(customer);

    // PROBAMOS PETICION
    try {
        // SI NO EXISTEN LOS DATOS DE PRODUCTO NO PODEMOS HACER NADA
        if (!products || products.length === 0) {
            return res.status(400).json({ error: 'No hay productos en el carrito' });
        }

        // SI NO EXISTEN LOS DATOS DE CLIENTE NO PODEMOS HACER NADA
        if (!customer) {
            return res.status(400).json({ error: 'No se ha proporcionado información del cliente' });
        }


        // CONSTRUIR UN ARRAY DE LOS DATOS PARA PASARLE A LA SESION Y QUE CREE UN PEDIDO
        const line_items = products.map(product => ({
            price_data: {
                currency: 'eur',
                product_data: {
                    name: product.name,
                    description: product.description || 'Sin descripción',
                },
                unit_amount: product.unit_price,
            },
            quantity: product.quantity,
        }));

        // DESPUES DE LA COMPRA PUEDE SER ERRONEO O EXITOSO
        const session = await stripe.checkout.sessions.create({
            line_items,
            mode: 'payment',
            success_url: `http://localhost:5173/Checkout/Success?products=${encodeURIComponent(JSON.stringify(products))}&customer=${encodeURIComponent(JSON.stringify(customer))}`,
            cancel_url: `http://localhost:5173/Checkout/Cancel?products=${encodeURIComponent(JSON.stringify(products))}`,
        });

        // SI LA COMPRA SE REALIZA CORRECTAMENTE ENVIAMOS EL CORREO
        if(session.success_url) {
            // ARCHIVO .TXT PARA INTRODUCIR LOS DATOS DE LA COMPRA
            const filePath =  path.join(__dirname, 'purchase_details.txt');
            // PLANTILLA
            const purchaseDetails = `
                Cliente: ${customer.Name} ${customer.Surname}
                Dirección: ${customer.Adress}
                Productos:
                ${products.map(product => `- ${product.name} (Cantidad: ${product.quantity}, Precio: ${product.unit_price / 100}€)`).join('\n')}
            `;
            // ESCRIMOS EL CORREO
            fs.writeFileSync(filePath, purchaseDetails);
    
            // LAS OPCIONES DEL CORREO (DESTINATARIO....)
            const mailOptions = {
                from: 'abu.bardani@gmail.com',
                to: 'turrado.joseangel@gmail.com', // CAMBIAR POR EL CORREO DEL CLIENTE!
                subject: 'Detalles de tu compra',
                text: `Gracias por tu compra. Aquí tienes los detalles:\n\n${purchaseDetails}`,
                attachments: [
                    {
                        filename: 'purchase_details.txt',
                        path: filePath,
                    },
                ],
            };
            // ENVIAR CORREO
            await transporter.sendMail(mailOptions);
            // DEBUG
            console.log('Correo enviado correctamente');
        }
        // ENVIAR DATOS AL BACKEDN FORMATO JSON
        return res.json({ url: session.url });
    } catch (error) {
        // CONTROL DE ERROR
        console.error(error);
        return res.status(500).json({ error: 'Error al crear la sesión de pago' });
    }
};

// EXPORTAMOS EL MODULO
module.exports = { createSession };