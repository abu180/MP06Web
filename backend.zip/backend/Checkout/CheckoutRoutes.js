// MODULOS NECESARIOS PARA CREAR ENRUTAMIENTO
const express = require('express');
// CONTROLADOR PARA CREAR ENRUTTAMIENTO
const { createSession } = require('./CheckoutController.js');
// MODULO ENRUTADOR
const router = express.Router();

// RUTA PARA PROBAR LA SESION DE PAGO
router.get('/test', (req, res) => {
    res.send("✅ Rutas funcionando correctamente");
});

// RUTA PARA CREAR UNA SESION DE PAGO
router.post('/createSession', createSession);

// EXPORTAMOS EL MODULO
module.exports = router;