// MODULOS NECESARIOS PARA GUARDAR LA RUTA DE UNA IMAGEN EN UNA CARPETA
const multer = require('multer');
const path = require('path');

// FUNCION PARA GUARDAR LA RUTA DE LA IMAGEN EN EL DISCO DURO
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        //Guardamos el archivo en la carpeta uploads
        cb(null, 'public/uploads');
    },
    filename: (req, file, cb) => {
        //Nombre unico del archivo
        cb(null, Date.now() + path.extname(file.originalname))
    }
});

// FUNCION PARA FILTRAR LA EXTENSION DE LA IMAGEN
const fileFilter = (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new Error('Tipo de archivo no permitido'), false);
    }
};

// FUNCION PARA SUBIR UNA IMAGEN Y GUARDARLA
const upload = multer({ storage, fileFilter });

// EXPORTAMOS LA FUNCION
module.exports = upload;