// backend/src/Products/ProductsModel.js
const db = require('../db');

// Aquí traemos todos los productos, junto con el nombre de contacto de su proveedor si lo tienen.
// Usamos LEFT JOIN para que aparezcan también los productos sin proveedor aún.
async function getAllProducts() {
    const [sql] = await db.query(
        `
        SELECT
            Product_id,
            ProductName,
            UnitPrice,
            Quantity,
            UnitsOnOrder,
            ProductImage,
            ProductDescription
        FROM Products
        `
    );
    return sql;
}

// Borra todos los proveedores de un producto
async function deleteSuppliersByProduct(productId) {
  const [result] = await db.query(
    'DELETE FROM Suppliers WHERE product_id = ?',
    [productId]
  );
  return result;
}


// Busca un producto por su nombre (ignora mayúsculas/minúsculas)
async function getProductByNameValues(productName) {
    const [rows] = await db.query(
        "SELECT * FROM Products WHERE LOWER(ProductName) = LOWER(?)", 
        [productName]
    );
    console.log("🔎 Resultado SQL:", rows);
    return rows;
}

// Inserta un nuevo producto y devuelve su ID
async function addProductValues(Product) {
    const { ProductName, UnitPrice, Quantity, UnitsOnOrder, ProductImage, ProductDescription } = Product;
    const [sql] = await db.query(
        "INSERT INTO Products (ProductName, UnitPrice, Quantity, UnitsOnOrder, ProductImage, ProductDescription) VALUES (?, ?, ?, ?, ?, ?)",
        [ProductName, UnitPrice, Quantity, UnitsOnOrder, ProductImage, ProductDescription]
    );
    return sql.insertId;
}

// Actualiza un producto completo; si viene imagen usamos un update con imagen, si no, sin ella
async function updateProductValues(id, Product) {
    const { ProductName, UnitPrice, Quantity, UnitsOnOrder, ProductImage, ProductDescription } = Product;
    const query = ProductImage
        ? "UPDATE Products SET ProductName = ?, UnitPrice = ?, Quantity = ?, UnitsOnOrder = ?, ProductImage = ?, ProductDescription = ? WHERE Product_id = ?"
        : "UPDATE Products SET ProductName = ?, UnitPrice = ?, Quantity = ?, UnitsOnOrder = ?, ProductDescription = ? WHERE Product_id = ?";
    const values = ProductImage
        ? [ProductName, UnitPrice, Quantity, UnitsOnOrder, ProductImage, ProductDescription, id]
        : [ProductName, UnitPrice, Quantity, UnitsOnOrder, ProductDescription, id];

    await db.query(query, values);
    return { message: "Producto actualizado correctamente" };
}

// Devuelve un producto por su ID
async function getProductByIdValues(id) {
    const [sql] = await db.query(
        "SELECT * FROM Products WHERE Product_id = ?", [id]
    );
    return sql[0];
}

// Borra un producto
async function deleteProductValues(id) {
    const [sql] = await db.query(
        "DELETE FROM Products WHERE Product_id = ?", 
        [id]
    );
    return sql;
}

// -------------------- SUBFORMULARIO PROVEEDORES ---------------------

// Devuelve todos los proveedores de un producto
async function getProduct_SupplierValues(id) {
    const [sql] = await db.query(
        "SELECT * FROM Suppliers WHERE product_id = ?",
        [id]
    );
    return sql;
}

// Devuelve un proveedor específico con datos del producto
async function getProduct_SupplierByIdValues(id) {
    const [sql] = await db.query(
        `SELECT S.Supplier_id, S.Ingredient, S.CompanyName, S.ContactName, S.Phone, S.Adress, S.Country, S.Postal_code, S.product_id,
                P.ProductName, P.Product_id
         FROM Suppliers S
         JOIN Products P ON P.Product_id = S.product_id
         WHERE Supplier_id = ?`,
        [id]
    );
    return sql[0];
}

// Inserta un nuevo proveedor a un producto
async function addProduct_SupplierValues({ Ingredient, CompanyName, ContactName, Phone, Adress, Country, Postal_code, product_id }) {
    const [sql] = await db.query(
        "INSERT INTO Suppliers (Ingredient, CompanyName, ContactName, Phone, Adress, Country, Postal_code, product_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [Ingredient, CompanyName, ContactName, Phone, Adress, Country, Postal_code, product_id]
    );
    return sql.insertId;
}

// Lista de países
async function getCountriesValue() {
    const [sql] = await db.query(
        "SELECT Country_id, Country FROM Countries"
    );
    return sql;
}

// Actualiza un proveedor de producto
async function updateProduct_SupplierValues(id, { Ingredient, CompanyName, ContactName, Phone, Adress, Country, Postal_code, Product_id }) {
    const [sql] = await db.query(
        'UPDATE Suppliers SET Ingredient = ?, CompanyName = ?, ContactName = ?, Phone = ?, Adress = ?, Country = ?, Postal_code = ?, product_id = ? WHERE Supplier_id = ?',
        [Ingredient, CompanyName, ContactName, Phone, Adress, Country, Postal_code, Product_id, id]
    );
    return sql;
}

// Borra un proveedor de producto
async function deleteProduct_SupplierValues(id) {
    const [sql] = await db.query(
        "DELETE FROM Suppliers WHERE Supplier_id = ?",
        [id]
    );
    return sql;
}

// Borra todas las reseñas de un producto
async function deleteReviewsByProduct(productId) {
  const [result] = await db.query(
    'DELETE FROM Reviews WHERE product_id = ?',
    [productId]
  );
  return result;
}

// Borra todos los detalles de pedido de un producto
async function deleteOrderDetailsByProduct(productId) {
  const [result] = await db.query(
    'DELETE FROM OrderDetails WHERE product_id = ?',
    [productId]
  );
  return result;
}

// EXPORTAMOS TODAS LAS FUNCIONES SQL
module.exports = {
    getAllProducts,
    getProductByNameValues,
    addProductValues,
    updateProductValues,
    getProductByIdValues,
    deleteProductValues,
    getProduct_SupplierValues,
    getProduct_SupplierByIdValues,
    addProduct_SupplierValues,
    getCountriesValue,
    updateProduct_SupplierValues,
    deleteProduct_SupplierValues,
    deleteOrderDetailsByProduct,
    deleteReviewsByProduct,
    deleteSuppliersByProduct
};
