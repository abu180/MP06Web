// backend/Products/ProductsRoutes.js
// FUNCIONES Y MODULOS NECESARIOS PARA EL ENRUTAMIENTO
const express = require('express');
const router = express.Router();
const upload = require('../multerConfig');
// FUNCIONES DEL CONTROLADOR QUE NECESITAREMOS PARA LAS PETICIONES BACKEND
const {
  searchProducts,
  getProducts,
  getProductById,
  getProductByName,
  addProduct,
  updateProduct,
  deleteProduct,
  getProduct_Supplier,
  getProduct_SupplierById,
  addProduct_Supplier,
  updateProduct_Supplier,
  deleteProduct_Supplier,
  getCountries
} = require('./ProductsController');

// RUTA DEL BUSCADOR, OBTENERMOS LOS PRODUCTOS
router.get('/search', searchProducts);
router.get('/name/:productName', getProductByName);

// RUTA PARA OBTENER LOS PRODUCTOS
router.get('/',              getProducts);
// RUTA PARA OBTENER LOS DATOS DE UN PRODUCTO EN CONCRETO
router.get('/:id',           getProductById);
// RUTA PARA ANADIR UN PRODUCTO
router.post('/addProduct',   upload.single('ProductImage'), addProduct);
// RUTA PARA SUBIR IMAGEN DEL PRODUCTO
router.put('/updateProduct/:id', upload.single('ProductImage'), updateProduct);
// RUTA PARA ELIMINAR UN PRODUCTO
router.delete('/deleteProduct/:id', deleteProduct);



// RUTA PARA OBTENER EL PROVEEDOR DE UN PRODUCTO
router.get('/getProduct_Supplier/:id',     getProduct_Supplier);
// RUTA PARA OBTENER LOS VALORES DEL PROVEEDOR DE UN PRODUCTO
router.get('/getProduct_SupplierById/:id', getProduct_SupplierById);
// RUTA PARA ANADIR UN PROVEEDOR AL PRODUCTO
router.post('/addProduct_Supplier/:id',    addProduct_Supplier);
// RUTA PARA ACTUALIZAR EL PROVEEDOR DE UN PRODUCTO
router.put('/updateProduct_Supplier/:id',  updateProduct_Supplier);
// RUTA PARA ELIMINAR EL PROVEEDOR DE UN PRODUCTO
router.delete('/deleteProduct_Supplier/:id', deleteProduct_Supplier);

// RUTA PARA OBTENER LOS PAISES
router.get('/getCountries', getCountries);


// EXPORTAR MODULO ENRUTADOR
module.exports = router;
