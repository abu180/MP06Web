// backend/Products/ProductsController.js
const upload = require('../multerConfig');
// TODAS LAS FUNCIONES SQL
const {
  getAllProducts,
  getProductByNameValues,
  addProductValues,
  updateProductValues,
  getProductByIdValues,
  deleteProductValues,
  getProduct_SupplierValues,
  getProduct_SupplierByIdValues,
  addProduct_SupplierValues,
  getCountriesValue,
  updateProduct_SupplierValues,
  deleteProduct_SupplierValues,
  deleteOrderDetailsByProduct,
  deleteReviewsByProduct,
  deleteSuppliersByProduct
} = require('./ProductsModel');

// ─── Listado general ────────────────────────────────
async function getProducts(req, res) {
  try {
    const products = await getAllProducts();
    res.json(products);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error al obtener productos' });
  }
}

// ─── Obtener 1 producto por su ID ──────────────────
async function getProductById(req, res) {
  const { id } = req.params;
  try {
    const product = await getProductByIdValues(id);
    if (!product) return res.status(404).json({ message: 'Producto no encontrado' });
    res.json(product);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener el producto' });
  }
}

// ─── Buscar por nombre ─────────────────────────────
async function getProductByName(req, res) {
  const { productName } = req.params;
  try {
    const rows = await getProductByNameValues(productName);
    if (!rows.length) return res.status(404).json({ message: 'Producto no encontrado' });
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error al buscar el producto' });
  }
}

// ─── Crear ──────────────────────────────────────────
async function addProduct(req, res) {
  const { ProductName, UnitPrice, Quantity, UnitsOnOrder, ProductDescription } = req.body;
  const ProductImage = req.file ? `/uploads/${req.file.filename}` : null;
  try {
    const newId = await addProductValues({ ProductName, UnitPrice, Quantity, UnitsOnOrder, ProductImage, ProductDescription });
    res.status(201).json({ Product_id: newId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al añadir el producto' });
  }
}

// ─── Actualizar ────────────────────────────────────
async function updateProduct(req, res) {
  const { id } = req.params;
  const { ProductName, UnitPrice, Quantity, UnitsOnOrder, ProductDescription } = req.body;
  const ProductImage = req.file ? `/uploads/${req.file.filename}` : null;
  try {
    await updateProductValues(id, { ProductName, UnitPrice, Quantity, UnitsOnOrder, ProductImage, ProductDescription });
    res.json({ message: 'Producto actualizado' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al actualizar el producto' });
  }
}

// Reemplaza tu deleteProduct por este único método:
async function deleteProduct(req, res) {
  const { id } = req.params;
  try {
    // 1) borrar suppliers asociados
    await deleteSuppliersByProduct(id);

    // 2) borrar reviews asociados
    await deleteReviewsByProduct(id);

    // 3) borrar detalles de orden asociados
    await deleteOrderDetailsByProduct(id);

    // 4) por último, borrar el producto
    await deleteProductValues(id);

    return res.sendStatus(204);
  } catch (err) {
    console.error('Error al eliminar producto y dependientes:', err);
    return res.status(500).json({ error: 'No se pudo eliminar el producto' });
  }
}
// ─── Subformulario Proveedores ────────────────────
async function getProduct_Supplier(req, res) {
  try {
    const list = await getProduct_SupplierValues(req.params.id);
    res.json(list);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener proveedores' });
  }
}

// CONTROLADOR QUE OBTIENE EL PROVEEDOR DE UN PRODUCTO
async function getProduct_SupplierById(req, res) {
  try {
    const item = await getProduct_SupplierByIdValues(req.params.id);
    res.json(item);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener proveedor' });
  }
}

// CONTROLADOR QUE AGREGA UN PROVEEDOR DE UN PRODUCTO
async function addProduct_Supplier(req, res) {
  try {
    const newId = await addProduct_SupplierValues({ ...req.body, product_id: req.params.id });
    res.status(201).json({ Supplier_id: newId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al añadir el proveedor' });
  }
}

// CONTROLADOR QUE ACTUALIZA EL PROVEEDOR DE UN PRODUCTO
async function updateProduct_Supplier(req, res) {
  try {
    await updateProduct_SupplierValues(req.params.id, req.body);
    res.json({ message: 'Proveedor actualizado' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al actualizar proveedor' });
  }
}

// CONTROLADOR QUE ELIMINA EL PROVEEDOR DE UN PRODUCTO
async function deleteProduct_Supplier(req, res) {
  try {
    await deleteProduct_SupplierValues(req.params.id);
    res.sendStatus(204);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al eliminar proveedor' });
  }
}

// CONTROLADOR PARA OBTENER TODOS LOS PAISES
async function getCountries(req, res) {
  try {
    const list = await getCountriesValue();
    res.json(list);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener países' });
  }
}

// ─── Buscador simple por nombre ─────────────────────────────
async function searchProducts(req, res) {
  const { q } = req.query;
  if (!q) return res.json([]);
  try {
    const all = await getAllProducts();
    const filtered = all.filter(p =>
      p.ProductName.toLowerCase().includes(q.toLowerCase())
    );
    return res.json(filtered);
  } catch (err) {
    console.error("Error en searchProducts:", err);
    return res.status(500).json({ message: "Error al buscar productos" });
  }
}

// EXPORTAMOS LOS CONTROLADORES
module.exports = {
  searchProducts,
  getProducts,
  getProductById,
  getProductByName,
  addProduct,
  updateProduct,
  deleteProduct,
  getProduct_Supplier,
  getProduct_SupplierById,
  addProduct_Supplier,
  updateProduct_Supplier,
  deleteProduct_Supplier,
  getCountries,
  deleteProduct
};
