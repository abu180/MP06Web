// FUNCIONES SQL QUE NECESITAMOS
const { getAllSuppliers, addSupplierValues, getSupplierByIdValues, updateSupplierValues, deleteSupplierValues } = require('./SuppliersModel');

// OBTENEMOS TODOS LOS PROVEEDORES
async function getSuppliers(req, res) {
    try {
        const suppliers = await getAllSuppliers();

        res.json(suppliers);
    } catch(error) {
        console.log('Error al obtener los datos de los proveedores', error);
        res.status(500).json({ message: 'Error al obtener los proveedores' });
    }
}

// AGREGAR PROVEEDOR
async function addSupplier(req, res) {
    // RECIBIMOS DATOS DEL FORMULARIO
    const { Ingredient, CompanyName, ContactName, Phone, Adress, Country, Postal_code, Product_id } = req.body;

    try {
        // OBJETO PROVEEDOR CON SUS CAMPOS
        const newSupplier = await addSupplierValues({
            Ingredient,
            CompanyName,
            ContactName,
            Phone,
            Adress,
            Country,
            Postal_code,
            Product_id,
        });
        // ENVIAMOS DATOS EN FORMATO JSON AL BACKEND
        res.status(201).json(newSupplier);
    } catch(error) {
        res.status(500).json({error: 'Error al anadir el proveedor'});
    }
}

// OBTENEMOS LOS DATOS DE UN PROVEEDOR EN CONCRETO
async function getSupplierById(req, res) {
    const { id } = req.params;
    try {
        const supplier = await getSupplierByIdValues(id);
        if (!supplier) {
            return res.status(404).json({ message: 'Proveedor no encontrado' });
        }
        res.json(supplier);
    } catch(error) {
        console.log('Error al obtener los datos del proveedor', error);
        res.status(500).json({ message: 'Error al obtener el proveedor' });
    }
}

// ACTUALIZAR PROVEEDOR
async function updateSupplier(req, res) {
    // ID DEL PROVEEDOR
    const { id } = req.params;
    // DATOS DEL FORMULARIO
    const { Ingredient, CompanyName, ContactName, Phone, Adress, Country, Postal_code, Product_id } = req.body;

    console.log("ID del proveedor:", id);
    console.log("Datos del proveedor:", req.body);

    try {
        // OBJETO PROVEEDOR
        const updatedSupplier = await updateSupplierValues(id, {
            Ingredient,
            CompanyName,
            ContactName,
            Phone,
            Adress,
            Country,
            Postal_code,
            Product_id
        });

        console.log("Proveedor actualizado:", updatedSupplier);
        // ENVIAMOS LOS DATOS EN FORMATO JSON AL BACKEND
        res.status(201).json(updatedSupplier);
    } catch(error) {
        console.log('Error al editar el proveedor', error);
        res.status(500).json({ message: 'Error al editar el proveedor' });
    }
}

// ELIMINAMOS EL PROVEEDOR
async function deleteSupplier(req, res) {
    const { id } = req.params;
    try {
        await deleteSupplierValues(id);
        res.status(204).end();
    } catch (error) {
        console.log('Error al eliminar el proveedor', error);
        res.status(500).json({ message: 'Error al eliminar el proveedor' });
    }
}

// EXPORTAMOS TODOS LOS CONTROLADORES
module.exports = {
    getSuppliers,
    addSupplier,
    getSupplierById,
    updateSupplier,
    deleteSupplier,
}