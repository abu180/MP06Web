// FUNCIONES Y MODULOS NECESARIOS PARA EL ENRUTAMIENTO
const express = require('express');
const router = express.Router();
const { getSuppliers, addSupplier, getSupplierById, updateSupplier, deleteSupplier } = require('./SuppliersController');

// RUTA PARA OBTENER PROVEEDORES
router.get('/', getSuppliers);

// RUTA PARA OBTENER UN PROVEEDOR
router.get('/:id', getSupplierById);

// RUTA PARA ANADIR UN PROVEEDOR
router.post('/addSupplier', addSupplier);

// RUTA PARA ACTUALIZAR UN PROVEEDOR
router.put('/updateSupplier/:id', updateSupplier);

// RUTA PARA ELIMINAR UN PROVEEDOR
router.delete('/deleteSupplier/:id', deleteSupplier);


// EXPORTAMOS EL ENRUTADOR
module.exports = router;