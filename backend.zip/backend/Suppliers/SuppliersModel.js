// IMPORTAMOS LA BASE DE DATOS
const db = require('../db');

// DEVOLVEMOS TODOS LOS PROVEEDORES
async function getAllSuppliers() {
    const [sql] = await db.query('SELECT * FROM Suppliers');
    return sql;
}


// INSERTAMOS LOS DATOS PARA ANADIR UN PROVEEDOR
async function addSupplierValues(Supplier) {
    const  { Ingredient, CompanyName, ContactName, Phone, Adress, Country, Postal_code, Product_id } = Supplier;
    const [sql] = await db.query(
        "INSERT INTO Suppliers (Ingredient, CompanyName, ContactName, Phone, Adress, Country, Postal_code, product_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [Ingredient, CompanyName, ContactName, Phone, Adress, Country, Postal_code, Product_id]
    );
    return sql
}

// OBTENEMOS LOS DATOS DE UN PROVEEDOR EN CONCRETO
async function getSupplierByIdValues(id) {
    const [sql] = await db.query(
        "SELECT S.Ingredient, S.CompanyName, S.ContactName, S.Phone, S.Adress, S.Country, S.Postal_code, S.product_id, P.ProductName AS ProductName, P.Product_id as Product_id FROM Suppliers S JOIN Products P ON P.Product_id = S.Product_id WHERE S.Supplier_id = ?",
        [id]
    );
    return sql[0];
}

// ACTUALIZAMOS LOS DATOS DE UN PROVEEDOR EN CONCRETO
async function updateSupplierValues(id, Supplier) {
    const { Ingredient, CompanyName, ContactName, Phone, Adress, Country, Postal_code, Product_id} = Supplier;
    const [sql] = await db.query(
        "UPDATE Suppliers SET Ingredient = ?, CompanyName = ?, ContactName = ?, Phone = ?, Adress = ?, Country = ?, Postal_code = ?, product_id = ? WHERE Supplier_id = ?",
        [Ingredient, CompanyName, ContactName, Phone, Adress, Country, Postal_code, Product_id, id]
    );
    return sql;
}

// ELIMINAMOS UN PROVEEDOR
async function deleteSupplierValues(id) {
    const [sql] = await db.query(
        "DELETE FROM Suppliers WHERE Supplier_id = ?",
        [id]
    );
    return sql;
}

// EXPORTAMOS LAS FUNCIONES SQL
module.exports = {
    getAllSuppliers,
    addSupplierValues,
    getSupplierByIdValues,
    updateSupplierValues,
    deleteSupplierValues,
}